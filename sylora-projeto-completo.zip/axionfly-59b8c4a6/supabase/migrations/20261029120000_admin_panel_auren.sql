-- Painel Admin (Sylora): marca Protocolo e registro de conversas do Mentor IA.

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_protocolo boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS public.mentor_ia_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  user_email text,
  question text NOT NULL,
  response text,
  cached boolean NOT NULL DEFAULT false,
  source text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS mentor_ia_logs_created_at_idx ON public.mentor_ia_logs (created_at DESC);
ALTER TABLE public.mentor_ia_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins read mentor logs" ON public.mentor_ia_logs;
CREATE POLICY "Admins read mentor logs" ON public.mentor_ia_logs
  FOR SELECT TO authenticated USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users insert own mentor logs" ON public.mentor_ia_logs;
CREATE POLICY "Users insert own mentor logs" ON public.mentor_ia_logs
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
