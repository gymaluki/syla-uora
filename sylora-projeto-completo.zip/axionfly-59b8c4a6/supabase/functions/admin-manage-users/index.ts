import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "No authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify user is admin
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey);
    const { data: isAdminData } = await admin.rpc("is_admin", { check_user_id: user.id });
    if (!isAdminData) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const action = body.action || "list";

    const json = (obj: unknown, status = 200) =>
      new Response(JSON.stringify(obj), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    // Prazo de cada plano: mensal 30 dias, trial 7, vitalício sem expiração (outros: 365).
    const expiryFor = (plan: string) => {
      if (plan === "lifetime") return null;
      const days = plan === "monthly" ? 30 : plan === "trial" ? 7 : plan === "quarterly" ? 90 : 365;
      return new Date(Date.now() + days * 86400000).toISOString();
    };
    const listAllUsers = async () => {
      const { data, error } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      if (error) throw error;
      return data.users as any[];
    };
    // Somente o dono pode mexer em administradores. Validado aqui, nunca só na interface.
    const requireOwner = async () => {
      const { data } = await admin.rpc("is_owner", { check_user_id: user.id });
      return data === true;
    };

    if (action === "list") {
      // List all users with subscription info
      const { data: { users }, error: listErr } = await admin.auth.admin.listUsers({
        page: 1,
        perPage: 1000,
      });
      if (listErr) throw listErr;

      const { data: subs } = await admin.from("subscriptions").select("*");
      // is_protocolo pode não existir até a migração ser aplicada: tenta com a coluna e cai para o básico.
      let profiles: any[] | null = null;
      const withFlag = await admin.from("profiles").select("user_id, display_name, is_protocolo");
      if (withFlag.error) {
        profiles = (await admin.from("profiles").select("user_id, display_name")).data;
      } else {
        profiles = withFlag.data;
      }
      const { data: adminRows } = await admin.from("admin_users").select("user_id, is_owner");
      const { data: pendings } = await admin.from("pending_payments").select("*").order("created_at", { ascending: false });

      const subMap = new Map((subs || []).map((s: any) => [s.user_id, s]));
      const profileMap = new Map((profiles || []).map((p: any) => [p.user_id, p.display_name]));
      const protoSet = new Set((profiles || []).filter((p: any) => p.is_protocolo === true).map((p: any) => p.user_id));
      const adminMap = new Map((adminRows || []).map((a: any) => [a.user_id, a.is_owner === true]));

      const enriched = users.map((u: any) => {
        const sub = subMap.get(u.id);
        return {
          user_id: u.id,
          email: u.email,
          display_name: profileMap.get(u.id) || u.user_metadata?.full_name || null,
          created_at: u.created_at,
          last_sign_in_at: u.last_sign_in_at,
          subscription: sub || null,
          is_protocolo: protoSet.has(u.id),
          is_admin: adminMap.has(u.id),
          is_owner: adminMap.get(u.id) === true,
        };
      });

      enriched.sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      return new Response(JSON.stringify({ users: enriched, pendings: pendings || [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "activate" || action === "deactivate") {
      const { user_id, plan } = body;
      if (!user_id) {
        return new Response(JSON.stringify({ error: "user_id required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const status = action === "activate" ? "active" : "inactive";
      const { error } = await admin
        .from("subscriptions")
        .upsert(
          {
            user_id,
            status,
            plan: plan || "monthly",
            payment_provider: "manual_admin",
            expires_at: status === "active" ? expiryFor(plan || "monthly") : null,
            updated_at: new Date().toISOString(),
          },
          { onConflict: "user_id" },
        );
      if (error) throw error;

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "set_plan") {
      const { user_id, plan } = body;
      if (!user_id || !plan) {
        return new Response(JSON.stringify({ error: "user_id and plan required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const { error } = await admin
        .from("subscriptions")
        .upsert(
          {
            user_id,
            status: "active",
            plan,
            payment_provider: "manual_admin",
            expires_at: expiryFor(plan),
            updated_at: new Date().toISOString(),
          },
          { onConflict: "user_id" },
        );
      if (error) throw error;
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }


    if (action === "create_user") {
      const email = String(body.email || "").trim().toLowerCase();
      const password = String(body.password || "");
      const plan = String(body.plan || "monthly");
      if (!email || password.length < 6) return json({ error: "email e senha (mínimo 6 caracteres) são obrigatórios" }, 400);
      // Atenção: se a conta já existir, a senha dela é redefinida e o e-mail é confirmado.
      const existing = (await listAllUsers()).find((u) => (u.email || "").toLowerCase() === email);
      let uid: string;
      if (existing) {
        const { error } = await admin.auth.admin.updateUserById(existing.id, { password, email_confirm: true });
        if (error) throw error;
        uid = existing.id;
      } else {
        const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true });
        if (error) throw error;
        uid = data.user!.id;
      }
      const { error: subErr } = await admin.from("subscriptions").upsert(
        { user_id: uid, status: "active", plan, payment_provider: "manual_admin", expires_at: expiryFor(plan), updated_at: new Date().toISOString() },
        { onConflict: "user_id" },
      );
      if (subErr) throw subErr;
      return json({ success: true, user_id: uid, existing: !!existing });
    }

    if (action === "set_protocolo") {
      const { user_id, is_protocolo } = body;
      if (!user_id || typeof is_protocolo !== "boolean") return json({ error: "user_id e is_protocolo são obrigatórios" }, 400);
      const { error } = await admin.from("profiles").update({ is_protocolo }).eq("user_id", user_id);
      if (error) throw error;
      return json({ success: true });
    }

    if (action === "list_admins") {
      if (!(await requireOwner())) return json({ error: "Somente o dono" }, 403);
      const { data: rows, error } = await admin.from("admin_users").select("user_id, is_owner");
      if (error) throw error;
      const emails = new Map((await listAllUsers()).map((u) => [u.id, u.email]));
      return json({ admins: (rows || []).filter((r: any) => r.user_id).map((r: any) => ({ user_id: r.user_id, email: emails.get(r.user_id) || "(conta não encontrada)", is_owner: r.is_owner === true })) });
    }

    if (action === "set_admin") {
      if (!(await requireOwner())) return json({ error: "Somente o dono" }, 403);
      const { user_id, is_admin } = body;
      if (!user_id || typeof is_admin !== "boolean") return json({ error: "user_id e is_admin são obrigatórios" }, 400);
      const { data: target } = await admin.from("admin_users").select("id, is_owner").eq("user_id", user_id).maybeSingle();
      if (target?.is_owner) return json({ error: "A conta do dono não pode ser alterada aqui" }, 400);
      if (user_id === user.id) return json({ error: "Você não pode alterar a própria administração" }, 400);
      if (is_admin) {
        if (!target) {
          const { error } = await admin.from("admin_users").insert({ user_id, is_owner: false });
          if (error) throw error;
        }
      } else {
        const { error } = await admin.from("admin_users").delete().eq("user_id", user_id).eq("is_owner", false);
        if (error) throw error;
      }
      return json({ success: true });
    }

    if (action === "usage_report") {
      const users = await listAllUsers();
      const count = async (table: string, col = "user_id") => {
        const m = new Map<string, { n: number; last: string | null }>();
        const { data, error } = await admin.from(table).select(`${col}, created_at`).limit(50000);
        if (error) return m; // tabela ausente: conta zero
        for (const r of data || []) {
          const k = (r as any)[col];
          if (!k) continue;
          const cur = m.get(k) || { n: 0, last: null };
          cur.n++;
          const t = (r as any).created_at;
          if (t && (!cur.last || t > cur.last)) cur.last = t;
          m.set(k, cur);
        }
        return m;
      };
      const [mentor, search, aulas, sites, vendas, lic] = await Promise.all([
        count("mentor_ia_logs"), count("search_history"), count("user_progress"), count("user_sites"), count("sales"), count("hyperbuild_license_logs"),
      ]);
      const { data: subs } = await admin.from("subscriptions").select("user_id, status, plan");
      const { data: profs } = await admin.from("profiles").select("user_id, display_name");
      const subMap = new Map((subs || []).map((s: any) => [s.user_id, s]));
      const nameMap = new Map((profs || []).map((p: any) => [p.user_id, p.display_name]));
      const rows = users.map((u) => {
        const parts = [mentor, search, aulas, sites, vendas, lic].map((m) => m.get(u.id));
        const last = parts.map((p) => p?.last).filter(Boolean).sort().pop() || null;
        const [a, b, c, d, e, f] = parts.map((p) => p?.n || 0);
        return {
          user_id: u.id, email: u.email, display_name: nameMap.get(u.id) || null,
          plan: subMap.get(u.id)?.plan ?? null, status: subMap.get(u.id)?.status ?? null,
          created_at: u.created_at, last_sign_in_at: u.last_sign_in_at,
          mentor: a, prospeccao: b, aulas: c, sites: d, vendas: e, licencas: f, total_acoes: a + b + c + d + e + f, ultima_atividade: last,
        };
      });
      return json({ rows });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("admin-manage-users error:", err);
    return new Response(JSON.stringify({ error: err.message || "Internal error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
