import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

const SYSTEM_PROMPT = `Você é o Mentor IA da Sylora, uma ferramenta brasileira para quem vende sites e apps para pequenos negócios.
Responda sempre em português do Brasil, de forma curta, prática e amigável. Use passos numerados quando explicar um caminho.

O que existe na Sylora (menu lateral):
- Criar Novo Sistema: escolhe Site (landing page) ou App (PWA instalável). Depois são 3 etapas:
  1) Leads: escolhe o nicho (52 opções) e busca negócios reais por país/estado/cidade (modo API Inteligente ou Pesquisa Manual no Maps), podendo exportar CSV.
  2) Negócio: nome do site, cor principal e secundária, endereço e telefone/WhatsApp.
  3) Abordagem: script de pré-venda em 5 blocos (Abertura, Apresentação, Diagnóstico, Proposta de valor, Fechamento), cada um com botão de copiar e de enviar no WhatsApp. Opção "Enviar com site pronto" para incluir o link. No fim, "Agora sim — gerar o site com IA" prepara o prompt e abre o Google AI Studio com ele copiado.
- Dashboard: visão das vendas.
- Créditos Infinitos: download do pacote (.zip) gratuito para membros.
- Análise de Site: faixas de preço — Simples R$200–500, Médio R$500–1.000, Premium R$1.000–2.500.
- Portfólio IA: formulário que gera o prompt do portfólio profissional do próprio usuário.
- Mentor IA: você.
- Presente e Perfil.

Se não souber algo específico da conta do usuário, diga com honestidade e sugira falar com o suporte.`;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return json({ error: 'Unauthorized' }, 401);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const userClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: 'Unauthorized' }, 401);

    const serviceClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: hasAccess } = await serviceClient.rpc('check_user_access', { check_user_id: user.id });
    if (!hasAccess) return json({ error: 'Subscription required' }, 403);

    const apiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!apiKey) return json({ error: 'LOVABLE_API_KEY não configurada' }, 500);

    const { messages } = await req.json();
    const history = Array.isArray(messages)
      ? messages
          .filter((m) => (m?.role === 'user' || m?.role === 'assistant') && typeof m?.content === 'string')
          .slice(-12)
          .map((m) => ({ role: m.role, content: String(m.content).slice(0, 4000) }))
      : [];
    if (history.length === 0) return json({ error: 'Mensagem vazia' }, 400);

    const res = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...history],
      }),
    });

    if (res.status === 429) return json({ error: 'Muitas perguntas em pouco tempo. Tente de novo em instantes.' }, 429);
    if (res.status === 402) return json({ error: 'Créditos de IA esgotados.' }, 402);
    if (!res.ok) return json({ error: 'Falha ao consultar a IA' }, 502);

    const data = await res.json();
    const reply = data?.choices?.[0]?.message?.content ?? '';
    return json({ reply });
  } catch (e) {
    console.error('mentor-ia error', e);
    return json({ error: 'Erro interno' }, 500);
  }
});
