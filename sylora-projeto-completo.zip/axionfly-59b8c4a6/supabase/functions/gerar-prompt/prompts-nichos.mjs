const nicheTemplates = {
    barbearia: {
        label: " Barbearia",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma barbearia chamada "${name}". Visual premium e sofisticado com um fundo elegante que harmonize com a paleta escolhida, acentos em ${primary || "dourado (gold gradient)"}. Cor secundária: ${secondary || "cinza escuro"}. Use a fonte Playfair Display para títulos e Raleway para corpo de texto. Seções: Hero fullscreen com imagem de barbearia premium e título "Estilo & Tradição" com gradiente ${primary || "dourado"}, botão "Agende seu Horário". Seção "Nossos Serviços" com 3 cards (Corte Masculino R$60, Barba R$45, Tratamento Capilar R$80 — cada um com imagem, descrição e preço). Seção "Sobre Nós" com texto sobre tradição e excelência, com estatísticas (15+ anos de experiência, 10.000+ clientes atendidos, 5 barbeiros especialistas, nota 4.9 de avaliação). Seção "Contato" com informações (endereço, telefone, horário de funcionamento e formulário). Footer simples. Animações suaves com framer-motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    pizzaria: {
        label: " Pizzaria",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma pizzaria chamada "${name}". Visual quente e acolhedor com um fundo sofisticado que maximize o contraste com as cores primárias, acentos em ${primary || "vermelho queimado"} e ${secondary || "laranja"}. Use fontes display bold para títulos e uma fonte corpo clean. Seções: Hero com imagem de pizza artesanal saindo do forno, seção "Cardápio" com cards de pizzas (Margherita, Pepperoni, Quatro Queijos, Calabresa — com preço e descrição), seção "Sobre Nós" contando a história da pizzaria com estatísticas (anos de tradição, pizzas por mês, avaliações 5 estrelas), seção "Contato" com endereço, telefone, horário de funcionamento e formulário de pedido/reserva. Footer simples. Animações suaves com framer-motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "fine-dining": {
        label: " Restaurante Fine Dining",
        buildPrompt: (name, primary, secondary, features) => `Crie um site de restaurante fine dining chamado "${name}" com tema escuro (fundo #1a1410), acentos ${primary || "dourados"}, cor secundária ${secondary || "bordô"}, tipografia Cormorant Garamond + Raleway. Seções: hero fullscreen com imagem do restaurante, cardápio com pratos alternados (filé, pasta, sobremesa) com fotos e preços, sobre com foto do chef e estatísticas (anos, clientes, avaliação), contato com reservas/endereço/horário, navbar fixa com blur e botão de reserva, footer elegante. Divisores dourados em gradiente entre seções. Animações suaves com framer-motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "restaurante-bairro": {
        label: " Restaurante de Bairro",
        buildPrompt: (name, primary, secondary, features) => `Crie um site de restaurante de bairro acolhedor chamado '${name}'. Tons ${primary || "terrosos (terracotta, amarelo quente, creme)"}, cor secundária ${secondary || "amarelo quente"}, tipografia Merriweather + Open Sans. Hero com fachada do restaurante, badge 'desde 1998', botões de cardápio e WhatsApp. Cardápio com cards de feijoada/picanha/moqueca com fotos, estrelas, tags e preços. Seção sobre com foto do interior rústico, história da fundadora e ícones (tradição, família, caseiro, amor). Contato com telefone, WhatsApp, endereço e horário. Footer simples. Estilo casual, emojis, linguagem calorosa.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    clinica: {
        label: " Clínica Odontológica",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para clínica odontológica chamado '${name}'. Use ${primary || "azul claro"} como cor primária, ${secondary || "verde-água"} como accent, um fundo limpo que destaque a paleta profissional escolhida, tipografia Plus Jakarta Sans. Faça um hero split com texto à esquerda e foto do consultório à direita, com badges de biossegurança, CRO e horários flexíveis. Seção de serviços com cards contendo foto e ícone para clareamento dental, ortodontia invisível e implantes dentários, mais um grid de serviços extras (limpeza, odontopediatria, scanner 3D). Seção sobre a dentista com foto profissional, CRO, formação USP/UNICAMP, e estatísticas (pacientes, avaliação). Seção de depoimentos de pacientes com estrelas e iniciais. Seção de contato com botões de WhatsApp, telefone e Instagram, mais endereço e horário. Navbar fixa com logo e botão de agendar. Footer com CRO. Design profissional, limpo e que transmita confiança.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    petshop: {
        label: " Pet Shop",
        buildPrompt: (name, primary, secondary, features) => `Crie um site de pet shop chamado "${name}" com estética vibrante, acolhedora e playful. Paleta de cores quentes baseada em ${primary || "coral (#E8734A)"} como cor primária e ${secondary || "âmbar dourado (#E8A644)"} como secundária, com acentos em rosa, azul, verde, amarelo e lavanda sobre um fundo acolhedor em tom suave que harmonize com a paleta claro. Tipografia Fredoka (display/headings — arredondada e divertida) + Nunito (body — limpa e legível). Bordas bem arredondadas. Animações com Framer Motion. Estrutura: Navbar fixa com blur, logo com ícone de cachorro, carrinho com badge. Hero full-height com grid 2 colunas (texto + imagem com badges flutuantes). Seção Serviços com 6 cards. Seção Produtos com 4 cards. Seção Depoimentos com 3 cards. CTA com gradiente e patinhas flutuantes. Footer escuro com 4 colunas. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    sobrancelhas: {
        label: " Design de Sobrancelhas",
        buildPrompt: (name, primary, secondary, features) => `Crie um site one-page para um estúdio de design de sobrancelhas chamado "${name}". Visual elegante e feminino com tons de ${primary || "creme e dourado"} e ${secondary || "rosé"}. Use Playfair Display para títulos e Raleway para corpo de texto. Seções: Navbar fixa com logo, links (Serviços, Sobre, Contato) e botão "Agendar". Hero com imagem de fundo de um salão de beleza luxuoso, título "Design de Sobrancelhas", subtítulo e botão CTA. Serviços com 3 cards: Microblading (R$350), Design Personalizado (R$80) e Micropigmentação (R$450). Sobre com texto sobre 8+ anos de experiência, estatísticas. Contato com cards de WhatsApp, Instagram, Endereço e Horário. Footer elegante. Design responsivo com animações suaves.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    mecanica: {
        label: " Mecânica Automotiva",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para uma mecânica automotiva chamada "${name}". Tema escuro industrial com acentos em ${primary || "âmbar/laranja"}, cor secundária ${secondary || "cinza escuro"}. Tipografia Oswald para títulos e Inter para corpo. Animações suaves com Framer Motion. Inclui: navbar fixa, hero fullscreen com imagem de oficina, seção de 6 serviços, seção Sobre Nós com estatísticas, formulário de contato e rodapé. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    hamburgueria: {
        label: " Hamburgueria",
        buildPrompt: (name, primary, secondary, features) => `Crie um site one-page premium para uma hamburgueria chamada "${name}", com visual impactante, moderno e apetitoso, estilo editorial urbano com clima noturno. Paleta com um fundo que harmonize com os tons ${primary || "âmbar e laranja queimado"}, ${secondary || "cobre e neutros elegantes"}. Tipografia marcante. Seções: Header fixo, Hero com título grande e CTAs, Cardápio com 6 cards elegantes, Seção Sobre, Estatísticas, CTA forte, Contato e Footer. Animações suaves. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    acaiteria: {
        label: " Açaiteria",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma açaiteria chamada "${name}". Estética tropical e vibrante com paleta baseada em ${primary || "roxo profundo do açaí"}, ${secondary || "verde amazônico"} e dourado como acento. Tipografia Playfair Display para títulos e DM Sans para corpo. Seções: Hero, Cardápio com 3 cards de produtos, Sobre nós com estatísticas, Contato. Footer elegante. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    lavarapido: {
        label: " Lava-Rápido",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para um lava-rápido premium chamado "${name}". Tema escuro e sofisticado com acentos em ${primary || "azul neon e ciano"}, cor secundária ${secondary || "cinza escuro metálico"}. Seções: Navbar fixa, Hero fullscreen, Seção Serviços com 6 cards, Seção Planos & Preços com 3 cards, Seção Contato, Footer. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    vidracaria: {
        label: " Vidraçaria",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma vidraçaria chamada "${name}". Visual moderno, limpo e sofisticado, transmitindo transparência e precisão. Paleta com acentos em ${primary || "azul cristal"} e ${secondary || "cinza grafite"}, sobre fundo claro ou escuro elegante com efeitos sutis de vidro (glassmorphism discreto). Tipografia forte e geométrica. Seções: Navbar fixa com botão "Pedir Orçamento", Hero fullscreen com imagem de box de vidro ou fachada espelhada e headline forte, Seção Serviços com 6 cards (box para banheiro, espelhos sob medida, portas e janelas de vidro, fachadas e peles de vidro, tampos de mesa, manutenção e troca de vidros), Seção "Antes e Depois" ou Galeria de obras, Seção Sobre com estatísticas (anos de experiência, projetos entregues, avaliação), Seção de Depoimentos, Seção Contato com formulário de orçamento e botão WhatsApp. Footer completo. Animações suaves com Framer Motion. Design responsivo mobile-first.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    assistencia: {
        label: " Assistência Técnica",
        buildPrompt: (name, primary, secondary, features) => `Crie um site de uma página para uma assistência técnica de celulares e computadores chamada "${name}". Tema escuro com acentos em ${primary || "azul elétrico"} e ${secondary || "verde-azulado"}. Seções: Header fixo, Hero com imagem de bancada, Seção Serviços com 8 cards, Seção Sobre Nós com estatísticas, Seção Contato com formulário. Footer minimalista. Animações com Framer Motion, glassmorphism. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    academia: {
        label: " Academia",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma academia chamada "${name}". Tema escuro e energético com acentos em ${primary || "vermelho e laranja"}, cor secundária ${secondary || "cinza escuro"}. Seções: Navbar fixa, Hero fullscreen, Seção Modalidades com cards, Seção Planos com 3 opções, Seção Sobre, Contato e Footer. Animações com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    advogado: {
        label: " Escritório de Advocacia",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para um escritório de advocacia chamado "${name}". Visual sóbrio e profissional com fundo escuro, acentos em ${primary || "dourado"} e ${secondary || "azul marinho"}. Seções: Navbar fixa, Hero, Áreas de Atuação com cards, Seção Sobre com estatísticas, Depoimentos, Contato e Footer elegante. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    imobiliaria: {
        label: " Imobiliária",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma imobiliária chamada "${name}". Visual moderno e sofisticado com fundo claro, acentos em ${primary || "azul escuro"} e ${secondary || "dourado"}. Seções: Navbar fixa, Hero com busca de imóveis, Seção Destaques com 4 cards de imóveis, Seção Serviços, Seção Sobre com estatísticas, Contato e Footer. Animações suaves. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    salaobeleza: {
        label: " Salão de Beleza",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para um salão de beleza chamado "${name}". Visual elegante e feminino com tons de ${primary || "rosa e dourado"}, cor secundária ${secondary || "nude e creme"}. Seções: Navbar fixa, Hero, Seção Serviços com cards, Seção Sobre, Depoimentos, Contato e Footer elegante. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    contabilidade: {
        label: " Contabilidade",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para um escritório de contabilidade chamado "${name}". Visual profissional e confiável com fundo escuro, acentos em ${primary || "verde escuro"} e ${secondary || "azul"}. Seções: Navbar fixa, Hero, Seção Serviços com cards, Seção Sobre com estatísticas, Depoimentos, Contato e Footer. Animações suaves. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    estetica: {
        label: " Estética / Depilação",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para um estúdio de depilação e estética chamado "${name}". Paleta de tons de creme (#f7f3ed fundo), ${primary || "dourado (hsl 38° 45% 60%)"} como acento, ${secondary || "charcoal escuro"} para texto. Fontes Playfair Display (headings) + Raleway (body). Glass cards com backdrop-blur. Seções: Navbar fixa, Hero fullscreen, Seção Serviços com cards, Seção Preços com 3 planos, Depoimentos, Contato e Footer elegante. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    marmitaria: {
        label: " Marmitaria",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma marmitaria chamada "${name}". Visual acolhedor e caseiro com fundo claro, tons de ${primary || "verde natural e terracota"}, cor secundária ${secondary || "amarelo quente"}. Seções: Navbar com logo, Hero com tag " Comida de verdade, feita com amor", Seção Cardápio com cards de marmitas, Seção Sobre com diferenciais, Seção Contato com formulário e Footer simples. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    idiomas: {
        label: " Escola de Idiomas",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma escola de idiomas chamada "${name}". Visual moderno e educacional com fundo claro, acentos em ${primary || "azul vibrante"} e ${secondary || "verde-esmeralda"}. Seções: Navbar, Hero com badge " Matrículas abertas 2026", Seção Cursos com cards de Inglês e Espanhol, Seção Sobre com 6 diferenciais, Seção Depoimentos, Seção Preços com 3 planos e Footer. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    fotografo: {
        label: " Fotógrafo",
        buildPrompt: (name, primary, secondary, features) => `Crie um site portfolio para um fotógrafo chamado "${name}". Visual minimalista e artístico com fundo escuro, acentos em ${primary || "branco e cinza claro"}, cor secundária ${secondary || "cinza escuro"}. Seções: Navbar minimalista com iniciais, Hero fullscreen com título "Fotografia Autoral" e botão "Ver Portfolio", Galeria com grid de 6 categorias (Paisagens, Urbano, Casamentos, Arquitetura, Fashion, Documental), Seção Sobre com estatísticas (projetos, anos, prêmios), Seção Contato com formulário e links de redes sociais, Footer elegante. Tipografia fina e espaçosa. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "marketing-digital": {
        label: " Marketing Digital",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma agência de marketing digital chamada "${name}". Visual moderno e profissional com fundo escuro, acentos em ${primary || "azul elétrico"} e ${secondary || "roxo vibrante"}. Seções: Navbar fixa com botão "Fale Conosco", Hero com badge "Transforme seu negócio digital" e título "Marketing Digital que Converte", Seção Serviços com 6 cards (SEO, Tráfego Pago, Branding, Social Media, Email Marketing, Analytics), Estatísticas (350+ clientes, 12M+ leads, 98% satisfação, 5x ROI), Seção Depoimentos com 3 clientes, CTA "Pronto para escalar?" com botão de consultoria gratuita, Footer com links sociais. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "artes-marciais": {
        label: " Academia de Artes Marciais",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma academia de artes marciais chamada "${name}". Tema escuro e agressivo com acentos em ${primary || "vermelho sangue"} e ${secondary || "cinza escuro"}. Tipografia Oswald condensada para títulos uppercase. Seções: Navbar fixa com botão "AULA GRÁTIS", Hero fullscreen com título "FORJE SEU ESPÍRITO DE LUTA", Seção Modalidades com 4 cards (Boxe, Muay Thai, Jiu-Jitsu, MMA), Estatísticas (500+ alunos, 15+ anos, 8 professores, 30+ campeões), Seção Planos com 3 opções (Básico, Premium, Black), CTA com botão pulsante, Footer minimalista. Animações intensas com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    papelaria: {
        label: " Papelaria / Artesanato",
        buildPrompt: (name, primary, secondary, features) => `Crie um site landing page para uma papelaria artesanal chamada "${name}". Visual delicado e feminino com fundo claro (creme/off-white), acentos em ${primary || "rosa suave"} e ${secondary || "verde-menta"}. Tipografia elegante e leve. Seções: Navbar com logo e links (Início, Produtos, Categorias, Sobre, Contato), Hero com título "A beleza está nos detalhes" e botões "Ver Coleção" e "Nossa História", Seção Produtos com 6 cards de itens com preços e tags (Novo, Popular, Oferta), Seção Categorias com 6 cards, Seção Sobre com história e diferenciais (Sustentável, Entrega Rápida, Qualidade), Newsletter, Footer com 3 colunas. Animações suaves com Framer Motion. Design responsivo.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    manicure: {
        label: " Manicure",
        buildPrompt: (name, primary, secondary, features) => `Crie um site one-page para um estúdio de manicure chamado "${name}". Visual delicado e moderno com fundo claro (off-white), acentos em ${primary || "rosa suave"} e ${secondary || "dourado rosé"}. Tipografia elegante. Seções: Navbar fixa, Hero com título sobre cuidado das unhas, Serviços (esmaltação em gel, alongamento, spa dos pés, nail art) com preços, Galeria com fotos de unhas, Sobre, Contato com agendamento. Footer simples. Animações suaves.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    dentista: {
        label: " Dentista",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para consultório odontológico chamado "${name}". Visual limpo e profissional com um fundo limpo que destaque a paleta profissional escolhida, acentos em ${primary || "azul sereno"} e ${secondary || "verde-água"}. Tipografia Plus Jakarta Sans. Seções: Hero split com badge de CRO, Serviços (clareamento, ortodontia invisível, implantes, limpeza) com cards, Sobre com formação, Depoimentos, Contato com WhatsApp e botão de agendamento. Design que transmite confiança.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    restaurante: {
        label: " Restaurante",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para um restaurante chamado "${name}". Visual acolhedor e apetitoso com um fundo que harmonize com os tons ${primary || "terrosos"} e ${secondary || "dourado"}. Tipografia clássica + sans moderna. Seções: Hero com fachada, Cardápio com pratos principais, Sobre com história, Reservas, Contato com endereço, telefone e horário. Footer elegante. Animações suaves.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    padaria: {
        label: " Padaria",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para uma padaria artesanal chamada "${name}". Visual quente e caseiro com um fundo acolhedor em tom suave que harmonize com a paleta, acentos em ${primary || "marrom dourado"} e ${secondary || "amarelo trigo"}. Tipografia clássica. Seções: Hero com pães saindo do forno, Produtos (pães, bolos, doces, salgados) com fotos e preços, Sobre com tradição, Encomendas, Contato com endereço e horário. Footer simples.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    farmacia: {
        label: " Farmácia",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para uma farmácia chamada "${name}". Visual clean e confiável com um fundo limpo e profissional, acentos em ${primary || "verde saúde"} e ${secondary || "azul"}. Tipografia limpa. Seções: Hero com proposta de atendimento humanizado, Serviços (entrega, manipulação, vacinas, aferição), Sobre, Contato com WhatsApp, endereço e horário. Footer simples e profissional.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    otica: {
        label: " Ótica",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para uma ótica chamada "${name}". Visual moderno e sofisticado com fundo claro, acentos em ${primary || "azul profundo"} e ${secondary || "dourado"}. Tipografia elegante. Seções: Hero com modelos de óculos, Coleções (solar, grau, infantil, esportivo) com cards, Serviços (exame de vista, ajuste, garantia), Sobre, Contato com endereço e horário. Footer elegante.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    floricultura: {
        label: " Floricultura",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para uma floricultura chamada "${name}". Visual delicado e colorido com fundo claro, acentos em ${primary || "rosa floral"} e ${secondary || "verde folha"}. Tipografia romântica + sans. Seções: Hero com buquês, Produtos (buquês, arranjos, plantas, cestas) com fotos e preços, Entregas, Sobre, Contato com WhatsApp e endereço. Footer com redes sociais.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "estetica-corporal": {
        label: " Clínica de Estética",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para clínica de estética chamada "${name}". Visual clean, luxuoso e relaxante. Tons de ${primary || "dourado suave"} e ${secondary || "branco marfim"}. Tipografia serifada elegante. Seções: Hero com imagem de spa, Tratamentos (corporal, facial, massagens) com cards detalhados, Sobre com foco em bem-estar, Depoimentos de clientes, Contato com agendamento. Design zen e profissional.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    nutricionista: {
        label: " Nutricionista",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para nutricionista chamado "${name}". Visual saudável e equilibrado. Tons de ${primary || "verde folha"} e ${secondary || "branco"}. Tipografia moderna e legível. Seções: Hero com foco em saúde, Serviços (planos alimentares, bioimpedância, acompanhamento), Sobre com formação e especialidades, Depoimentos, Blog/Dicas, Contato com agendamento. Design que transmite vitalidade.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    psicologo: {
        label: " Psicólogo / Terapeuta",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para psicólogo chamado "${name}". Visual acolhedor, seguro e profissional. Tons de ${primary || "azul sereno"} e ${secondary || "cinza claro"}. Tipografia clássica e calma. Seções: Hero com foco em acolhimento, Áreas de Atuação (ansiedade, depressão, casal), Sobre com abordagem clínica, FAQ, Contato com botão para consulta. Design que transmite paz e confiança.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "personal-trainer": {
        label: " Personal Trainer",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para personal trainer chamado "${name}". Visual energético, motivador e forte. Tons de ${primary || "preto e amarelo"} ou ${secondary || "laranja"}. Tipografia bold e impactante. Seções: Hero com foco em transformação, Programas de Treino, Sobre com conquistas e método, Resultados de alunos, Contato com formulário. Design dinâmico e focado em performance.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    fisioterapeuta: {
        label: " Fisioterapeuta",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para fisioterapeuta chamado "${name}". Visual clínico e regenerativo. Tons de ${primary || "ciano"} e ${secondary || "branco"}. Tipografia limpa e técnica. Seções: Hero com foco em recuperação, Especialidades (RPG, Pilates, Reabilitação), Sobre com formação acadêmica, Depoimentos de recuperação, Contato com agendamento. Design profissional e focado em saúde corporal.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    buffet: {
        label: " Buffet / Eventos",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para buffet e eventos chamado "${name}". Visual festivo, elegante e organizado. Tons de ${primary || "dourado"} e ${secondary || "preto ou branco"}. Tipografia sofisticada. Seções: Hero com festa luxuosa, Nossos Cardápios, Espaços, Sobre com anos de experiência, Galeria de Eventos realizados, Orçamento. Design que celebra momentos especiais.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "escola-musica": {
        label: " Escola de Música",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para escola de música chamada "${name}". Visual artístico e inspirador. Tons de ${primary || "azul marinho"} e ${secondary || "dourado ou branco"}. Tipografia moderna. Seções: Hero com instrumentos, Cursos (violão, piano, canto, bateria), Sobre com professores, Vídeos de apresentações, Planos, Contato. Design vibrante e melódico.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    veterinaria: {
        label: " Clínica Veterinária",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para clínica veterinária chamada "${name}". Visual amigável e confiável. Tons de ${primary || "verde água"} e ${secondary || "branco"}. Tipografia arredondada. Seções: Hero com pets felizes, Serviços (cirurgia, vacinas, exames), Sobre com equipe dedicada, Dicas Pet, Contato com emergência destacada. Design que transmite amor pelos animais.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    dedetizadora: {
        label: " Dedetizadora",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para dedetizadora chamada "${name}". Visual técnico e eficiente. Tons de ${primary || "amarelo e preto"} (segurança). Tipografia industrial forte. Seções: Hero com foco em ambiente limpo, Pragas atendidas (cupins, baratas, ratos), Sobre com certificados, Processo de dedetização, Contato com orçamento rápido. Design que transmite segurança e higiene.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    chaveiro: {
        label: " Chaveiro",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para chaveiro chamado "${name}". Visual de urgência e confiança. Tons de ${primary || "azul elétrico"} e ${secondary || "branco"}. Tipografia direta e clara. Seções: Hero com botão "Chamar Agora", Serviços (residencial, automotivo, cofres), Sobre com tempo de chegada, Contato com mapa. Design mobile-first focado em atendimento rápido.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    arquiteto: {
        label: " Arquiteto / Designer",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para arquiteto/designer chamado "${name}". Visual minimalista, estrutural e premium. Tons de ${primary || "cinza espacial"} e ${secondary || "branco"}. Tipografia arquitetônica. Seções: Hero com projeto autoral, Portfolio (residencial, comercial), Sobre com visão estética, Processo criativo, Contato. Design elegante com muito espaço em branco.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    eletricista: {
        label: " Eletricista",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para eletricista chamado "${name}". Visual técnico e seguro. Tons de ${primary || "azul e amarelo"} ou ${secondary || "cinza"}. Tipografia clara. Seções: Hero com foco em segurança elétrica, Serviços (instalações, reparos, painéis), Sobre com certificações, Contato com botão de emergência. Design focado em utilidade e confiança.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    encanador: {
        label: " Encanador",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para encanador chamado "${name}". Visual de serviço rápido e limpo. Tons de ${primary || "azul água"} e ${secondary || "branco"}. Tipografia direta. Seções: Hero com foco em solução de problemas, Serviços (vazamentos, pias, encanamento geral), Sobre com experiência, Contato com WhatsApp. Design funcional e direto.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    pintor: {
        label: " Pintor de Obras",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para pintor chamado "${name}". Visual colorido e de acabamento fino. Tons de ${primary || "vibrantes"} e ${secondary || "branco"}. Tipografia amigável. Seções: Hero com transformação de ambientes, Serviços (pintura interna, externa, texturas), Sobre com portfólio de obras, Contato com orçamento. Design que valoriza o visual renovado.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    despachante: {
        label: " Despachante",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para despachante chamado "${name}". Visual burocrático porém ágil e moderno. Tons de ${primary || "azul marinho"} e ${secondary || "dourado"}. Tipografia séria. Seções: Hero com foco em agilidade, Serviços (documentação veicular, multas, CNH), Sobre com anos de atuação, Consulta de débitos, Contato. Design que transmite seriedade e facilidade.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "saude-mental": {
        label: " Clínica de Saúde Mental",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para clínica de saúde mental chamada "${name}". Visual extremamente acolhedor e leve. Tons de ${primary || "lavanda ou verde menta"} e ${secondary || "creme"}. Tipografia suave. Seções: Hero com mensagem de acolhimento, Especialidades (psiquiatria, psicologia, terapias), Sobre com foco humanizado, FAQ, Contato para primeira consulta. Design focado em tranquilidade.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "cuidador-idosos": {
        label: " Cuidador de Idosos",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para serviço de cuidador de idosos chamado "${name}". Visual amoroso, seguro e dedicado. Tons de ${primary || "azul suave"} e ${secondary || "rosa claro"}. Tipografia clara e legível. Seções: Hero com imagem de cuidado carinhoso, Serviços (acompanhamento, cuidados médicos, lazer), Sobre com equipe qualificada, Depoimentos de famílias, Contato. Design que transmite carinho e segurança.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    "produtos-naturais": {
        label: " Produtos Naturais",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para loja de produtos naturais chamada "${name}". Visual orgânico e saudável. Tons de ${primary || "verde terra"} e ${secondary || "bege"}. Tipografia natural. Seções: Hero com cesta de produtos frescos, Categorias (grãos, suplementos, orgânicos), Sobre com foco em sustentabilidade, Benefícios de uma vida natural, Contato e Loja. Design eco-friendly.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    pilates: {
        label: " Studio de Pilates",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para studio de pilates chamado "${name}". Visual equilibrado e flexível. Tons de ${primary || "cinza suave"} e ${secondary || "azul claro"}. Tipografia clean. Seções: Hero com foco em postura e força, Modalidades (aparelhos, solo, gestantes), Sobre com benefícios do método, Planos e Horários, Contato. Design que inspira movimento e saúde.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
    quiropraxia: {
        label: " Quiropraxia / Acupuntura",
        buildPrompt: (name, primary, secondary, features) => `Crie um site para clínica de quiropraxia/acupuntura chamada "${name}". Visual medicinal e de alívio. Tons de ${primary || "azul petróleo"} e ${secondary || "branco"}. Tipografia técnica mas acessível. Seções: Hero com foco em alívio de dores, Especialidades (quiropraxia, acupuntura, ventosaterapia), Sobre com foco em coluna e nervos, Depoimentos de alívio, Contato com agendamento. Design profissional e reparador.${features ? ` Funcionalidades extras: ${features}.` : ""}`,
    },
};
const fontOptions = [
    { value: "playfair-raleway", label: "Playfair Display + Raleway", desc: "Clássico e elegante" },
    { value: "inter-space", label: "Inter + Space Grotesk", desc: "Moderno e limpo" },
    { value: "poppins-dm", label: "Poppins + DM Sans", desc: "Amigável e atual" },
    { value: "oswald-roboto", label: "Oswald + Roboto", desc: "Forte e industrial" },
    { value: "cormorant-lato", label: "Cormorant Garamond + Lato", desc: "Sofisticado e premium" },
    { value: "fredoka-nunito", label: "Fredoka + Nunito", desc: "Divertido e arredondado" },
    { value: "montserrat-opensans", label: "Montserrat + Open Sans", desc: "Versátil e profissional" },
];
const designStyles = [
    {
        value: "conversao",
        label: " Design de Conversão",
        desc: "Página única focada em uma ação (CTA). Ideal para infoprodutos, serviços e promoções.",
        prompt: "Estilo landing page de conversão: foco total em um único CTA principal, estrutura vertical sem menus complexos, com depoimentos, benefícios claros, prova social e preços destacados. Eliminar distrações para maximizar conversão.",
    },
    {
        value: "catalogo",
        label: " Catálogo / E-commerce Clean",
        desc: "Visualização de produtos com fotos de alta qualidade e navegação intuitiva.",
        prompt: "Estilo catálogo/e-commerce limpo: priorizar visualização dos produtos com fotos grandes e fundos neutros, navegação intuitiva com filtros e categorias bem visíveis, grid de produtos organizado.",
    },
    {
        value: "local-first",
        label: " Local-First (Geolocalização)",
        desc: "Informações práticas em destaque: mapa, 'Como chegar', horário e telefone.",
        prompt: "Estilo local-first: colocar informações práticas em primeiro plano (mapa de localização, botão 'Como Chegar', horário de funcionamento, telefone clicável). Design extremamente rápido e mobile-first.",
    },
    {
        value: "institucional",
        label: " Institucional Moderno",
        desc: "Transmite autoridade e profissionalismo com seção 'Quem Somos' e cores sólidas.",
        prompt: "Estilo institucional moderno: passar autoridade e profissionalismo com estrutura organizada, fotos da equipe, seção 'Quem Somos' detalhada, cores sólidas, fontes serifadas para transmitir confiança e tradição.",
    },
    {
        value: "lifestyle",
        label: " Visual / Estético (Lifestyle)",
        desc: "Foca em vender experiência e estilo de vida com fotos ambientadas.",
        prompt: "Estilo visual/lifestyle: foco em vender uma experiência e estilo de vida, menos texto e mais imagens ambientadas e vídeos em tela cheia. Design elegante com margens amplas e tipografia refinada.",
    },
    {
        value: "cardapio-digital",
        label: " Cardápio Digital / Reservas",
        desc: "Grids organizados, fotos dos pratos, preços destacados e integração com agendamento.",
        prompt: "Estilo cardápio digital: facilitar escolhas rápidas com grids organizados, fotos dos pratos/serviços, preços bem destacados, integração direta com sistema de pagamento ou agendamento online.",
    },
];
const siteObjectives = [
    { value: "leads", label: " Gerar Leads", desc: "Captar contatos e potenciais clientes" },
    { value: "vendas", label: " Vender Produtos/Serviços", desc: "Levar o visitante a comprar" },
    { value: "portfolio", label: " Portfólio", desc: "Mostrar trabalhos e projetos realizados" },
    { value: "institucional", label: " Institucional", desc: "Apresentar a empresa e gerar confiança" },
];
const toneOptions = [
    { value: "formal", label: " Formal", desc: "Sério, profissional e corporativo" },
    { value: "amigavel", label: " Amigável", desc: "Próximo, caloroso e acessível" },
    { value: "criativo", label: " Criativo", desc: "Ousado, divertido e inovador" },
    { value: "autoritario", label: " Autoritário", desc: "Especialista, confiante e direto" },
];
const pageOptions = [
    { value: "inicio", label: "Início" },
    { value: "sobre", label: "Sobre Nós" },
    { value: "servicos", label: "Serviços" },
    { value: "depoimentos", label: "Depoimentos" },
    { value: "faq", label: "FAQ" },
    { value: "blog", label: "Blog" },
    { value: "galeria", label: "Galeria de Fotos" },
    { value: "precos", label: "Preços / Planos" },
];
const ctaOptions = [
    { value: "whatsapp", label: " Enviar WhatsApp", desc: "Redireciona para conversa no WhatsApp" },
    { value: "checkout", label: " Ir para Checkout", desc: "Leva direto para a página de pagamento" },
    { value: "formulario", label: " Preencher Formulário", desc: "Abre um formulário de contato/orçamento" },
    { value: "agendar", label: " Agendar Horário", desc: "Leva para agendamento online" },
    { value: "ligar", label: " Ligar Agora", desc: "Inicia uma ligação telefônica" },
];
const sloganSuggestions = {
    barbearia: ["Estilo & Tradição", "Onde o corte vira arte", "Seu visual, nossa missão", "A navalha da confiança", "Mais que um corte, uma experiência"],
    pizzaria: ["Sabor que conquista", "Direto do forno pro coração", "A fatia perfeita existe", "Tradição em cada mordida", "Pizza feita com paixão"],
    "fine-dining": ["Sabores que contam histórias", "Uma experiência além do paladar", "Onde a arte encontra a gastronomia", "Excelência em cada detalhe"],
    "restaurante-bairro": ["Comida de verdade, feita com amor", "O sabor de se sentir em casa", "Tempero de família", "Aqui todo mundo é de casa"],
    clinica: ["Seu sorriso em boas mãos", "Cuidado que transforma sorrisos", "Tecnologia e confiança para o seu sorriso", "Saúde bucal com excelência"],
    petshop: ["Amor em cada patinha", "Seu pet merece o melhor", "Cuidado que faz o rabo abanar", "O paraíso do seu pet"],
    sobrancelhas: ["O olhar que encanta", "Beleza nos mínimos detalhes", "Realce o que você tem de melhor", "Design que transforma"],
    mecanica: ["Confiança embaixo do capô", "Seu carro em boas mãos", "Performance e segurança garantidas", "A solução que você precisa"],
    hamburgueria: ["Sabor sem limites", "O smash que vicia", "Feito na brasa, com alma", "Aqui o burger é levado a sério"],
    acaiteria: ["Energia pura da Amazônia", "Sabor tropical, alma brasileira", "Açaí do jeito que você merece", "Refrescância que dá energia"],
    lavarapido: ["Brilho que impressiona", "Seu carro como novo, sempre", "Cuidado premium pro seu veículo", "Limpeza que você vê e sente"],
    assistencia: ["Tecnologia que volta a funcionar", "Conserto rápido, confiança total", "Seu dispositivo em boas mãos", "A solução tech que você precisa"],
    vidracaria: ["Vidros sob medida com perfeição", "Transparência e qualidade em cada projeto", "O vidro certo para o seu ambiente", "Precisão que você enxerga"],
    academia: ["Supere seus limites", "Transforme corpo e mente", "O treino que muda sua vida", "Força, foco e resultado"],
    advogado: ["Justiça com estratégia", "Seu direito, nossa luta", "Advocacia de resultado", "Confiança e competência jurídica"],
    imobiliaria: ["O lar dos seus sonhos te espera", "Seu novo endereço começa aqui", "Realizando sonhos em cada chave", "Imóveis que combinam com você"],
    salaobeleza: ["Beleza que transforma", "Realce a sua essência", "Seu momento de brilhar", "Beleza com personalidade"],
    contabilidade: ["Números que fazem sentido", "Seu negócio em boas contas", "Contabilidade inteligente", "Resultados que você pode contar"],
    estetica: ["Beleza é cuidar de si", "Sua melhor versão começa aqui", "Estética com resultado real", "Cuide-se, você merece"],
    marmitaria: ["Comida de verdade, feita com amor", "Sabor caseiro todo dia", "Sua refeição, nossa dedicação", "Tempero de mãe, praticidade de chef"],
    idiomas: ["O mundo fala, você também", "Fluência que abre portas", "Seu futuro é bilíngue", "Aprenda o idioma da oportunidade"],
    fotografo: ["Momentos que duram para sempre", "A arte de contar histórias em imagens", "Cada clique, uma emoção", "Fotografia que eterniza"],
    "marketing-digital": ["Resultados que você pode medir", "Marketing que converte de verdade", "Seu negócio no topo digital", "Estratégia + criatividade = resultado"],
    "artes-marciais": ["Forje seu espírito de luta", "Disciplina que transforma", "Supere-se a cada round", "Força interior, poder exterior"],
    papelaria: ["A beleza está nos detalhes", "Criatividade em cada página", "Papelaria que inspira", "Sua história merece ser escrita com estilo"],
    "estetica-corporal": ["Realce sua beleza natural", "Seu momento de cuidado e bem-estar", "Excelência em estética corporal", "Transforme sua autoestima"],
    nutricionista: ["Saúde através da alimentação", "Nutrição com equilíbrio e prazer", "Seu corpo, sua melhor versão", "Comer bem para viver melhor"],
    psicologo: ["Cuidado com a sua mente", "Um espaço seguro para você", "Equilíbrio emocional e bem-estar", "Sua saúde mental em primeiro lugar"],
    "personal-trainer": ["Transforme seu corpo e mente", "Treino focado em seus objetivos", "Supere seus limites", "Saúde e performance personalizada"],
    fisioterapeuta: ["Recupere seu movimento", "Saúde e reabilitação física", "Vida sem dor e com mais equilíbrio", "Cuidado especializado com seu corpo"],
    buffet: ["Momentos inesquecíveis", "O sabor do seu evento", "Transformando sonhos em festas", "Excelência em cada detalhe do seu buffet"],
    "escola-musica": ["Desperte o músico em você", "Aprenda música com paixão", "Onde o som ganha vida", "Educação musical de excelência"],
    veterinaria: ["Cuidado e amor pelos animais", "Saúde pet em boas mãos", "Seu melhor amigo merece o melhor cuidado", "Medicina veterinária com carinho"],
    dedetizadora: ["Ambiente livre de pragas", "Sua segurança e higiene em foco", "Soluções eficazes contra pragas", "Protegendo sua casa e sua saúde"],
    chaveiro: ["Segurança a qualquer hora", "Soluções rápidas em chaves", "Atendimento 24h com confiança", "Sua tranquilidade garantida"],
    arquiteto: ["Projetando seus sonhos", "Arquitetura com personalidade", "Espaços que contam histórias", "Design e inovação em cada traço"],
    eletricista: ["Segurança elétrica garantida", "Soluções em energia com confiança", "Seu imóvel em boas mãos", "Atendimento elétrico profissional"],
    encanador: ["Soluções rápidas em hidráulica", "Chega de vazamentos", "Seu encanamento em perfeitas condições", "Atendimento hidráulico de confiança"],
    pintor: ["Cores que transformam", "Acabamento impecável para sua obra", "Sua casa com vida nova", "Pintura profissional com qualidade"],
    despachante: ["Agilidade em seus documentos", "Documentação sem burocracia", "Sua tranquilidade veicular", "O caminho mais rápido para regularizar"],
    "saude-mental": ["Acolhimento e saúde mental", "Equilíbrio para sua vida", "Cuidado humanizado e seguro", "Sua jornada de bem-estar começa aqui"],
    "cuidador-idosos": ["Cuidado com amor e dedicação", "Segurança e carinho para quem você ama", "Assistência qualificada para idosos", "Atenção plena em cada detalhe"],
    "produtos-naturais": ["O melhor da natureza para você", "Vida saudável começa aqui", "Alimentação consciente e natural", "Equilíbrio em cada produto"],
    pilates: ["Força, equilíbrio e flexibilidade", "O método que transforma seu corpo", "Saúde em cada movimento", "Conecte corpo e mente"],
    quiropraxia: ["Coluna saudável, vida plena", "Alívio e bem-estar para seu corpo", "Cuidado especializado com sua saúde", "Sinta a diferença em cada sessão"],
};
const nicheInternalConfig = {
    pizzaria: { designStyle: "cardapio-digital", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "cardapio", "localizacao", "contato"], fontPair: "Playfair Display + Raleway", defaultPrimary: "#E31837", defaultSecondary: "#FF6B35" },
    hamburgueria: { designStyle: "cardapio-digital", siteGoal: "gerar-pedidos", voiceTone: "criativo", pages: ["inicio", "cardapio", "contato"], fontPair: "Oswald + Roboto", defaultPrimary: "#F97316", defaultSecondary: "#1A1A1A" },
    restaurante: { designStyle: "cardapio-digital", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "cardapio", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#8B2E2E", defaultSecondary: "#D4AF37" },
    padaria: { designStyle: "local-first", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "produtos", "sobre", "contato"], fontPair: "Playfair Display + Open Sans", defaultPrimary: "#A0522D", defaultSecondary: "#E8B84A" },
    marmitaria: { designStyle: "cardapio-digital", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "cardapio", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#16A34A", defaultSecondary: "#FACC15" },
    acaiteria: { designStyle: "cardapio-digital", siteGoal: "gerar-pedidos", voiceTone: "criativo", pages: ["inicio", "cardapio", "contato"], fontPair: "Playfair Display + DM Sans", defaultPrimary: "#6B21A8", defaultSecondary: "#16A34A" },
    "fine-dining": { designStyle: "lifestyle", siteGoal: "institucional", voiceTone: "formal", pages: ["inicio", "cardapio", "sobre", "contato"], fontPair: "Cormorant Garamond + Raleway", defaultPrimary: "#D4AF37", defaultSecondary: "#1A1410" },
    "restaurante-bairro": { designStyle: "local-first", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "cardapio", "sobre", "contato"], fontPair: "Merriweather + Open Sans", defaultPrimary: "#C2410C", defaultSecondary: "#FACC15" },
    barbearia: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "galeria", "contato"], fontPair: "Oswald + Roboto", defaultPrimary: "#D4AF37", defaultSecondary: "#1A1A2E" },
    manicure: { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "galeria", "contato"], fontPair: "Playfair Display + Raleway", defaultPrimary: "#F472B6", defaultSecondary: "#D4AF37" },
    salaobeleza: { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#F472B6", defaultSecondary: "#D4AF37" },
    estetica: { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#F472B6", defaultSecondary: "#D4AF37" },
    sobrancelhas: { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "contato"], fontPair: "Playfair Display + Raleway", defaultPrimary: "#D4AF37", defaultSecondary: "#F472B6" },
    dentista: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Plus Jakarta Sans + Inter", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981" },
    clinica: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Plus Jakarta Sans + Inter", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981" },
    farmacia: { designStyle: "institucional", siteGoal: "institucional", voiceTone: "formal", pages: ["inicio", "servicos", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#16A34A", defaultSecondary: "#0EA5E9" },
    otica: { designStyle: "catalogo", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "produtos", "servicos", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37" },
    academia: { designStyle: "conversao", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "planos", "sobre", "contato"], fontPair: "Oswald + Roboto", defaultPrimary: "#DC2626", defaultSecondary: "#F97316" },
    "artes-marciais": { designStyle: "conversao", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "modalidades", "planos", "contato"], fontPair: "Oswald + Roboto", defaultPrimary: "#DC2626", defaultSecondary: "#1A1A1A" },
    petshop: { designStyle: "lifestyle", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "servicos", "produtos", "contato"], fontPair: "Fredoka + Nunito", defaultPrimary: "#E8734A", defaultSecondary: "#E8A644" },
    mecanica: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Oswald + Inter", defaultPrimary: "#F97316", defaultSecondary: "#1A1A1A" },
    lavarapido: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "criativo", pages: ["inicio", "servicos", "planos", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#0EA5E9", defaultSecondary: "#1A1A1A" },
    assistencia: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981" },
    vidracaria: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "galeria", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#0EA5E9", defaultSecondary: "#374151" },
    imobiliaria: { designStyle: "catalogo", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "imoveis", "servicos", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37" },
    advogado: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "areas", "sobre", "contato"], fontPair: "Cormorant Garamond + Raleway", defaultPrimary: "#D4AF37", defaultSecondary: "#1E3A8A" },
    contabilidade: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#16A34A", defaultSecondary: "#1E3A8A" },
    idiomas: { designStyle: "conversao", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "cursos", "planos", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981" },
    fotografo: { designStyle: "lifestyle", siteGoal: "portfolio", voiceTone: "criativo", pages: ["inicio", "portfolio", "sobre", "contato"], fontPair: "Playfair Display + Raleway", defaultPrimary: "#F8FAFC", defaultSecondary: "#1A1A1A" },
    floricultura: { designStyle: "catalogo", siteGoal: "gerar-pedidos", voiceTone: "amigavel", pages: ["inicio", "produtos", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#F472B6", defaultSecondary: "#16A34A" },
    papelaria: { designStyle: "catalogo", siteGoal: "gerar-pedidos", voiceTone: "criativo", pages: ["inicio", "produtos", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#F472B6", defaultSecondary: "#10B981" },
    "marketing-digital": { designStyle: "conversao", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "cases", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#2563EB", defaultSecondary: "#7C3AED" },
    "estetica-corporal": { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#D4AF37", defaultSecondary: "#F8FAFC" },
    nutricionista: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#16A34A", defaultSecondary: "#F8FAFC" },
    psicologo: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "areas", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#1E3A8A", defaultSecondary: "#F1F5F9" },
    "personal-trainer": { designStyle: "conversao", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "treinos", "sobre", "contato"], fontPair: "Oswald + Roboto", defaultPrimary: "#FACC15", defaultSecondary: "#0F172A" },
    fisioterapeuta: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "especialidades", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#0891B2", defaultSecondary: "#F8FAFC" },
    buffet: { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "cardapios", "espacos", "contato"], fontPair: "Playfair Display + Raleway", defaultPrimary: "#D4AF37", defaultSecondary: "#1A1A1A" },
    "escola-musica": { designStyle: "lifestyle", siteGoal: "institucional", voiceTone: "criativo", pages: ["inicio", "cursos", "sobre", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37" },
    veterinaria: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Fredoka + Nunito", defaultPrimary: "#14B8A6", defaultSecondary: "#F8FAFC" },
    dedetizadora: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Oswald + Inter", defaultPrimary: "#FACC15", defaultSecondary: "#0F172A" },
    chaveiro: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#2563EB", defaultSecondary: "#F8FAFC" },
    arquiteto: { designStyle: "lifestyle", siteGoal: "portfolio", voiceTone: "formal", pages: ["inicio", "portfolio", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#374151", defaultSecondary: "#F8FAFC" },
    eletricista: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Oswald + Inter", defaultPrimary: "#2563EB", defaultSecondary: "#FACC15" },
    encanador: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "autoritario", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#0284C7", defaultSecondary: "#F8FAFC" },
    pintor: { designStyle: "local-first", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#EA580C", defaultSecondary: "#F8FAFC" },
    despachante: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Cormorant Garamond + Raleway", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37" },
    "saude-mental": { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "especialidades", "sobre", "contato"], fontPair: "Cormorant Garamond + Lato", defaultPrimary: "#8B5CF6", defaultSecondary: "#FDF4FF" },
    "cuidador-idosos": { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "servicos", "sobre", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#3B82F6", defaultSecondary: "#FEF2F2" },
    "produtos-naturais": { designStyle: "catalogo", siteGoal: "vendas", voiceTone: "amigavel", pages: ["inicio", "produtos", "sobre", "contato"], fontPair: "Fredoka + Nunito", defaultPrimary: "#15803D", defaultSecondary: "#FEFCE8" },
    pilates: { designStyle: "lifestyle", siteGoal: "gerar-leads", voiceTone: "amigavel", pages: ["inicio", "modalidades", "sobre", "contato"], fontPair: "Poppins + DM Sans", defaultPrimary: "#78716c", defaultSecondary: "#F1F5F9" },
    quiropraxia: { designStyle: "institucional", siteGoal: "gerar-leads", voiceTone: "formal", pages: ["inicio", "especialidades", "sobre", "contato"], fontPair: "Inter + Space Grotesk", defaultPrimary: "#0F172A", defaultSecondary: "#F8FAFC" },
};
const namedColors = [
    { name: "Vermelho Pepperoni", hex: "#E31837" },
    { name: "Azul Oceano", hex: "#0EA5E9" },
    { name: "Verde Folha", hex: "#16A34A" },
    { name: "Roxo Profundo", hex: "#6B21A8" },
    { name: "Laranja Queimado", hex: "#EA580C" },
    { name: "Preto Elegante", hex: "#0F172A" },
    { name: "Branco Gelo", hex: "#F8FAFC" },
    { name: "Dourado Premium", hex: "#D4AF37" },
    { name: "Rosa Quartzo", hex: "#F472B6" },
    { name: "Azul Marinho", hex: "#1E3A8A" },
    { name: "Verde Esmeralda", hex: "#10B981" },
    { name: "Cinza Grafite", hex: "#374151" },
];
const featureOptions = [
    "Cardápio Digital",
    "Galeria de Fotos",
    "Agendamento Online",
    "Depoimentos",
    "Formulário de Contato",
    "FAQ",
];
const nicheDefaultFeatures = {
    // Alimentício → Cardápio Digital
    pizzaria: ["Cardápio Digital"],
    hamburgueria: ["Cardápio Digital"],
    restaurante: ["Cardápio Digital"],
    "restaurante-bairro": ["Cardápio Digital"],
    "fine-dining": ["Cardápio Digital"],
    padaria: ["Cardápio Digital"],
    marmitaria: ["Cardápio Digital"],
    acaiteria: ["Cardápio Digital"],
    buffet: ["Cardápio Digital"],
    // Beleza / Saúde → Agendamento Online
    barbearia: ["Agendamento Online"],
    manicure: ["Agendamento Online"],
    salaobeleza: ["Agendamento Online"],
    estetica: ["Agendamento Online"],
    sobrancelhas: ["Agendamento Online"],
    dentista: ["Agendamento Online"],
    clinica: ["Agendamento Online"],
    nutricionista: ["Agendamento Online"],
    psicologo: ["Agendamento Online"],
    fisioterapeuta: ["Agendamento Online"],
    pilates: ["Agendamento Online"],
    quiropraxia: ["Agendamento Online"],
    veterinaria: ["Agendamento Online"],
    // Portfólio / Visual → Galeria de Fotos
    petshop: ["Galeria de Fotos"],
    fotografo: ["Galeria de Fotos"],
    floricultura: ["Galeria de Fotos"],
    arquiteto: ["Galeria de Fotos"],
    papelaria: ["Galeria de Fotos"],
    // Serviços / Leads → Formulário de Contato
    advogado: ["Formulário de Contato"],
    contabilidade: ["Formulário de Contato"],
    imobiliaria: ["Formulário de Contato"],
    despachante: ["Formulário de Contato"],
    mecanica: ["Formulário de Contato"],
    lavarapido: ["Formulário de Contato"],
    assistencia: ["Formulário de Contato"],
    vidracaria: ["Formulário de Contato", "Galeria de Fotos"],
    dedetizadora: ["Formulário de Contato"],
    chaveiro: ["Formulário de Contato"],
    eletricista: ["Formulário de Contato"],
    encanador: ["Formulário de Contato"],
    pintor: ["Formulário de Contato"],
    otica: ["Formulário de Contato"],
    farmacia: ["Formulário de Contato"],
    academia: ["Formulário de Contato"],
    idiomas: ["Formulário de Contato"],
};
const simpleCtaOptions = [
    { value: "whatsapp", label: "Conversar no WhatsApp" },
    { value: "ligar", label: "Ligar para o Negócio" },
    { value: "formulario", label: "Enviar Formulário" },
    { value: "agendar", label: "Reservar um Horário" },
];
const quizNichoToProspeccaoLabel = {
    pizzaria: "Pizzarias",
    hamburgueria: "Hamburguerias",
    restaurante: "Restaurantes",
    "restaurante-bairro": "Restaurantes",
    "fine-dining": "Restaurantes",
    padaria: "Padarias",
    marmitaria: "Restaurantes",
    acaiteria: "Açaiteria",
    barbearia: "Barbearias",
    manicure: "Manicures",
    salaobeleza: "Salões de Beleza",
    estetica: "Estética",
    sobrancelhas: "Estética",
    dentista: "Dentistas",
    clinica: "Clínicas",
    farmacia: "Farmácias",
    otica: "Óticas",
    academia: "Academias",
    "artes-marciais": "Academias",
    petshop: "Pet Shops",
    mecanica: "Mecânicas",
    lavarapido: "Lava Jato",
    assistencia: "Assistência Técnica",
    vidracaria: undefined,
    imobiliaria: "Imobiliárias",
    advogado: "Advogados",
    contabilidade: "Contadores",
    idiomas: "Escolas de Idiomas",
    fotografo: "Fotógrafos",
    floricultura: "Floricultura",
    papelaria: undefined,
    "marketing-digital": undefined,
    "estetica-corporal": "Estética Corporal",
    nutricionista: "Nutricionista",
    psicologo: "Psicólogo",
    "personal-trainer": "Personal Trainer",
    fisioterapeuta: "Fisioterapeuta",
    buffet: "Buffet / Eventos",
    "escola-musica": "Escola de Música",
    veterinaria: "Veterinária",
    dedetizadora: "Dedetizadora",
    chaveiro: "Chaveiro",
    arquiteto: "Arquiteto",
    eletricista: "Eletricista",
    encanador: "Encanador",
    pintor: "Pintor",
    despachante: "Despachante",
    "saude-mental": "Saúde Mental",
    "cuidador-idosos": "Cuidador de Idosos",
    "produtos-naturais": "Produtos Naturais",
    pilates: "Pilates",
    quiropraxia: "Quiropraxia",
};
const DELIVERY_APP_NICHES = new Set([
    "pizzaria", "hamburgueria", "acaiteria", "marmitaria", "padaria",
    "restaurante", "restaurante-bairro", "fine-dining", "buffet", "farmacia",
]);
const AGENDAMENTO_APP_NICHES = new Set([
    "barbearia", "manicure", "salaobeleza", "estetica", "sobrancelhas",
    "dentista", "clinica", "otica", "academia", "artes-marciais",
    "veterinaria", "psicologo", "nutricionista", "fisioterapeuta",
    "personal-trainer", "estetica-corporal", "pilates", "quiropraxia",
    "saude-mental", "petshop",
]);
const APP_NICHE_KEYS = new Set([
    ...Array.from(DELIVERY_APP_NICHES),
    ...Array.from(AGENDAMENTO_APP_NICHES),
]);
const applyElitePrompt = (prompt) => `${prompt}

═══════════════════════════════════════════════
🏆 MODO ELITE — PADRÃO AWWWARDS / AGÊNCIA INTERNACIONAL
═══════════════════════════════════════════════
Eleve este projeto ao nível de um site premiado internacionalmente. O resultado precisa parecer feito por um estúdio de design de altíssimo nível, não por um gerador.

DIREÇÃO DE ARTE
- Defina antes um conceito criativo único para a marca (uma ideia central) e faça cada seção reforçar esse conceito.
- Grid intencional (12 colunas, com quebras assimétricas propositais), escala tipográfica matemática e espaçamento generoso e consistente.
- Tipografia como protagonista: títulos grandes com kerning ajustado, contraste forte entre display e corpo, largura de linha entre 60 e 75 caracteres.
- Paleta com profundidade: tons de superfície, elevação, estados e um acento usado com parcimônia. Evite cores chapadas sem profundidade, mas mantenha a fidelidade absoluta à paleta escolhida pelo usuário.
- Imagens tratadas com enquadramento editorial, proporção consistente e integração real com o layout (sobreposição, recorte, moldura), nunca coladas.

MOVIMENTO
- Timeline de entrada coreografada na primeira tela (título, subtítulo, ação e mídia em cascata com atrasos precisos).
- Parallax sutil, revelações por máscara e transições de estado suaves com curvas personalizadas (cubic-bezier), nunca lineares.
- Cursor, hover e foco com resposta refinada e imediata. Toda animação abaixo de 800ms e respeitando prefers-reduced-motion.

CONTEÚDO
- Copy de redator sênior: frases curtas, verbos fortes, benefício concreto em cada título, zero clichê corporativo e zero informação inventada.
- Cada seção precisa ter uma razão de existir e responder a uma objeção real do cliente final.

ENGENHARIA
- Componentes limpos e reutilizáveis, tokens semânticos no index.css, zero cor hardcoded, zero valor mágico repetido.
- Estados completos: carregando, vazio, erro, sucesso, foco, desabilitado.
- Acessibilidade AA+, semântica correta, navegação por teclado impecável, desempenho otimizado e layout estável.

CRITÉRIO FINAL
Antes de entregar, revise silenciosamente como se fosse submeter o site a um júri de premiação: se qualquer seção parecer comum, refaça-a. Entregue somente quando o conjunto estiver visualmente memorável, coerente e impecável em qualquer tela.`;
export function gerarPrompt({ niche, projectName, primaryColor, secondaryColor, projectType = 'site', slogan = '', selectedFeatures = [], address = '', phone = '', businessHours = '', ctaPrincipal = '', eliteMode = false }) {
    const template = nicheTemplates[niche];
    if (!template)
        throw new Error('Nicho inválido');
    if (!projectName?.trim())
        throw new Error('Nome obrigatório');
    if (!primaryColor || !secondaryColor)
        throw new Error('As duas cores são obrigatórias');
    const primaryName = namedColors.find((c) => c.hex === primaryColor)?.name;
    const secondaryName = namedColors.find((c) => c.hex === secondaryColor)?.name;
    const primaryLabel = primaryName ? `${primaryName} (${primaryColor})` : primaryColor;
    const secondaryLabel = secondaryName ? `${secondaryName} (${secondaryColor})` : secondaryColor;
    const cfg = nicheInternalConfig[niche];
    const isApp = projectType === "app";
    const appKind = DELIVERY_APP_NICHES.has(niche) ? "delivery" : "agendamento";
    // Mantém todas as escolhas manuais e apenas acrescenta sugestões compatíveis do nicho.
    const smartFeatures = nicheDefaultFeatures[niche] || [];
    const extraSmart = ["SEO Avançado", "Micro-interações premium", "Otimização de performance extrema", "Copywriting magnético", "Design responsivo fluido"];
    const finalFeaturesStr = [...new Set([...selectedFeatures, ...smartFeatures, ...extraSmart])].join(", ");
    const cta = simpleCtaOptions.find((c) => c.value === ctaPrincipal)?.label || "Entrar em contato";
    const basePrompt = `Você é um diretor de arte premiado (nível Awwwards) e desenvolvedor front-end sênior. Crie em UMA ÚNICA passada um site cuja PRIORIDADE Nº 1 é a BELEZA VISUAL. Sem perguntas, sem plano, sem placeholders: implemente diretamente o resultado final.

A REGRA DE OURO: menos é mais. Sites bonitos têm POUCO TEXTO e MUITO RESPIRO. Não encha a página de informação: cada seção deve dizer uma única coisa, com poucas palavras, tipografia grande e espaçamento generoso. Se uma seção parecer um bloco de texto corrido, você errou.

═══════════════════════════════════════════════
🎯 O PROJETO
═══════════════════════════════════════════════
Negócio: ${projectName.trim()}
Nicho: ${template.label}
Slogan: ${slogan.trim() || "(crie um headline curto e marcante — máx. 8 palavras)"}
Objetivo: ${cfg?.siteGoal || "conversão"}
Ação principal (CTA): ${cta}

═══════════════════════════════════════════════
📸 FOTOS — REGRA OBRIGATÓRIA (erro aqui = site reprovado)
═══════════════════════════════════════════════
- TODAS as fotos devem mostrar exatamente o nicho "${template.label}": o ambiente, os profissionais, os produtos e os serviços reais desse tipo de negócio. Nunca use fotos de outro nicho, paisagens aleatórias, escritórios genéricos, pessoas sem relação ou imagens abstratas.
- Antes de escolher cada foto, confira: "esta imagem mostra claramente ${template.label}?" Se não mostrar, troque.
- Cada foto deve combinar com o texto ao lado (ex.: card de um serviço mostra esse serviço; card de um produto mostra esse produto).
- Use fotos reais do Unsplash (images.unsplash.com) com termos de busca em inglês específicos do nicho; não repita a mesma foto e não use links quebrados.
- Pessoas nas fotos devem ter aparência brasileira/diversa e contexto coerente com o negócio. Sem texto, marca d'água ou logotipos de terceiros nas imagens.


═══════════════════════════════════════════════
🎨 DESIGN — O QUE DEFINE UM SITE LINDO
═══════════════════════════════════════════════
1. PRIMEIRA TELA IMPECÁVEL: é 70% do julgamento. Título enorme e confiante, no máximo uma frase de apoio, UMA imagem grande e deslumbrante do nicho e o botão de ação. Nada mais. Deixe a borda da próxima seção aparecer para convidar à rolagem.
2. TIPOGRAFIA COMO PROTAGONISTA: escolha uma dupla tipográfica expressiva (títulos com personalidade + corpo neutro). Títulos muito grandes com clamp() responsivo, entrelinha apertada nos títulos e generosa no corpo. Jamais Inter/Poppins como escolha automática.
3. RESPIRO: paddings verticais grandes (mínimo 6–8rem por seção), margens consistentes, grid com colunas claras. Espaço vazio é elegância — não preencha por preencher.
4. IMAGENS GRANDES E REAIS: poucas, porém enormes e de altíssima qualidade, sempre do nicho, com boa luz. Use-as como elementos de composição (sangradas, sobrepostas, em mascaras/arcos), nunca como thumbnails genéricas em cards.
5. RITMO VISUAL: cada seção com um arranjo diferente (texto à esquerda/imagem à direita, depois inverta, depois centralizado, depois editorial assimétrico). Proibida a sequência de seções iguais com 3 cards lado a lado.
6. PALETA DISCIPLINADA: as duas cores escolhidas abaixo dominam tudo. Fundos amplos e limpos, acentos pontuais. Se houver cor escura (preto/marinho), faça tema dark premium. Tokens semânticos em HSL no index.css; nada de cores hardcoded nos componentes.
7. DETALHES FINOS: cantos, bordas e sombras consistentes; divisores discretos; micro-interações sutis ao passar o mouse apenas em elementos clicáveis; scroll-reveal suave (framer-motion, whileInView, once, 0.6s). Respeite prefers-reduced-motion. Zero brilho exagerado, zero glitter.
Estilo de referência: ${cfg?.designStyle || "moderno editorial"} · Tom de voz: ${cfg?.voiceTone || "profissional"} · Tipografia sugerida: ${cfg?.fontPair || "escolha a dupla ideal para o nicho"}.

═══════════════════════════════════════════════
🧱 ESTRUTURA ENXUTA (máx. 6 seções)
═══════════════════════════════════════════════
${cfg?.pages.join(" → ") || "Abertura impactante → O que oferece (visual, poucos itens) → Prova/depoimentos curtos → Chamada final → Rodapé simples"}.
Copy em português do Brasil: títulos de até 6 palavras, frases curtas, zero enrolação, zero texto corporativo genérico. Não invente prêmios, números, clientes ou endereços — omita o que não foi informado.
Funcionalidades desejadas: ${finalFeaturesStr || "nenhuma"} — integre-as com discrição visual.

═══════════════════════════════════════════════
🎨 BRIEFING DO NICHO (inspire-se, não copie)
═══════════════════════════════════════════════
${template.buildPrompt(projectName.trim(), primaryLabel, secondaryLabel, finalFeaturesStr)}

═══════════════════════════════════════════════
🔒 ESCOLHAS DO USUÁRIO — INEGOCIÁVEIS
═══════════════════════════════════════════════
- Cor principal: ${primaryLabel} · Cor secundária: ${secondaryLabel}.
- Estas cores definem TODA a identidade (fundos, botões, destaques, estados). Ignore qualquer paleta sugerida pelo nicho que conflite com elas. Nunca troque por branco/cinza automático.
- As funcionalidades selecionadas pelo usuário devem ser preservadas.

═══════════════════════════════════════════════
📞 CONTATO (usar só o que existir)
═══════════════════════════════════════════════
Endereço: ${address.trim() || "não informado — não crie seção de mapa"}
Telefone: ${phone.trim() || "não informado — não crie botão de WhatsApp"}
Horário: ${businessHours.trim() || "não informado"}
Se houver telefone: botão de WhatsApp com wa.me, número sanitizado, mensagem pronta e abertura em nova aba.

═══════════════════════════════════════════════
✅ TÉCNICA (silenciosa)
═══════════════════════════════════════════════
- Perfeito em 360px, 768px e desktop; sem corte, sobreposição ou rolagem horizontal.
- Todos os botões funcionam e levam a "${cta}" ou à seção correspondente; nenhum link "#" vazio.
- Formulário (se houver) com rótulos e validação; sem integração, direciona ao WhatsApp se houver telefone.
- SEO básico: um único H1, title ≤ 60, meta description ≤ 160, alt nas imagens.
- Revisão final: se qualquer seção parecer um template genérico, refaça-a com mais ousadia visual antes de entregar.`;
    let finalPrompt = isApp
        ? `Crie um APP MOBILE (PWA mobile-first, instalável, com a aparência e o comportamento de um aplicativo nativo) — NÃO crie uma landing page.

ESTRUTURA OBRIGATÓRIA DO APP:
- Container centralizado com largura máxima de 480px no desktop, simulando tela de celular.
- Tela inicial de Login/Cadastro com opção "entrar como visitante".
- Navegação principal por bottom tabs fixas com 4 abas: ${appKind === "delivery"
            ? "Início, Cardápio, Pedidos, Perfil"
            : "Início, Agendar, Meus Agendamentos, Perfil"}.
- Header fixo em cada tela interna com botão de voltar e título.
- ${appKind === "delivery"
            ? `Aba Cardápio com categorias, cards de produtos (foto, nome, descrição, preço, botão adicionar), carrinho persistente (badge no ícone), checkout fake com resumo do pedido e botão "Finalizar pelo WhatsApp" que abre wa.me com a mensagem do pedido.`
            : `Fluxo de agendamento em etapas: 1) escolher serviço, 2) escolher profissional, 3) escolher data (calendário), 4) escolher horário, 5) tela de confirmação. Aba "Meus Agendamentos" lista próximos e anteriores.`}
- Transições suaves entre telas com framer-motion (slide horizontal).
- Estado de carrinho/agendamentos persistido em localStorage.
- Notificações via toast (sonner) para ações importantes.
- Visual mobile-first com cantos arredondados generosos, cards com sombra suave, tipografia legível em telas pequenas, botões grandes (mínimo 48px de altura).
- Sem seções/banners de "promoções" ou "ofertas em destaque".

APLIQUE A IDENTIDADE VISUAL E AS INFORMAÇÕES ABAIXO (nome, slogan, cores, contato, horário) DENTRO DO APP, NÃO COMO UM SITE:

${basePrompt}`
        : basePrompt;
    // Padrão de qualidade máxima aplicado condicionalmente.
    if (eliteMode)
        finalPrompt = applyElitePrompt(finalPrompt);
    return finalPrompt;
}
export const catalogo = Object.fromEntries(Object.entries(nicheTemplates).map(([key, t]) => [key, { label: t.label, config: nicheInternalConfig[key], extras: nicheDefaultFeatures[key] || [], slogans: sloganSuggestions[key] || [], permiteApp: APP_NICHE_KEYS.has(key), tipoApp: DELIVERY_APP_NICHES.has(key) ? 'delivery' : AGENDAMENTO_APP_NICHES.has(key) ? 'agendamento' : null }]));
export { nicheTemplates, nicheInternalConfig, nicheDefaultFeatures, namedColors, featureOptions, simpleCtaOptions, sloganSuggestions, quizNichoToProspeccaoLabel, APP_NICHE_KEYS };
