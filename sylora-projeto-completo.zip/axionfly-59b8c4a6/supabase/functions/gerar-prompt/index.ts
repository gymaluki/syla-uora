// Gera o prompt completo do site/app de um nicho. Não usa IA: o texto é montado
// por regras fixas (gerador de nichos), então não gasta crédito nenhum.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
// @ts-ignore: módulo JS sem tipos
import { gerarPrompt, catalogo } from "./prompts-nichos.mjs";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

const text = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return json({ error: 'Unauthorized' }, 401);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const userClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: 'Unauthorized' }, 401);

    const serviceClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: hasAccess } = await serviceClient.rpc('check_user_access', { check_user_id: user.id });
    if (!hasAccess) return json({ error: 'Subscription required' }, 403);

    const body = await req.json().catch(() => ({}));
    const niche = text(body?.niche, 60);
    const projectType = body?.projectType === 'app' ? 'app' : 'site';
    const projectName = text(body?.projectName, 120);
    const primaryColor = text(body?.primaryColor, 60);
    const secondaryColor = text(body?.secondaryColor, 60);

    const entry = (catalogo as Record<string, { permiteApp: boolean }>)[niche];
    if (!entry) return json({ error: 'Nicho inválido' }, 400);
    if (projectType === 'app' && !entry.permiteApp) return json({ error: 'Este nicho não está disponível para app' }, 400);
    if (!projectName) return json({ error: 'Informe o nome do projeto' }, 400);
    if (!primaryColor || !secondaryColor) return json({ error: 'Informe as duas cores' }, 400);

    const prompt = gerarPrompt({
      niche,
      projectType,
      projectName,
      primaryColor,
      secondaryColor,
      slogan: text(body?.slogan, 160),
      selectedFeatures: Array.isArray(body?.selectedFeatures)
        ? body.selectedFeatures.map((f: unknown) => text(f, 80)).filter(Boolean).slice(0, 20)
        : [],
      address: text(body?.address, 240),
      phone: text(body?.phone, 40),
      businessHours: text(body?.businessHours, 160),
      ctaPrincipal: text(body?.ctaPrincipal, 20) || 'whatsapp',
    });

    return json({ prompt });
  } catch (e) {
    console.error('gerar-prompt', e);
    return json({ error: 'Não foi possível gerar o prompt' }, 500);
  }
});
