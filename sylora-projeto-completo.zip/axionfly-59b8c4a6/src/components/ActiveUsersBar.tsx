import { motion } from "framer-motion";
import { AlertTriangle, RefreshCw } from "lucide-react";

const TOTAL = 500;
const ATIVOS = 493;
const VAGAS = 7;

export default function ActiveUsersBar() {
  const percent = Math.min(100, Math.round((ATIVOS / TOTAL) * 100));

  return (
    <section className="container mx-auto px-4 pt-2 pb-12 md:pt-4 md:pb-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="max-w-3xl mx-auto rounded-2xl border border-primary/20 bg-[#0a0a0e]/80 backdrop-blur-sm p-6 md:p-8 shadow-[0_8px_40px_-12px_rgba(220,226,238,0.25)]"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-foreground">
            <AlertTriangle className="w-4 h-4 text-primary" />
            <span className="text-sm md:text-base font-medium">Usuários ativos</span>
          </div>
          <div className="text-sm md:text-base font-black text-foreground tabular-nums">
            {ATIVOS} / {TOTAL}
          </div>
        </div>

        <div className="relative h-2 w-full rounded-full bg-[var(--au-surface-2)] overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: `${percent}%` }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-primary to-primary/70 shadow-[0_0_20px_rgba(220,226,238,0.5)]"
          />
        </div>

        <p className="text-center text-sm md:text-base text-[var(--au-text-3)] mt-5">
          Restam apenas <span className="font-black text-foreground">{VAGAS} acessos</span> disponíveis.
        </p>

        <div className="flex items-center justify-center gap-2 mt-2 text-xs text-[var(--au-text-3)]">
          <RefreshCw className="w-3 h-3" />
          <span>Atualizado em tempo real</span>
        </div>
      </motion.div>
    </section>
  );
}
