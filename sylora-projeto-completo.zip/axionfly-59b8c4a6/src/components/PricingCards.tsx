import React, { useState, useRef } from "react";
import { motion, type Easing, AnimatePresence } from "framer-motion";
import { Check, Sparkles, ChevronDown, Clock, Star } from "lucide-react";
// Inline payment icons (replaced react-icons to keep bundle small)
const SiPix = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M5.283 18.36a3.5 3.5 0 0 0 2.493-1.032l3.6-3.6a.5.5 0 0 1 .7 0l3.6 3.6a3.5 3.5 0 0 0 2.493 1.032h.708l-4.6 4.6a3 3 0 0 1-4.243 0l-4.6-4.6h.849zm13.394-12.72a3.5 3.5 0 0 0-2.493 1.032l-3.6 3.6a.51.51 0 0 1-.7 0l-3.6-3.6A3.5 3.5 0 0 0 5.84 5.64h-.85l4.6-4.6a3 3 0 0 1 4.243 0l4.6 4.6h-.85zM1.04 10.36l2.84-2.84h1.41a2.5 2.5 0 0 1 1.768.732l3.6 3.6a1.5 1.5 0 0 0 2.121 0l3.6-3.6a2.5 2.5 0 0 1 1.768-.732h1.4l2.85 2.84a3 3 0 0 1 0 4.243l-2.85 2.84h-1.4a2.5 2.5 0 0 1-1.768-.732l-3.6-3.6a1.5 1.5 0 0 0-2.121 0l-3.6 3.6a2.5 2.5 0 0 1-1.768.732H3.88l-2.84-2.84a3 3 0 0 1 0-4.243z" />
  </svg>
);
const FaCcMastercard = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 576 512" fill="currentColor" aria-hidden="true">
    <path d="M482.9 410.3c0 6.8-4.6 11.7-11.2 11.7-6.8 0-11.2-5.2-11.2-11.7 0-6.5 4.4-11.7 11.2-11.7 6.6 0 11.2 5.2 11.2 11.7zm-310.8-11.7c-7.1 0-11.2 5.2-11.2 11.7 0 6.5 4.1 11.7 11.2 11.7 6.5 0 10.9-4.9 10.9-11.7-.1-6.5-4.4-11.7-10.9-11.7zm117.5-.3c-5.4 0-8.7 3.5-9.5 8.7h19.1c-.9-5.7-4.4-8.7-9.6-8.7zm107.8.3c-6.8 0-10.9 5.2-10.9 11.7 0 6.5 4.1 11.7 10.9 11.7 6.8 0 11.2-4.9 11.2-11.7 0-6.5-4.4-11.7-11.2-11.7zm105.9 26.1c0 .3.3.5.3 1.1 0 .3-.3.5-.3 1.1-.3.3-.3.5-.5.8-.3.3-.5.5-1.1.5-.3.3-.5.3-1.1.3-.3 0-.5 0-1.1-.3-.3 0-.5-.3-.8-.5-.3-.3-.5-.5-.5-.8-.3-.5-.3-.8-.3-1.1 0-.5 0-.8.3-1.1 0-.5.3-.8.5-1.1.3-.3.5-.3.8-.5.5-.3.8-.3 1.1-.3.5 0 .8 0 1.1.3.5.3.8.3 1.1.5s.2.6.5 1.1zm-2.2 1.4c.5 0 .5-.3.8-.3.3-.3.3-.5.3-.8 0-.3 0-.5-.3-.8-.3 0-.5-.3-1.1-.3h-1.6v3.5h.8V427h.3l1.1 1.4h.8l-1.1-1.3zM576 81v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V81c0-26.5 21.5-48 48-48h480c26.5 0 48 21.5 48 48zM64 220.6c0 76.5 62.1 138.5 138.5 138.5 27.2 0 53.9-8.2 76.5-23.1-72.9-59.3-72.4-171.2 0-230.5-22.6-15-49.3-23.1-76.5-23.1-76.4-.1-138.5 62-138.5 138.2zm224 108.8c70.5-55 70.2-162.2 0-217.5-70.2 55.3-70.5 162.6 0 217.5zm-142.3 76.3c0-11.4-7.6-19.1-19.6-19.4-6.2 0-12.8 1.9-17.4 8.7-3.5-5.7-9-8.7-16.9-8.7-5.2 0-10.4 1.6-14.4 7.4v-6.2H71v50.9h8.4v-28.3c0-8.4 4.6-12.5 11.7-12.5 7.1 0 10.6 4.6 10.6 12.5v28.3h8.4v-28.3c0-8.4 4.9-12.5 11.7-12.5 7.1 0 10.6 4.6 10.6 12.5v28.3h8.7v-31.7zm59 5.4v-25.3h-8.4v6.2c-3.5-4.6-8.7-7.4-15.8-7.4-14.1 0-25 11.2-25 26.7 0 15.6 10.9 26.7 25 26.7 6.8 0 12-2.7 15.8-7.4v6.2h8.4v-25.7zm59.3 10.3c0-15.4-21.2-9.3-21.2-16.6 0-3.5 3.3-5.4 9-5.4 5.4 0 11.4 1.9 16.1 4.6l3.5-7.1c-15.5-9.7-37.4-6.4-37.4 8.7 0 14.6 21.2 9 21.2 16.3 0 4.1-3.8 6-9.5 6-9.6 0-14.4-5.4-14.4-5.4l-3.8 6.8s6 5.4 18.2 5.4c11.4 0 17.9-5.7 18.2-13.6.2-.5.2-.4.1.3zm38.2 8.7l-2.4-7.1s-3.8 2.7-7.9 2.7c-3.5 0-5.4-2.2-5.4-6.2v-22.6h13.6v-7.6h-13.6v-15.5h-8.4v15.5h-7.6v7.6h7.6v22.6c0 11.4 8.7 13.6 13.6 13.6 5.5.1 9.6-1.5 11.7-3z"/>
  </svg>
);
const FaCcVisa = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 576 512" fill="currentColor" aria-hidden="true">
    <path d="M470.1 231.3s7.6 37.2 9.3 45H446c3.3-8.9 16-43.5 16-43.5-.2.3 3.3-9.1 5.3-14.9l2.8 13.4zM576 80v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V80c0-26.5 21.5-48 48-48h480c26.5 0 48 21.5 48 48zM152.5 331.2L215.7 176h-42.5l-39.3 106-4.3-21.5-14-71.4c-2.3-9.9-9.4-12.7-18.2-13.1H32.7l-.7 3.1c15.8 4 29.9 9.8 42.2 17.1l35.8 135h42.5zm94.4.2L272.1 176h-40.2l-25.1 155.4h40.1zm139.9-50.8c.2-17.7-10.6-31.2-33.7-42.3-14.1-7.1-22.7-11.9-22.7-19.2.2-6.6 7.3-13.4 23.1-13.4 13.1-.3 22.7 2.8 29.9 5.9l3.6 1.7 5.5-33.6c-7.9-3.1-20.5-6.6-36-6.6-39.7 0-67.6 21.2-67.8 51.4-.3 22.3 20 34.7 35.2 42.2 15.5 7.6 20.8 12.6 20.8 19.3-.2 10.4-12.6 15.2-24.1 15.2-16 0-24.6-2.5-37.7-8.3l-5.3-2.5-5.6 34.9c9.4 4.3 26.8 8.1 44.8 8.3 42.2.1 69.7-20.8 70-53zM528 331.4L495.6 176h-31.1c-9.6 0-16.9 2.8-21 12.9l-59.7 142.5H426s6.9-19.2 8.4-23.3H486c1.2 5.5 4.8 23.3 4.8 23.3H528z"/>
  </svg>
);
const FaBarcode = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 512 512" fill="currentColor" aria-hidden="true">
    <path d="M0 32v448h512V32H0zm64 384h-32V96h32v320zm64 0h-16V96h16v320zm64 0h-32V96h32v320zm80 0h-32V96h32v320zm48 0h-32V96h32v320zm80 0h-48V96h48v320zm80 0h-48V96h48v320z"/>
  </svg>
);
import googleMapsLogo from "@/assets/google-maps-logo.webp";
import "@/components/auren/alvora-landing.css";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { resolveCheckoutUrl, setSelectedPlan, clearAffiliateData } from "@/lib/affiliates";


const ease: Easing = [0.16, 1, 0.3, 1];
const hoverTransition = { type: "tween" as const, duration: 0.12, ease: "easeOut" as const };

// useCountUp removed as requested to make prices static

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.05, duration: 0.4, ease },
  }),
};

interface PricingCardProps {
  planName: string;
  description: string;
  features: string[];
  isHighlight?: boolean;
  buttonText: string;
  plan: "monthly" | "lifetime";
  index: number;
}

function PricingCard({ planName, description, features, isHighlight, buttonText, plan, index }: PricingCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleClick = async () => {
    setSelectedPlan(plan);
    try {
      const url = await resolveCheckoutUrl(plan);
      if (url) {
        window.location.href = url;
        return;
      }
    } catch (err) {
      console.error("Checkout url error:", err);
    }
    toast.error("Não foi possível abrir o checkout. Tente novamente.");
  };

  const visibleFeatures = isExpanded ? features : features.slice(0, 5);

  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={fadeUp}
      custom={index}
      whileHover={{ y: -8, transition: hoverTransition }}
      className={`relative flex h-full w-full flex-col rounded-[28px] px-6 pb-6 pt-10 sm:px-8 sm:pb-7 transition-all duration-500 border ${
        isHighlight
          ? "al-light z-10 border-white bg-white shadow-[0_0_140px_-20px_rgba(255,255,255,0.4)]"
          : "al-light border-white bg-white shadow-[0_0_60px_-24px_rgba(255,255,255,0.3)]"
      }`}
    >
      <div className="text-center space-y-1.5">
        <h3 className="au-display text-2xl sm:text-[28px] font-semibold text-[var(--au-text)]">{planName}</h3>
        <p className="text-[14px] font-medium text-[var(--au-text-2)]">{description}</p>
      </div>

      <div className="mt-6 mb-7 min-h-[150px] flex flex-col items-center justify-center text-center">
        {plan === "lifetime" ? (
          <>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-red-400/40 bg-red-500/10 px-4 py-1.5 text-[11px] font-black uppercase tracking-[0.18em] text-red-600">
              <Sparkles className="h-3.5 w-3.5" /> Promoção Black Friday
            </span>
            <span className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-red-400/30 bg-red-500/[0.06] px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.14em] text-red-600">
              <Clock className="h-3.5 w-3.5" /> Só enquanto durar a promoção
            </span>
            <span className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[var(--au-text)] px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.14em] text-white">
              <Star className="h-3.5 w-3.5" /> Mais escolhido
            </span>
            <div className="mt-5 flex items-baseline gap-1.5">
              <span className="text-[12px] font-black text-[var(--au-text)]">12x</span>
              <span className="au-display text-[40px] sm:text-[44px] font-semibold text-[var(--au-text)] leading-none">R$ 19,07</span>
              <span className="text-[11px] font-bold text-[var(--au-text)] uppercase tracking-widest">no cartão</span>
            </div>
            <span className="mt-3 inline-flex items-center gap-2 rounded-full border border-[var(--au-border-strong)] bg-[var(--au-surface-2)] px-3 py-1">
              <span className="text-[12.5px] font-bold text-[var(--au-text-2)] tabular-nums">R$ 179,00</span>
              <span className="text-[9.5px] font-black uppercase tracking-wider text-[var(--au-text)]">à vista no Pix</span>
            </span>
          </>
        ) : (
          <>
            <div className="flex items-baseline gap-1.5">
              <span className="au-display text-[40px] sm:text-[44px] font-semibold text-[var(--au-text)] leading-none">R$ 139,90</span>
              <span className="text-[11px] font-bold text-[var(--au-text)] uppercase tracking-widest">/ mês</span>
            </div>
            <span className="mt-4 inline-flex items-center gap-2 rounded-full border border-[var(--au-border-strong)] bg-[var(--au-surface-2)] px-3.5 py-1.5">
              <span className="text-[9.5px] font-black uppercase tracking-wider text-[var(--au-text)]">Mensal</span>
              <span className="text-[13px] font-bold text-[var(--au-text)]">renovação todo mês</span>
            </span>
          </>
        )}
      </div>

      <div className="mb-6 flex-1">
        <ul className="space-y-2.5">
          <AnimatePresence>
            {visibleFeatures.map((feature, idx) => (
              <motion.li
                key={feature}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.04 }}
                className="flex items-start gap-2.5 text-[13.5px] text-[var(--au-text)] font-semibold"
              >
                <div className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-[var(--au-surface-2)] mt-0.5">
                  <Check className="h-2.5 w-2.5 text-[var(--au-text)] stroke-[3px]" />
                </div>
                <span>{feature}</span>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>

        {features.length > 5 && (
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="mt-4 flex items-center gap-2 text-[11px] font-black text-[var(--au-text)] uppercase tracking-widest hover:opacity-80 transition-opacity"
          >
            {isExpanded ? "Ver menos" : "Ver todos os recursos"}
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${isExpanded ? "rotate-180" : ""}`} />
          </button>
        )}
      </div>

      <div className="mt-auto space-y-4">
        <button type="button" className="al-buy solid" onClick={handleClick}>
          {buttonText}
        </button>

        <div className="flex items-center justify-center gap-3 opacity-50 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-300">
          <SiPix className="h-5 w-5" />
          <FaCcMastercard className="h-6 w-6" />
          <FaCcVisa className="h-6 w-6" />
          <FaBarcode className="h-5 w-5" />
        </div>
      </div>
    </motion.div>
  );
}

export default function PricingCards() {
  const sharedFeatures = [
    "Criador de Sites e Apps com IA (30+ nichos)",
    "Criação de Sites e Apps Infinitos",
    "Prospecção Automática Brasil via Google Maps",
    "Hyperbuild Pro Grátis",
    "Gerador de Contrato Automático",
    "Script de Vendas Pronto para WhatsApp",
    "Dashboard de Acompanhamento de Lucros",
    "Mentor IA — Tira Dúvidas 24h",
    "Parceria Oficial com Google AI Studio",
    "Suporte Prioritário",
    "6 Estilos de Design Exclusivos",
    "Todas as Atualizações Futuras Incluídas",
  ];

  // Anual usa o 2º checkout configurado (slot "lifetime") — trocar pelos links dos produtos novos.
  const plans: PricingCardProps[] = [
    {
      planName: "Plano Mensal",
      description: "Acesso completo à plataforma por mês",
      features: sharedFeatures,
      buttonText: "Assinar plano mensal",
      plan: "monthly",
      index: 1,
    },
    {
      planName: "Plano Anual",
      description: "Acesso completo à plataforma por 1 ano",
      features: sharedFeatures,
      buttonText: "Assinar plano anual com desconto",
      plan: "lifetime",
      isHighlight: true,
      index: 2,
    },
  ];

  return (
    <section id="pricing" className="al-night au-dark relative overflow-hidden py-24 md:py-32">
      <i className="al-rings" aria-hidden />
      <i className="al-glow" aria-hidden />
      <div className="container mx-auto px-4 relative">
      <SectionPill>Chega de perder tempo</SectionPill>

      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={fadeUp}
        custom={0}
        className="mb-16 space-y-6 text-center"
      >
        <h2 className="au-display text-[36px] md:text-[60px] font-semibold text-[var(--au-text)] leading-[1.02] tracking-[-0.05em]">
          Você já perdeu tempo suficiente. <br className="hidden md:block" />
          Agora é hora de cobrar por isso.
        </h2>
        <p className="mx-auto max-w-2xl text-[18px] md:text-[20px] text-[var(--au-text-2)] font-normal leading-[1.7]">
          Enquanto você aprende do zero, outros já estão fechando contratos. A plataforma corta o caminho e te coloca direto no lucro.
        </p>
      </motion.div>

      <div className="grid w-full max-w-4xl grid-cols-1 items-stretch gap-5 px-4 md:px-0 lg:grid-cols-2 lg:gap-6 mx-auto">
        {plans.map((plan) => (
          <div key={plan.planName} className="flex h-full w-full">
            <PricingCard {...plan} />
          </div>
        ))}
      </div>
      </div>
    </section>
  );
}

function SectionPill({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex justify-center mb-8">
      <span className="inline-flex items-center rounded-full border border-white/20 bg-white/5 px-6 py-1.5 text-[11px] font-black uppercase tracking-[0.18em] text-white backdrop-blur-sm">
        {children}
      </span>
    </div>
  );
}
