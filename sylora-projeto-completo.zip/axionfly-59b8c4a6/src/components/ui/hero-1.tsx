import { Button } from "@/components/ui/button";
import { ArrowRightIcon, Zap, Sparkles, BarChart3, Users, Globe, ArrowUpRight, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

/* Laptop mockup with sylora dashboard */
function LaptopMockup() {
  return (
    <div className="relative w-full" style={{ perspective: "1500px" }}>
      <div
        className="relative"
        style={{ transform: "rotateY(-14deg) rotateX(6deg)", transformStyle: "preserve-3d" }}
      >
        {/* Screen */}
        <div className="rounded-[14px] border border-primary/30 bg-[var(--au-surface)] shadow-[0_30px_80px_-20px_rgba(220,226,238,0.45)] overflow-hidden">
          {/* Title bar */}
          <div className="h-7 border-b border-primary/15 bg-[#0c0c0f] flex items-center px-3 gap-1.5">
            <div className="w-2 h-2 rounded-full bg-red-500/60" />
            <div className="w-2 h-2 rounded-full bg-amber-500/60" />
            <div className="w-2 h-2 rounded-full bg-emerald-500/60" />
            <div className="mx-auto bg-[var(--au-surface)] rounded px-2 py-0.5 text-[8px] text-muted-foreground font-mono">
              auren.site/dashboard
            </div>
          </div>
          {/* Content */}
          <div className="p-3 grid grid-cols-3 gap-2.5">
            <div className="space-y-2">
              <div className="p-2.5 rounded-lg bg-[var(--au-surface)] border border-primary/15">
                <div className="flex justify-between items-start mb-1.5">
                  <div className="p-1 rounded bg-primary/15"><Users className="w-3 h-3 text-primary" /></div>
                  <span className="text-[8px] text-emerald-500 font-bold flex items-center"><ArrowUpRight className="w-2.5 h-2.5" />+12%</span>
                </div>
                <p className="text-[8px] text-muted-foreground">Leads</p>
                <p className="text-sm font-black text-foreground">1.284</p>
              </div>
              <div className="p-2.5 rounded-lg bg-[var(--au-surface)] border border-primary/15">
                <div className="flex justify-between items-start mb-1.5">
                  <div className="p-1 rounded bg-primary/15"><Globe className="w-3 h-3 text-primary" /></div>
                  <span className="text-[8px] text-emerald-500 font-bold flex items-center"><ArrowUpRight className="w-2.5 h-2.5" />+8%</span>
                </div>
                <p className="text-[8px] text-muted-foreground">Sites</p>
                <p className="text-sm font-black text-foreground">542</p>
              </div>
            </div>
            <div className="col-span-2 p-3 rounded-lg bg-[var(--au-surface)] border border-primary/15 flex flex-col">
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-[10px] font-bold text-foreground">Receita</h4>
                <BarChart3 className="w-3 h-3 text-primary" />
              </div>
              <div className="flex items-end gap-1 h-20 mt-auto">
                {[40, 70, 45, 90, 65, 85, 100].map((h, i) => (
                  <div key={i} className="flex-1 rounded-t-sm bg-gradient-to-t from-primary/30 to-primary" style={{ height: `${h}%` }} />
                ))}
              </div>
            </div>
          </div>
        </div>
        {/* Base */}
        <div className="mx-auto h-2 w-[105%] -mt-[1px] rounded-b-2xl bg-gradient-to-b from-[#1c1c21] to-[#060607] border-x border-b border-primary/20" />
      </div>
    </div>
  );
}

/* Phone mockup */
function PhoneMockup() {
  return (
    <div className="relative" style={{ perspective: "1500px" }}>
      <div
        className="relative w-[150px] sm:w-[170px] rounded-[28px] border-[3px] border-[#1c1c21] bg-[var(--au-surface)] shadow-[0_25px_60px_-10px_rgba(220,226,238,0.5)] overflow-hidden"
        style={{ transform: "rotateY(12deg) rotateX(-4deg)", transformStyle: "preserve-3d", aspectRatio: "9/19" }}
      >
        {/* Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-3 rounded-full bg-black z-10" />
        {/* Screen content */}
        <div className="h-full bg-gradient-to-b from-[#0c0c0f] to-[#060607] pt-7 px-2.5 pb-3 flex flex-col gap-2">
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-5 rounded-md bg-primary/20 flex items-center justify-center">
              <Sparkles className="w-3 h-3 text-primary" />
            </div>
            <span className="text-[8px] font-black text-foreground">Sylora</span>
          </div>
          <div className="rounded-lg bg-primary/10 border border-primary/30 p-2">
            <p className="text-[7px] text-muted-foreground">Saldo</p>
            <p className="text-sm font-black text-foreground">R$ 15.400</p>
            <div className="flex items-center gap-0.5 mt-0.5">
              <TrendingUp className="w-2 h-2 text-emerald-500" />
              <span className="text-[7px] font-bold text-emerald-500">+24%</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div className="rounded-md bg-[var(--au-surface)] border border-primary/15 p-1.5">
              <Users className="w-2.5 h-2.5 text-primary mb-0.5" />
              <p className="text-[6px] text-muted-foreground">Leads</p>
              <p className="text-[10px] font-black text-foreground">1.284</p>
            </div>
            <div className="rounded-md bg-[var(--au-surface)] border border-primary/15 p-1.5">
              <Globe className="w-2.5 h-2.5 text-primary mb-0.5" />
              <p className="text-[6px] text-muted-foreground">Sites</p>
              <p className="text-[10px] font-black text-foreground">542</p>
            </div>
          </div>
          <div className="rounded-md bg-gradient-to-r from-primary to-primary/70 py-1.5 text-center">
            <span className="text-[8px] font-black text-[var(--au-text)] uppercase tracking-wider">Criar site</span>
          </div>
          <div className="space-y-1 mt-auto">
            {[60, 80, 45].map((w, i) => (
              <div key={i} className="h-1 rounded-full bg-primary/20" style={{ width: `${w}%` }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function HeroSection() {
  const navigate = useNavigate();

  return (
    <section id="inicio" className="relative pt-20 pb-16 md:pt-28 md:pb-32 overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex justify-center">
          {/* LEFT — copy */}
          <div className="text-center max-w-3xl">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex justify-center mb-6"
            >
              <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-5 py-2 md:px-4 md:py-1.5 backdrop-blur-md shadow-[0_0_15px_rgba(220,226,238,0.2)]">
                <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 2, repeat: Infinity }}>
                  <Zap className="size-5 md:size-3.5 text-primary fill-primary" />
                </motion.div>
                <span className="text-xs md:text-[11px] font-black uppercase tracking-[0.1em] text-primary">
                  +5.000 empreendedores já vendem com Sylora
                </span>
              </div>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="text-3xl md:text-5xl lg:text-[54px] font-black tracking-tight text-foreground leading-[1.08] mb-5"
            >
              Feche Contratos de <span className="text-primary">R$500 a R$3.000</span> Criando Sites com IA em <span className="text-primary">10 Minutos</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="max-w-xl mx-auto text-[16px] md:text-[18px] text-[var(--au-text-3)] font-normal leading-[1.7] mb-8"
            >
              Escolha o plano ideal para você. Comece seu negócio{" "}
              <span className="text-foreground font-bold border-b-2 border-primary/40">com a liberdade</span> de crescer ainda mais.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.45 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10"
            >
              <Button variant="neon" size="xl" className="rounded-full shimmer-button px-10 h-14 text-base font-black uppercase tracking-widest w-full sm:w-auto" onClick={() => navigate("/auth?isSignup=true")}>
                <Zap className="size-5 mr-2 fill-current" />
                Assinar agora
              </Button>
              <Button variant="outline" size="xl" className="rounded-full px-10 h-14 text-base font-black uppercase tracking-widest border-2 hover:bg-primary/10 w-full sm:w-auto" onClick={() => document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" })}>
                Ver Planos
                <ArrowRightIcon className="size-5 ml-2" />
              </Button>
            </motion.div>

            {/* Métrica */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="inline-flex items-center gap-3 rounded-2xl border border-primary/20 bg-[var(--au-surface)]/80 backdrop-blur-md px-5 py-3 shadow-[0_0_25px_rgba(220,226,238,0.15)]"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-primary" />
              </div>
              <div className="text-left">
                <p className="text-[10px] font-bold uppercase tracking-widest text-primary">Contratos fechados</p>
                <p className="text-xl font-black text-foreground tabular-nums">R$ 15.400 <span className="text-emerald-500 text-xs">+24%</span></p>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Partners */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.3 }}
          className="mt-16 lg:mt-20 flex flex-col items-center gap-6"
        >
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--au-text-3)]">
            Parceiros oficiais
          </p>
          <div className="w-full max-w-3xl overflow-hidden relative [mask-image:linear-gradient(to_right,transparent,black_15%,black_85%,transparent)]">
            <div className="flex w-max gap-12 md:gap-16 animate-[marquee_25s_linear_infinite] grayscale opacity-70 hover:[animation-play-state:paused]">
              {[0, 1].map((dup) => (
                <div key={dup} className="flex items-center gap-12 md:gap-16 shrink-0">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-primary" />
                    <span className="text-xl font-black tracking-tighter text-foreground whitespace-nowrap">Lovable</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/a/aa/Google_Maps_icon_%282020%29.svg" alt="Google Maps" className="w-6 h-6" />
                    <span className="text-xl font-bold tracking-tight text-foreground/80 whitespace-nowrap">Google Maps</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md bg-primary/20 flex items-center justify-center">
                      <Zap className="w-4 h-4 text-primary" />
                    </div>
                    <span className="text-xl font-black tracking-tighter text-foreground italic whitespace-nowrap">HYPERBUILD PRO</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </motion.div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-primary/10 blur-[120px] rounded-full -z-10 pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-[500px] h-[500px] bg-primary/15 blur-[140px] rounded-full -z-10 pointer-events-none" />
    </section>
  );
}
