import React from 'react';
import { Button } from '@/components/ui/button';
import { AurenWordmark } from '@/components/auren/AurenLogo';
import { cn } from '@/lib/utils';
import { MenuToggleIcon } from '@/components/ui/menu-toggle-icon';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
	NavigationMenu,
	NavigationMenuContent,
	NavigationMenuItem,
	NavigationMenuLink,
	NavigationMenuList,
	NavigationMenuTrigger,
} from '@/components/ui/navigation-menu';
import { LucideIcon } from 'lucide-react';
import {
	MapPin,
	BookOpen,
	Code2,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

type LinkItem = {
	title: string;
	href: string;
	icon: LucideIcon;
	description?: string;
};

export function Header({ className }: { className?: string }) {
	const [open, setOpen] = React.useState(false);
	const scrolled = useScroll(10);
	const navigate = useNavigate();

	React.useEffect(() => {
		if (open) {
			document.body.style.overflow = 'hidden';
		} else {
			document.body.style.overflow = '';
		}
		return () => {
			document.body.style.overflow = '';
		};
	}, [open]);

	return (
		<motion.header
			initial={{ y: -100, opacity: 0 }}
			animate={{ y: 0, opacity: 1 }}
			transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
			className={cn(
				'fixed top-0 left-0 right-0 z-50 w-full transition-all duration-500 border-b border-transparent',
				className,
				scrolled || open
					? 'bg-background/80 backdrop-blur-xl border-[var(--au-border)] shadow-lg'
					: 'bg-transparent'
			)}
		>
			<nav
				className={cn(
					'container mx-auto flex items-center justify-between transition-all duration-500',
					scrolled ? 'h-16 px-4' : 'h-20 px-6',
				)}
			>
			{/* Logo */}
				<a href="#inicio" onClick={(e) => { e.preventDefault(); document.getElementById('inicio')?.scrollIntoView({ behavior: 'smooth' }); }} className="flex items-center shrink-0">
					<div className="p-1.5 flex items-center justify-center">
						<AurenWordmark size={30} />
					</div>
				</a>

				{/* Nav links — always visible on desktop */}
				<NavigationMenu className="hidden md:flex">
					<NavigationMenuList className="gap-2">
						<NavigationMenuItem>
							<NavigationMenuLink className="text-sm font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors px-4 py-2" asChild>
								<a href="#etapas" onClick={(e) => { e.preventDefault(); document.getElementById('etapas')?.scrollIntoView({ behavior: 'smooth' }); }}>
									Etapas
								</a>
							</NavigationMenuLink>
						</NavigationMenuItem>
						<NavigationMenuItem>
							<NavigationMenuLink className="text-sm font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors px-4 py-2" asChild>
								<a href="#pricing" onClick={(e) => { e.preventDefault(); document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' }); }}>
									Planos
								</a>
							</NavigationMenuLink>
						</NavigationMenuItem>
						<NavigationMenuItem>
							<NavigationMenuLink className="text-sm font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors px-4 py-2" asChild>
								<a href="#feedbacks" onClick={(e) => { e.preventDefault(); document.getElementById('feedbacks')?.scrollIntoView({ behavior: 'smooth' }); }}>
									Feedbacks
								</a>
							</NavigationMenuLink>
						</NavigationMenuItem>
						<NavigationMenuItem>
							<NavigationMenuLink className="text-sm font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors px-4 py-2" asChild>
								<a href="#faq" onClick={(e) => { e.preventDefault(); document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' }); }}>
									FAQ
								</a>
							</NavigationMenuLink>
						</NavigationMenuItem>
					</NavigationMenuList>
				</NavigationMenu>

				{/* Right side buttons */}
				<div className="hidden items-center gap-4 md:flex">
					<Button variant="ghost" className="font-bold uppercase tracking-widest text-xs" onClick={() => navigate('/auth')}>Entrar</Button>
					<Button variant="neon" className="shimmer-button font-bold uppercase tracking-widest text-xs px-6" onClick={() => navigate('/auth?isSignup=true')}>Criar Conta</Button>
				</div>
				<Button
					size="icon"
					variant="outline"
					onClick={() => setOpen(!open)}
					className="md:hidden"
					aria-expanded={open}
					aria-controls="mobile-menu"
					aria-label="Toggle menu"
				>
					<MenuToggleIcon open={open} className="size-5" duration={300} />
				</Button>
			</nav>
			<MobileMenu open={open} top={scrolled ? "top-[108px]" : "top-[124px]"} className="flex flex-col justify-between gap-2 overflow-y-auto">
				<NavigationMenu className="max-w-full">
					<div className="flex w-full flex-col gap-y-2">
						<span className="text-sm text-muted-foreground">Ferramentas</span>
						{productLinks.map((link) => (
							<ListItem key={link.title} {...link} />
						))}
					</div>
				</NavigationMenu>
				<div className="flex flex-col gap-2">
					<Button variant="outline" className="w-full bg-transparent" onClick={() => navigate('/auth')}>
						Entrar
					</Button>
					<Button variant="neon" className="w-full" onClick={() => navigate('/auth')}>Acessar Plataforma</Button>
				</div>
			</MobileMenu>
		</motion.header>
	);
}

type MobileMenuProps = React.ComponentProps<'div'> & {
	open: boolean;
	top?: string;
};

function MobileMenu({ open, top, children, className, ...props }: MobileMenuProps) {
	if (!open || typeof window === 'undefined') return null;

	return createPortal(
		<div
			id="mobile-menu"
			className={cn(
				'bg-background/95 supports-[backdrop-filter]:bg-background/50 backdrop-blur-lg',
				'fixed right-0 bottom-0 left-0 z-40 flex flex-col overflow-hidden border-y border-border md:hidden',
				top || 'top-[112px] md:top-[128px]'
			)}
		>
			<div
				data-slot={open ? 'open' : 'closed'}
				className={cn(
					'data-[slot=open]:animate-in data-[slot=open]:zoom-in-97 ease-out',
					'size-full p-4',
					className,
				)}
				{...props}
			>
				{children}
			</div>
		</div>,
		document.body,
	);
}

function ListItem({
	title,
	description,
	icon: Icon,
	className,
	href,
	...props
}: React.ComponentProps<typeof NavigationMenuLink> & LinkItem) {
	return (
		<NavigationMenuLink className={cn('w-full flex flex-row gap-x-2 hover:bg-secondary/50 rounded-sm p-2 transition-colors', className)} {...props} asChild>
			<a href={href}>
				<div className="bg-secondary/50 flex aspect-square size-10 items-center justify-center rounded-md border border-border shadow-sm">
					<Icon className="text-primary size-5" />
				</div>
				<div className="flex flex-col items-start justify-center">
					<span className="font-medium text-foreground">{title}</span>
					<span className="text-muted-foreground text-xs">{description}</span>
				</div>
			</a>
		</NavigationMenuLink>
	);
}

const productLinks: LinkItem[] = [
	{
		title: 'Criador de Sites',
		href: '/auth',
		description: 'Crie sites via Quiz com IA e Landing Pages em minutos',
		icon: Code2,
	},
	{
		title: 'Busca de Leads',
		href: '/auth',
		description: 'Encontre leads qualificados e empresas sem site no Brasil',
		icon: MapPin,
	},
];

function useScroll(threshold: number) {
	const [scrolled, setScrolled] = React.useState(false);

	const onScroll = React.useCallback(() => {
		setScrolled(window.scrollY > threshold);
	}, [threshold]);

	React.useEffect(() => {
		window.addEventListener('scroll', onScroll);
		return () => window.removeEventListener('scroll', onScroll);
	}, [onScroll]);

	React.useEffect(() => {
		onScroll();
	}, [onScroll]);

	return scrolled;
}
