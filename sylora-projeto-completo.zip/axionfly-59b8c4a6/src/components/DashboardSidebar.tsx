import { MapPin, Code2, LogOut, ShoppingBag, User, ChevronUp, Shield, PlayCircle, FileText, UserCircle, Sparkles, ExternalLink, Zap, LayoutDashboard, Rocket, Users } from "lucide-react";
import syloraLogo from "@/assets/axionfly-logo-x.png";
import { cn } from "@/lib/utils";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

type View = "prospeccao" | "sites" | "vendas" | "membros" | "admin" | "contrato" | "perfil" | "extensao-lovable" | "meu-grupo";

interface DashboardSidebarProps {
  active: View;
  onNavigate: (view: View) => void;
  onSignOut: () => void;
  userEmail?: string;
  userName?: string;
  isAdmin?: boolean;
  showGrupo?: boolean;
}

const navItems: { id: View; label: string; icon: React.ElementType }[] = [
  { id: "vendas", label: "Dashboard", icon: LayoutDashboard },
  { id: "sites", label: "Estúdio de Sites & Leads", icon: Rocket },
  { id: "contrato", label: "Contrato & Script", icon: FileText },
  { id: "extensao-lovable", label: "Extensão Lovable", icon: Sparkles },
  { id: "membros", label: "Área de Membros", icon: PlayCircle },
  { id: "perfil", label: "Meu Perfil", icon: UserCircle },
];

const DashboardSidebar = ({ active, onNavigate, onSignOut, userEmail, userName, isAdmin, showGrupo }: DashboardSidebarProps) => {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  let allNavItems = [...navItems];
  if (showGrupo) {
    allNavItems = [...allNavItems, { id: "meu-grupo" as View, label: "Seu Grupo", icon: Users }];
  }
  if (isAdmin) {
    allNavItems = [...allNavItems, { id: "admin" as View, label: "Painel Admin", icon: Shield }];
  }

  const displayName = userName || userEmail?.split("@")[0] || "Usuário";
  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <Sidebar collapsible="icon" className="bg-[var(--au-surface)] border-r border-[var(--au-border)]">
      <SidebarHeader className="border-b border-[var(--au-border)] px-4 py-4 bg-[var(--au-surface)]">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center">
            <img src={syloraLogo} alt="Sylora" width="120" height="24" decoding="async" className="h-6 w-auto" />
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="text-lg font-black text-[var(--au-text)] tracking-tighter leading-none">
                Sylora
              </span>
              <span className="text-[11px] text-muted-foreground font-bold uppercase tracking-[0.1em] mt-1">DASHBOARD</span>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-[var(--au-surface)]">
        <SidebarGroup>
          <SidebarGroupLabel className="text-[11px] font-bold uppercase tracking-[0.1em] text-[var(--au-text-3)] mb-2 px-4">
            FERRAMENTAS
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="px-2 space-y-1">
              {allNavItems.map(({ id, label, icon: Icon }) => (
                <SidebarMenuItem key={id}>
                  <SidebarMenuButton
                    onClick={() => onNavigate(id)}
                    isActive={active === id}
                    tooltip={label}
                    className={cn(
                      "transition-all duration-200 h-10 px-3 rounded-lg",
                      active === id 
                        ? "bg-[#1a2035] text-[#3B82F6] border-l-2 border-[#3B82F6] rounded-l-none" 
                        : "text-[var(--au-text-3)] hover:bg-[var(--au-surface-2)] hover:text-[var(--au-text)] border-l-2 border-transparent"
                    )}
                  >
                    <Icon className={cn("w-4 h-4 shrink-0", active === id ? "text-primary" : "text-inherit")} />
                    <span className="font-bold text-[11px] uppercase tracking-[0.1em]">{label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Minimal Hyperbuild Link */}
        {!collapsed && (
          <div className="mt-auto px-4 py-4">
            <div className="p-4 rounded-2xl bg-[var(--au-surface-2)] border border-[#3B82F6]/30 space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-[11px] font-bold text-primary uppercase tracking-[0.1em]">Parceria Ativa</span>
              </div>
              <p className="text-xs text-[var(--au-text-3)] leading-relaxed">
                Tokens ilimitados com <span className="text-[var(--au-text)] font-bold">Hyperbuild Pro</span>
              </p>
            </div>
          </div>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-[var(--au-border)] bg-[var(--au-surface)] p-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <DropdownMenuTrigger asChild>
                      <SidebarMenuButton size="lg" className="w-full h-12 rounded-xl hover:bg-[var(--au-surface-2)] transition-colors">
                        <div className="relative">
                          <Avatar className="w-8 h-8 shrink-0 ring-2 ring-white/5">
                            <AvatarFallback className="bg-[#3B82F6] text-[var(--au-text)] text-xs font-bold">
                              {initials}
                            </AvatarFallback>
                          </Avatar>
                          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-[#0d0d14] rounded-full animate-pulse" />
                        </div>
                        {!collapsed && (
                          <div className="flex-1 text-left min-w-0 ml-3">
                            <p className="text-sm font-bold text-foreground truncate leading-none mb-1">{displayName}</p>
                            <p className="text-[11px] text-[var(--au-text-3)] font-bold uppercase tracking-[0.1em]">Membro Premium</p>
                          </div>
                        )}
                        {!collapsed && <ChevronUp className="w-4 h-4 text-[var(--au-text-3)] shrink-0" />}
                      </SidebarMenuButton>
                    </DropdownMenuTrigger>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="bg-primary text-[var(--au-text)] border-none text-xs font-bold px-3 py-1.5">
                    {userEmail}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <DropdownMenuContent side="top" align="start" className="w-56 bg-[var(--au-surface)] border-[var(--au-border)] text-[var(--au-text)]">
                <DropdownMenuItem onClick={() => onNavigate("perfil")} className="hover:bg-[var(--au-surface-2)] focus:bg-[var(--au-surface-2)] py-2.5">
                  <UserCircle className="w-4 h-4 mr-3 text-primary" />
                  Meu Perfil
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onSignOut} className="text-red-400 hover:bg-red-400/10 focus:bg-red-400/10 py-2.5">
                  <LogOut className="w-4 h-4 mr-3" />
                  Sair da conta
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
};

export default DashboardSidebar;
