import { Fragment, lazy, Suspense, useEffect, useRef, useState } from "react";
import { markParts, useSiteText } from "@/lib/siteContent";
import { useLocation, useNavigate } from "react-router-dom";
import {
  AnimatePresence, motion, useInView, useMotionValueEvent, useScroll, useSpring,
} from "framer-motion";
import {
  ArrowLeft, ArrowRight, BarChart3, Bot, Briefcase, Check, Clock, Code2, Dumbbell, FileText, Globe, Infinity as InfinityIcon, Lock,
  MapPin, Menu, Monitor, Phone, Pizza, Scissors, Search, Send, ShieldCheck, Smile, Sparkles, TrendingUp, X, Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { AurenMark } from "./AurenLogo";
import "./auren.css";
import "./alvora-landing.css";

const PricingCards = lazy(() => import("@/components/PricingCards"));

const EASE = [0.22, 1, 0.36, 1] as const;
const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

/* ============================== TOPO ============================== */
const NAV = [
  ["Funcionalidades", "funcionalidades"],
  ["Como funciona", "etapas"],
  ["Planos", "pricing"],
] as const;
const NAV_IDS = NAV.map(([, id]) => id);

/** Qual seção está no meio da tela (funciona mesmo com seções carregadas depois). */
function useScrollSpy(ids: readonly string[]) {
  const [active, setActive] = useState("");
  useEffect(() => {
    let raf = 0;
    const calc = () => {
      raf = 0;
      let cur = "";
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= window.innerHeight * 0.38) cur = id;
      }
      setActive((p) => (p === cur ? p : cur));
    };
    const on = () => { if (!raf) raf = requestAnimationFrame(calc); };
    calc();
    window.addEventListener("scroll", on, { passive: true });
    window.addEventListener("resize", on);
    return () => {
      window.removeEventListener("scroll", on);
      window.removeEventListener("resize", on);
      cancelAnimationFrame(raf);
    };
  }, [ids]);
  return active;
}

const TopBar = () => {
  const t = useSiteText();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const active = useScrollSpy(NAV_IDS);
  const { scrollY, scrollYProgress } = useScroll();
  const prog = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.4 });
  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 24));
  const go = (id: string) => { setOpen(false); scrollTo(id); };

  return (
    <div className="al-top">
      <div className="al-ticker"><span>— {t("site_ticker")} —</span></div>
      <header className={cn("al-bar", scrolled && "is-small")}>
        <div className="al-bar-in">
          <button type="button" onClick={() => go("inicio")} aria-label="Início" className="al-brand">
            <AurenMark size={42} />
          </button>

          <nav className="al-nav" aria-label="Seções">
            {NAV.map(([label, id]) => (
              <button key={id} type="button" onClick={() => go(id)} className={cn("al-link", active === id && "on")}>{label}</button>
            ))}
          </nav>

          <div className="flex items-center gap-2 justify-self-end">
            <button type="button" onClick={() => navigate("/auth")} className="al-link !px-2 sm:!px-4 !text-[#0A0A0C]">Entrar</button>
            <button type="button" onClick={() => navigate("/auth?isSignup=true")} className="al-btn dark" style={{ height: 40, padding: "0 20px" }}>Assinar</button>
            <button type="button" aria-label={open ? "Fechar menu" : "Abrir menu"} onClick={() => setOpen((o) => !o)} className="md:hidden al-btn line" style={{ width: 40, height: 40, padding: 0 }}>
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        <motion.i className="al-bar-prog" style={{ scaleX: prog }} aria-hidden />
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            className="al-menu mt-2 md:hidden"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: EASE }}
          >
            {NAV.map(([label, id]) => (
              <button key={id} type="button" onClick={() => go(id)} className={cn("al-link w-full !h-12 text-left", active === id && "on")}>{label}</button>
            ))}
            <button type="button" onClick={() => navigate("/auth")} className="al-link w-full !h-12 text-left !text-[#0A0A0C]">Entrar</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/* ============================== HERO ============================== */
const partners = [
  { icon: MapPin, name: "Google Maps" },
  { icon: Zap, name: "Créditos Infinitos" },
  { icon: ShieldCheck, name: "Applyfy" },
  { icon: Sparkles, name: "Google AI Studio" },
];

/** O alvo: anéis que se desenham, marcas girando devagar e um radar varrendo. */
const Target = () => (
  <div className="al-target" aria-hidden>
    <svg viewBox="0 0 1000 1000" fill="none">
      {[110, 200, 290, 380, 470].map((r, i) => (
        <motion.circle
          key={r} cx="500" cy="500" r={r} stroke="rgba(10,10,12,0.13)" strokeWidth="1.2"
          initial={{ pathLength: 0, opacity: 0 }} animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 1.8, delay: 0.15 + i * 0.18, ease: EASE }}
        />
      ))}
      <g className="ticks"><circle cx="500" cy="500" r="490" stroke="rgba(10,10,12,0.4)" strokeWidth="6" strokeDasharray="1.5 22" /></g>
      <motion.path d="M500 20V980M20 500H980" stroke="rgba(10,10,12,0.1)" strokeWidth="1" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4, duration: 1 }} />
      <circle cx="500" cy="500" r="5" fill="#0A0A0C" />
    </svg>
    <div className="sweep" />
  </div>
);

const useMagnet = <T extends HTMLElement>() => {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || window.matchMedia("(pointer: coarse)").matches) return;
    const move = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.18}px, ${(e.clientY - r.top - r.height / 2) * 0.28}px)`;
    };
    const leave = () => { el.style.transform = ""; };
    el.addEventListener("mousemove", move);
    el.addEventListener("mouseleave", leave);
    return () => { el.removeEventListener("mousemove", move); el.removeEventListener("mouseleave", leave); };
  }, []);
  return ref;
};

const Line = ({ children, delay }: { children: React.ReactNode; delay: number }) => (
  <span className="al-line">
    <motion.span initial={{ y: "110%" }} animate={{ y: 0 }} transition={{ duration: 1.05, delay, ease: EASE }}>{children}</motion.span>
  </span>
);

/** O construtor trabalhando sozinho: só formas, sem texto novo. */
const Hero = () => {
  const t = useSiteText();
  const navigate = useNavigate();
  const magnet = useMagnet<HTMLButtonElement>();

  return (
    <section id="inicio" className="al-hero">
      <i className="al-dots" aria-hidden />
      <Target />

      <div className="mx-auto max-w-[1240px]">
        <h1 className="al-h1">
          <Line delay={0.35}>{t("site_hero_1")}</Line>
          <Line delay={0.5}>{t("site_hero_2")}</Line>
        </h1>

        <motion.p className="al-sub" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.85, ease: EASE }}>
          {markParts(t("site_hero_sub")).map((p, i) => (p.mark ? <span key={i} className="al-u">{p.t}</span> : <Fragment key={i}>{p.t}</Fragment>))}
        </motion.p>

        <motion.div className="al-cta" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 1, ease: EASE }}>
          <button ref={magnet} type="button" onClick={() => navigate("/auth?isSignup=true")} className="al-btn dark lg w-full sm:w-auto" style={{ transition: "transform .25s ease, box-shadow .3s ease" }}>
            <Zap /> {t("site_hero_cta")} <ArrowRight />
          </button>
          <button type="button" onClick={() => scrollTo("pricing")} className="al-btn line lg w-full sm:w-auto">{t("site_hero_cta2")}</button>
        </motion.div>
      </div>
    </section>
  );
};

/* ======================== FUNCIONALIDADES ======================== */
const features = [
  { icon: Code2, tag: "Principal", title: "Criador de Sites e Apps com IA", desc: "Escolha entre 30+ nichos, personalize cores, fontes e estilo de design — a IA monta o site e app completo em minutos. Design profissional pronto para vender." },
  { icon: InfinityIcon, tag: "Infinito", title: "Créditos Infinitos", desc: "Crie sites sem limites de créditos. Sistema exclusivo para garantir sua escala total." },
  { icon: Globe, tag: "Sem limites", title: "Domínios e Hospedagem Infinitos", desc: "Publique quantos sites e apps quiser, com domínio personalizado e hospedagem inclusa para todos os seus projetos." },
  { icon: MapPin, tag: "Global", title: "Prospecção Automática Global", desc: "Selecione qualquer país, estado e cidade. O sistema busca negócios sem site e entrega nome, telefone e endereço prontos pra fechar negócio." },
  { icon: FileText, tag: "Automático", title: "Gerador de Contrato", desc: "Gere contratos profissionais personalizados com nome do cliente, serviço e valores — prontos para enviar e fechar negócio na hora, com segurança jurídica." },
  { icon: BarChart3, tag: "Gestão", title: "Dashboard de Vendas", desc: "Acompanhe seus lucros, clientes atendidos e sites criados em um painel completo. Tenha controle total do seu faturamento e crescimento." },
  { icon: TrendingUp, tag: "Novo", title: "Avaliador de Preço de Sites", desc: "Descubra exatamente quanto cobrar por cada site. Responda perguntas sobre nicho, recursos e perfil do cliente — a IA calcula o preço justo de mercado para você fechar com confiança." },
  { icon: Bot, tag: "Novo", title: "Mentor IA", desc: "Uma IA treinada com todo o método. Tire qualquer dúvida sobre scripts, prospecção, fechamento e ferramentas — resposta na hora, 24 horas por dia." },
  { icon: Briefcase, tag: "Novo", title: "Portfólio IA", desc: "Monte um portfólio profissional pronto pra fechar cliente em minutos. A IA organiza seus sites, depoimentos e resultados em uma página única que vende por você." },
];

const Partners = () => (
  <div className="al-partners" style={{ marginTop: 72 }}>
    <p className="al-eyebrow">Parceiros oficiais</p>
    <div className="al-marq">
      <div className="al-marq-track">
        {[...partners, ...partners, ...partners, ...partners, ...partners, ...partners, ...partners, ...partners].map((p, i) => (
          <span key={i} className="al-partner"><span className="ic"><p.icon /></span>{p.name}</span>
        ))}
      </div>
    </div>
  </div>
);

/** Cada função aparece "dentro da ferramenta": uma tela de verdade, animada, que reinicia a cada troca. */
const rise = (d: number) => ({ initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.5, delay: d, ease: EASE } });
const grow = (d: number, w: string) => ({ initial: { width: 0 }, animate: { width: w }, transition: { duration: 0.7, delay: d, ease: EASE } });

const Screen = ({ i }: { i: number }) => {
  if (i === 0)
    return (
      <div className="al-sc two">
        <div className="col">
          <p className="lab">1 · Nicho</p>
          <div className="grid grid-cols-2 gap-2">
            {[[Scissors, "Barbearia"], [Pizza, "Pizzaria"], [Smile, "Clínica"], [Dumbbell, "Academia"]].map(([Ic, n], k) => {
              const I = Ic as typeof Scissors;
              return <motion.span key={n as string} className={cn("pick", k === 0 && "on")} {...rise(0.1 + k * 0.08)}><I />{n as string}</motion.span>;
            })}
          </div>
          <p className="lab mt-3">2 · Cores</p>
          <div className="flex gap-2">
            {["#D4AF37", "#1A1A2E", "#F5F5F4", "#34d399"].map((c, k) => <motion.i key={c} className="sw" style={{ background: c }} {...rise(0.5 + k * 0.07)} />)}
          </div>
          <motion.div className="gen" {...rise(0.9)}>
            <span>Gerando o site…</span>
            <i><motion.b initial={{ width: "6%" }} animate={{ width: "100%" }} transition={{ duration: 2.4, delay: 1, ease: EASE }} /></i>
          </motion.div>
        </div>
        <motion.div className="pv" {...rise(0.3)}>
          <div className="pvbar"><i /><i /><i /></div>
          <div className="pvbody">
            <motion.p className="brand" {...rise(0.9)}>Barbearia Dom Corte</motion.p>
            <motion.h4 {...rise(1.1)}>Estilo & Tradição</motion.h4>
            <motion.span className="cta" {...rise(1.3)}>Agendar horário</motion.span>
            <div className="grid grid-cols-3 gap-1.5 mt-3">{[0, 1, 2].map((k) => <motion.span key={k} className="card" {...rise(1.5 + k * 0.12)}><b /><u /></motion.span>)}</div>
          </div>
        </motion.div>
      </div>
    );
  if (i === 1)
    return (
      <div className="al-sc center">
        <div className="orbit">
          <svg viewBox="0 0 200 200" aria-hidden>
            <circle cx="100" cy="100" r="92" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1.5" />
            <motion.circle cx="100" cy="100" r="92" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="60 520" animate={{ rotate: 360 }} transition={{ duration: 5, repeat: Infinity, ease: "linear" }} style={{ transformOrigin: "100px 100px" }} />
          </svg>
          <motion.span className="inf" initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, ease: EASE }}>∞</motion.span>
        </div>
        <motion.p className="lab" {...rise(0.4)}>créditos disponíveis</motion.p>
        <div className="flex flex-wrap justify-center gap-2 mt-3">
          {["Sites sem limite", "Apps sem limite", "Sem renovação"].map((t, k) => <motion.span key={t} className="pill" {...rise(0.6 + k * 0.12)}><Check />{t}</motion.span>)}
        </div>
      </div>
    );
  if (i === 2)
    return (
      <div className="al-sc">
        <div className="tbl">
          <div className="th"><span>Domínio</span><span>SSL</span><span>Status</span></div>
          {["barbeariadomcorte.com.br", "pizzariaforno.com.br", "clinicasorrir.com.br", "studioaurora.com.br"].map((d, k) => (
            <motion.div key={d} className="tr" {...rise(0.15 + k * 0.28)}>
              <span className="d"><Globe />{d}</span>
              <span className="ssl"><Lock />ativo</span>
              <span className="live"><i />no ar</span>
            </motion.div>
          ))}
        </div>
        <motion.div className="host" {...rise(1.4)}>
          <span>Hospedagem inclusa</span>
          <i><motion.b initial={{ width: "4%" }} animate={{ width: "100%" }} transition={{ duration: 1.4, delay: 1.5, ease: EASE }} /></i>
          <em>∞</em>
        </motion.div>
      </div>
    );
  if (i === 3)
    return (
      <div className="al-sc two">
        <div className="col">
          <p className="lab">Onde buscar</p>
          {[["País", "Brasil"], ["Estado", "Alagoas"], ["Cidade", "Maceió"]].map(([l, v], k) => (
            <motion.div key={l} className="field" {...rise(0.1 + k * 0.12)}><em>{l}</em><span>{v}</span></motion.div>
          ))}
          <motion.span className="btnw" {...rise(0.6)}><Search /> Buscar leads</motion.span>
        </div>
        <div className="map">
          <i className="radar" />
          {[[24, 30], [58, 22], [40, 62], [74, 54], [18, 70]].map(([x, y], k) => (
            <motion.span key={k} className="pin" style={{ left: `${x}%`, top: `${y}%` }} initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.8 + k * 0.25, type: "spring", stiffness: 300, damping: 14 }}><MapPin /></motion.span>
          ))}
          <div className="leads">
            {[["Studio Aurora", "(82) 9 9•••-••12"], ["Auto Center Sul", "(82) 9 8•••-••40"], ["Padaria Pão Quente", "(82) 9 9•••-••77"]].map(([n, t], k) => (
              <motion.div key={n} className="lead" {...rise(1.4 + k * 0.25)}><b>{n}</b><span>{t}</span><u>sem site</u></motion.div>
            ))}
          </div>
        </div>
      </div>
    );
  if (i === 4)
    return (
      <div className="al-sc center">
        <motion.div className="paper" {...rise(0.1)}>
          <p className="ph">Contrato de prestação de serviços</p>
          {[["Cliente", "Barbearia Dom Corte"], ["Serviço", "Site profissional + app"], ["Valor", "R$ 1.500,00"]].map(([l, v], k) => (
            <motion.div key={l} className="row" {...rise(0.4 + k * 0.35)}><em>{l}</em><span>{v}</span></motion.div>
          ))}
          <div className="lines">{[92, 100, 78].map((w, k) => <motion.u key={k} {...grow(1.5 + k * 0.15, `${w}%`)} />)}</div>
          <div className="sign">
            <svg viewBox="0 0 120 34" fill="none" aria-hidden>
              <motion.path d="M4 24c8-20 12-20 10-4s6 6 14-8c4 10 8 12 14 2s10 6 18-2 14 4 22-4" stroke="#0A0A0C" strokeWidth="2" strokeLinecap="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.1, delay: 2.1 }} />
            </svg>
            <motion.span className="stamp" initial={{ opacity: 0, scale: 1.6, rotate: -14 }} animate={{ opacity: 1, scale: 1, rotate: -8 }} transition={{ delay: 3.1, duration: 0.35 }}>assinado</motion.span>
          </div>
        </motion.div>
      </div>
    );
  if (i === 5)
    return (
      <div className="al-sc">
        <div className="kpis">
          {[["Faturamento", "R$ 4.800"], ["Clientes", "6"], ["Sites criados", "9"]].map(([l, v], k) => (
            <motion.div key={l} className="kpi" {...rise(0.1 + k * 0.12)}><em>{l}</em><b>{v}</b></motion.div>
          ))}
        </div>
        <div className="chart">
          {[34, 46, 40, 62, 54, 78, 92].map((h, k) => <motion.i key={k} initial={{ height: 0 }} animate={{ height: `${h}%` }} transition={{ duration: 0.7, delay: 0.5 + k * 0.09, ease: EASE }} />)}
        </div>
        <div className="sales">
          {[["Barbearia Dom Corte", "R$ 1.500"], ["Studio Aurora", "R$ 1.200"]].map(([n, v], k) => (
            <motion.div key={n} className="sale" {...rise(1.3 + k * 0.2)}><span className="av">{n[0]}</span><b>{n}</b><em>{v}</em><u>pago</u></motion.div>
          ))}
        </div>
      </div>
    );
  if (i === 6)
    return (
      <div className="al-sc center">
        <div className="flex flex-wrap justify-center gap-2">
          {["Barbearia", "Agendamento online", "Cliente pequeno"].map((t, k) => <motion.span key={t} className="pill" {...rise(0.1 + k * 0.3)}><Check />{t}</motion.span>)}
        </div>
        <motion.p className="lab mt-5" {...rise(1.1)}>preço justo de mercado</motion.p>
        <motion.p className="price" {...rise(1.25)}>R$ 1.200 <span>a R$ 1.800</span></motion.p>
        <div className="range"><motion.i initial={{ left: "8%", right: "92%" }} animate={{ left: "34%", right: "28%" }} transition={{ duration: 1.1, delay: 1.4, ease: EASE }} /></div>
        <motion.span className="pill ok mt-4" {...rise(2.2)}>Feche com confiança</motion.span>
      </div>
    );
  if (i === 7)
    return (
      <div className="al-sc chat">
        <motion.div className="bub me" {...rise(0.15)}>Como abordo uma barbearia sem site?</motion.div>
        <motion.div className="typing" initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 1, 0] }} transition={{ duration: 1.1, delay: 0.7, times: [0, 0.1, 0.85, 1] }}><i /><i /><i /></motion.div>
        <motion.div className="bub" {...rise(1.8)}>
          <b>Em 3 passos:</b>
          <ol>
            <li>Mostre o que ela perde sem presença online.</li>
            <li>Envie uma prévia pronta do site dela.</li>
            <li>Proponha uma conversa rápida para fechar.</li>
          </ol>
        </motion.div>
        <div className="inp"><span>Pergunte ao Mentor IA…</span><i><Send /></i></div>
      </div>
    );
  return (
    <div className="al-sc center">
      <motion.div className="pv wide" {...rise(0.1)}>
        <div className="pvbar"><i /><i /><i /></div>
        <div className="pvbody">
          <motion.p className="brand" {...rise(0.4)}>Marina Costa</motion.p>
          <motion.h4 {...rise(0.55)}>Criadora de sites para negócios locais</motion.h4>
          <div className="grid grid-cols-3 gap-1.5 mt-3">{[0, 1, 2].map((k) => <motion.span key={k} className="shot" {...rise(0.8 + k * 0.15)} />)}</div>
          <motion.div className="quote" {...rise(1.5)}>“O site ficou pronto em dias e já trouxe clientes.”</motion.div>
        </div>
      </motion.div>
    </div>
  );
};

const FeatureCard = ({ i }: { i: number }) => {
  const ref = useRef<HTMLElement>(null);
  const seen = useInView(ref, { amount: 0.35, once: true });
  const f = features[i];
  return (
    <article ref={ref} className="al-fc au-dark">
      <div className="al-fc-view">{seen && <Screen i={i} />}</div>
      <div className="al-fc-txt">
        <div className="top">
          <span className="ic"><f.icon /></span>
          <span className="tg">{f.tag}</span>
        </div>
        <h3>{f.title}</h3>
        <p>{f.desc}</p>
      </div>
    </article>
  );
};

const Features = () => {
  const t = useSiteText();
  const rail = useRef<HTMLDivElement>(null);
  const [paused, setPaused] = useState(false);
  const [edge, setEdge] = useState({ start: true, end: false });
  const [idx, setIdx] = useState(0);
  const seen = useInView(rail, { amount: 0.3 });

  const step = () => {
    const r = rail.current, c = r?.querySelector<HTMLElement>(".al-fc");
    return r && c ? c.offsetWidth + parseFloat(getComputedStyle(r).columnGap || "14") : 0;
  };
  const sync = () => {
    const r = rail.current; if (!r) return;
    setEdge({ start: r.scrollLeft < 4, end: r.scrollLeft + r.clientWidth >= r.scrollWidth - 4 });
    setIdx(Math.min(features.length - 1, Math.round(r.scrollLeft / (step() || 1))));
  };
  const to = (i: number) => rail.current?.scrollTo({ left: i * step(), behavior: "smooth" });
  const go = (d: 1 | -1) => {
    const r = rail.current; if (!r) return;
    if (d === 1 && r.scrollLeft + r.clientWidth >= r.scrollWidth - 4) r.scrollTo({ left: 0, behavior: "smooth" });
    else r.scrollBy({ left: d * step(), behavior: "smooth" });
  };

  // passa um card para o lado a cada 2s, enquanto está à vista e sem ninguém interagindo
  useEffect(() => {
    if (!seen || paused) return;
    const id = window.setInterval(() => go(1), 2000);
    return () => window.clearInterval(id);
  }, [seen, paused]);

  return (
    <section id="funcionalidades" className="al-sec" style={{ paddingBottom: 0 }}>
      <div className="al-wrap">
        <div className="al-head2">
          <div>
            <span className="al-tag">Funcionalidades premium</span>
            <h2 className="al-h2 mt-6">{t("site_feat_title")}</h2>
          </div>
          <p className="al-lead">{t("site_feat_lead")}</p>
        </div>
        <div
          onPointerEnter={(e) => e.pointerType === "mouse" && setPaused(true)}
          onPointerLeave={(e) => e.pointerType === "mouse" && setPaused(false)}
          onTouchStart={() => setPaused(true)}
          onTouchEnd={() => window.setTimeout(() => setPaused(false), 4000)}
        >
          <div ref={rail} className={cn("al-fgrid", !edge.start && "from", !edge.end && "more")} onScroll={sync}>
            {features.map((_, i) => <FeatureCard key={i} i={i} />)}
          </div>
          <div className="al-fctrl">
            <span className="al-fcount" aria-hidden><b>{String(idx + 1).padStart(2, "0")}</b> / {String(features.length).padStart(2, "0")}</span>
            <button type="button" onClick={() => go(-1)} disabled={edge.start} className="al-arrow" aria-label="Funcionalidade anterior"><ArrowLeft /></button>
            <button type="button" onClick={() => go(1)} className="al-arrow dark" aria-label="Próxima funcionalidade"><ArrowRight /></button>
            <span className="al-fdots" role="tablist" aria-label="Funcionalidades">
              {features.map((x, i) => <button key={i} type="button" role="tab" aria-selected={i === idx} aria-label={x.title} className={cn(i === idx && "on")} onClick={() => to(i)} />)}
            </span>
          </div>
        </div>
      </div>
      <Partners />
    </section>
  );
};

/* ========================= COMO FUNCIONA ========================= */
const steps = [
  { title: "Ative sua Ferramenta", desc: "Assine, acesse a plataforma e conecte a IA. Em poucos cliques, sua base de operação está pronta para prospectar e criar sites e apps." },
  { title: "Crie Sites e Apps via Quiz com IA", desc: "Responda algumas perguntas rápidas sobre o negócio e a IA gera o site e app completo. Use a busca de leads para encontrar empresas sem site na sua cidade." },
  { title: "Venda e Escale com Leads", desc: "Use nossa busca para encontrar clientes reais, apresente o site pronto e feche o contrato. Acompanhe seus resultados e continue escalando." },
];

/** Miniatura de cada etapa: desenhada com formas, sem texto novo. Acende quando a etapa fica ativa. */
const StepArt = ({ i, on }: { i: number; on: boolean }) => {
  if (i === 0)
    return (
      <div className="relative h-full flex flex-col items-center justify-center gap-6">
        <div className="relative w-[112px] h-[58px] rounded-full border border-white/20" style={{ background: on ? "linear-gradient(180deg,#2A2B31,#16161A)" : "rgba(255,255,255,.04)" }}>
          <motion.span className="absolute top-[6px] w-[44px] h-[44px] rounded-full bg-white" style={{ boxShadow: on ? "0 0 30px rgba(255,255,255,.6)" : "none" }} animate={{ left: on ? 60 : 6 }} transition={{ duration: 0.7, ease: EASE }} />
        </div>
        <div className="flex gap-1.5">
          {[0, 1, 2, 3, 4].map((k) => (
            <motion.i key={k} className="block w-8 h-[3px] rounded-full bg-white" animate={{ opacity: on ? 0.9 : 0.15 }} transition={{ duration: 0.4, delay: on ? 0.3 + k * 0.1 : 0 }} />
          ))}
        </div>
      </div>
    );
  if (i === 1)
    return (
      <div className="relative h-full flex items-center justify-center">
        <div className="w-[70%] rounded-xl border border-white/15 bg-white/[0.04] overflow-hidden">
          <div className="flex gap-1 px-3 py-2 border-b border-white/10">{[0, 1, 2].map((k) => <i key={k} className="block w-1.5 h-1.5 rounded-full bg-white/30" />)}</div>
          <div className="p-3.5 space-y-2.5">
            <div className="flex gap-1.5">
              {[0, 1, 2].map((k) => (
                <motion.i key={k} className="block h-5 rounded-full border border-white/25" style={{ flex: k === 1 ? 1.4 : 1 }} animate={{ background: on && k === 1 ? "#fff" : "rgba(255,255,255,0)" }} transition={{ duration: 0.5, delay: on ? 0.45 : 0 }} />
              ))}
            </div>
            {[78, 56, 66].map((w, k) => (
              <motion.i key={k} className="block h-[5px] rounded-full bg-white" initial={false} animate={{ width: on ? `${w}%` : "14%", opacity: on ? 0.55 : 0.15 }} transition={{ duration: 0.8, delay: on ? 0.5 + k * 0.12 : 0, ease: EASE }} />
            ))}
          </div>
        </div>
      </div>
    );
  return (
    <div className="relative h-full flex items-end justify-center gap-3 pb-6 px-8">
      {[26, 38, 34, 56, 78, 100].map((h, k) => (
        <motion.i key={k} className="block flex-1 max-w-[30px] rounded-t-md origin-bottom"
          style={{ height: `${h * 0.78}%`, background: k === 5 ? "#fff" : "linear-gradient(180deg,rgba(255,255,255,.35),rgba(255,255,255,.06))", boxShadow: k === 5 && on ? "0 0 30px rgba(255,255,255,.55)" : "none" }}
          initial={false} animate={{ scaleY: on ? 1 : 0.18, opacity: on ? 1 : 0.45 }} transition={{ duration: 0.9, delay: on ? k * 0.09 : 0, ease: EASE }} />
      ))}
    </div>
  );
};

const HowItWorks = () => {
  const t = useSiteText();
  const ref = useRef<HTMLDivElement>(null);
  const seen = useInView(ref, { amount: 0.35 });
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const last = steps.length - 1;

  // avança sozinho enquanto o bloco está na tela
  useEffect(() => {
    if (!seen || paused) return;
    const id = window.setInterval(() => setIndex((i) => (i >= last ? 0 : i + 1)), 6500);
    return () => window.clearInterval(id);
  }, [seen, paused, last]);

  const go = (d: number) => setIndex((i) => Math.min(last, Math.max(0, i + d)));

  return (
    <section id="etapas" className="al-sec" style={{ background: "var(--au-surface)", borderBlock: "1px solid var(--au-border)" }}>
      <div className="al-wrap">
        <div className="text-center mx-auto max-w-[820px]">
          <span className="al-tag">Como funciona</span>
          <h2 className="al-h2 mt-6">{t("site_how_title")}</h2>
          <p className="al-lead mt-6 mx-auto max-w-[620px]">{t("site_how_lead")}</p>
        </div>

        <div ref={ref} className="al-hs" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
          {/* trilho: as três etapas lado a lado, ligadas por uma linha que avança */}
          <div className="al-hs-rail">
            <i className="line" aria-hidden><b style={{ width: `${(index / last) * 100}%` }} /></i>
            {steps.map((_, i) => (
              <button key={i} type="button" onClick={() => setIndex(i)} className={cn("al-hs-node", i <= index && "on", i === index && "cur")} aria-label={`Etapa 0${i + 1}`}>
                <span>0{i + 1}</span>
                <em>Etapa 0{i + 1}</em>
              </button>
            ))}
          </div>

          <div className="al-hs-view">
            <motion.div
              className="al-hs-track"
              animate={{ x: `-${index * 100}%` }}
              transition={{ type: "spring", stiffness: 110, damping: 21 }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.18}
              onDragEnd={(_, info) => { if (info.offset.x < -60) go(1); else if (info.offset.x > 60) go(-1); }}
            >
              {steps.map((st, i) => (
                <article key={i} className="al-hs-slide" aria-hidden={i !== index}>
                  <div className="al-hs-card">
                    <div className="al-art au-dark"><StepArt i={i} on={i === index} /></div>
                    <div className="al-hs-txt">
                      <div className="meta"><span>Etapa 0{i + 1}</span><span className="tabular-nums">0{i + 1}/03</span></div>
                      <h3>{st.title}</h3>
                      <p>{st.desc}</p>
                      <span className="al-hs-big" aria-hidden>0{i + 1}</span>
                    </div>
                  </div>
                </article>
              ))}
            </motion.div>
          </div>

          <div className="al-hs-ctrl">
            <button type="button" onClick={() => go(-1)} disabled={index === 0} className="al-arrow" aria-label="Etapa anterior"><ArrowLeft /></button>
            <button type="button" onClick={() => go(1)} disabled={index === last} className="al-arrow dark" aria-label="Próxima etapa"><ArrowRight /></button>
          </div>
        </div>
      </div>
    </section>
  );
};

/* ============================= RODAPÉ ============================= */
const Footer = () => (
  <footer className="al-night au-dark" style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
    <div className="al-wrap pt-24 pb-10">
      <div className="grid grid-cols-2 md:grid-cols-[1.6fr_1fr_1fr_1fr] gap-10">
        <div className="col-span-2 md:col-span-1">
          <AurenMark size={76} className="text-white" />
          <p className="text-[14.5px] text-[var(--au-text-2)] mt-6 max-w-[340px] leading-relaxed">
            A plataforma completa para criar e vender sites com IA — do primeiro lead ao contrato fechado.
          </p>
          <div className="flex gap-3 mt-6">
            {[Globe, Monitor, Phone].map((Icon, i) => (
              <span key={i} className="grid place-items-center w-10 h-10 rounded-full border border-white/15 text-white"><Icon className="w-4 h-4" /></span>
            ))}
          </div>
        </div>
        {[
          ["Plataforma", [["Funcionalidades", "#funcionalidades"], ["Como funciona", "#etapas"], ["Planos", "#pricing"], ["Parcerias", "#inicio"]]],
          ["Empresa", [["Blog", "#"], ["Contato", "#"]]],
          ["Legal", [["Termos de Uso", "/termos"], ["Privacidade", "/privacidade"], ["Avisos Legais", "/legal"], ["Cookies", "/cookies"]]],
        ].map(([title, links]) => (
          <div key={title as string}>
            <p className="text-[11px] font-extrabold uppercase tracking-[0.2em] text-white">{title as string}</p>
            <ul className="mt-5 space-y-3">
              {(links as string[][]).map(([label, href]) => (
                <li key={label}>
                  <a href={href} className="text-[14.5px] text-[var(--au-text-2)] hover:text-white transition-colors">{label}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="h-px bg-white/10 mt-16" />
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5 mt-8">
        <div className="flex flex-wrap gap-x-8 gap-y-3">
          {[[Lock, "SSL Seguro"], [ShieldCheck, "Pagamento protegido"], [Clock, "Suporte 24/7"]].map(([Icon, label]) => {
            const I = Icon as React.ElementType;
            return (
              <span key={label as string} className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[var(--au-text-2)]">
                <I className="w-3.5 h-3.5 text-white" /> {label as string}
              </span>
            );
          })}
        </div>
        <p className="text-[12.5px] text-[var(--au-text-3)]">© 2025 Todos os direitos reservados.</p>
      </div>
    </div>
  </footer>
);

/* ============================= PÁGINA ============================= */
const AurenLanding = () => {
  const { hash } = useLocation();
  useEffect(() => {
    if (!hash) return;
    const id = hash.slice(1);
    const tm = window.setTimeout(() => scrollTo(id), 400);
    return () => window.clearTimeout(tm);
  }, [hash]);
  return (
  <div className="auren al-page min-h-screen overflow-x-clip relative">
    <TopBar />
    <main className="relative z-[1]">
      <Hero />
      <Features />
      <HowItWorks />
      <Suspense fallback={<div className="min-h-[600px] bg-[#060607]" />}>
        <PricingCards />
      </Suspense>
    </main>
    <Footer />
  </div>
  );
};

export default AurenLanding;
