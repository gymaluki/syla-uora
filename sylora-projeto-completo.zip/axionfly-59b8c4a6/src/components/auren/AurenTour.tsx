import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Bot, DollarSign, Gift, Rocket, Search, Sparkles, X } from "lucide-react";
import "./presente/presente.css";

const STORAGE_KEY = "sylora_onboarding_completed_v2";

const steps = [
  { icon: Sparkles, title: "Boas-vindas à Sylora", description: "Sua plataforma completa para criar sites com inteligência artificial, prospectar clientes e fechar vendas todos os dias. Vamos te mostrar rapidinho onde fica cada ferramenta do painel.", highlight: "Bora começar o passo a passo!" },
  { icon: DollarSign, title: "Dashboard", description: "Cadastre cada cliente fechado, acompanhe seu faturamento, o status dos pagamentos e o seu progresso mensal em tempo real. É o centro de controle do seu negócio.", highlight: "Controle financeiro completo" },
  { icon: Sparkles, title: "Ativar Créditos", description: "Baixe e ative os Créditos Infinitos para criar sem limites. Aqui você pega o seu token de licença e o arquivo de instalação.", highlight: "Créditos infinitos liberados" },
  { icon: Search, title: "Diagnóstico de Sites", description: "Cole o site de qualquer possível cliente e receba um diagnóstico completo com pontos a melhorar. Perfeito para chegar em uma reunião mostrando valor de verdade.", highlight: "Diagnóstico profissional em segundos" },
  { icon: Rocket, title: "Meu Portfólio", description: "Gere um portfólio profissional em minutos usando IA. Responda algumas perguntas e o sistema monta o prompt otimizado para abrir no Google AI Studio e nas outras plataformas suportadas.", highlight: "Portfólio pronto para impressionar" },
  { icon: Bot, title: "Mentor de Vendas", description: "Um mentor de vendas e criação de sites disponível vinte e quatro horas por dia. Tire dúvidas, peça scripts, revise abordagens e receba conselhos sob medida para o seu momento.", highlight: "Consultoria sempre à disposição" },
  { icon: Gift, title: "Recompensas", description: "Recompensas e bônus liberados conforme você avança dentro da plataforma. Fique de olho, pois novos presentes aparecem por aqui em datas especiais.", highlight: "Aproveite tudo o que é seu" },
];

const keyFor = (userId: string) => `${STORAGE_KEY}_${userId}`;
const read = (userId: string) => { try { return localStorage.getItem(keyFor(userId)); } catch { return null; } };

/** Tour de 7 passos. Abre 500 ms depois da primeira entrada; concluir ou pular grava e libera o aviso do sorteio. */
const AurenTour = ({ userId, onComplete, forceOpen }: { userId?: string; onComplete: () => void; forceOpen?: number }) => {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!userId) return;
    if (read(userId)) { onComplete(); return; }
    const t = setTimeout(() => setOpen(true), 500);
    return () => clearTimeout(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  // Reabrir pela prévia administrativa, sem apagar o que já foi gravado.
  useEffect(() => { if (forceOpen) { setStep(0); setOpen(true); } }, [forceOpen]);

  const finish = () => {
    if (userId) { try { localStorage.setItem(keyFor(userId), "true"); } catch { /* sem armazenamento */ } }
    setOpen(false);
    onComplete();
    window.dispatchEvent(new Event("sylora:onboarding-done"));
  };

  const s = steps[step];
  const Icon = s.icon;
  const last = step === steps.length - 1;

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="auren auren-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div
            role="dialog" aria-modal="true" aria-label="Apresentação da plataforma" className="auren-modal"
            initial={{ opacity: 0, y: 24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="tour-bar"><i style={{ width: `${((step + 1) / steps.length) * 100}%` }} /></div>
            <button type="button" className="au-icon-btn x" style={{ position: "absolute", top: 16, right: 14 }} onClick={finish} aria-label="Fechar apresentação"><X /></button>
            <div className="tour-body">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div key={step} initial={{ opacity: 0, x: 14 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -14 }} transition={{ duration: 0.2 }}>
                  <div className="au-icon-box solid" style={{ width: 56, height: 56, borderRadius: 16 }}><Icon style={{ width: 24, height: 24 }} /></div>
                  <p className="tour-step">Passo {step + 1} de {steps.length}</p>
                  <h2 className="tour-title">{s.title}</h2>
                  <p className="tour-desc">{s.description}</p>
                  <span className="tour-hl">{s.highlight}</span>
                </motion.div>
              </AnimatePresence>
              <div className="tour-dots">
                {steps.map((_, i) => <button key={i} type="button" className={i === step ? "on" : ""} onClick={() => setStep(i)} aria-label={`Ir para o passo ${i + 1}`} />)}
              </div>
              <div className="tour-foot">
                <button type="button" className="au-btn au-btn-ghost" style={{ height: 40, padding: "0 16px", fontSize: 13 }} onClick={() => setStep((v) => v - 1)} disabled={step === 0}><ArrowLeft />Voltar</button>
                <button type="button" className="tour-skip" onClick={finish}>Pular apresentação</button>
                <button type="button" className="au-btn au-btn-primary" style={{ height: 40, padding: "0 18px", fontSize: 13 }} onClick={() => (last ? finish() : setStep((v) => v + 1))}>
                  {last ? "Começar" : "Continuar"}{!last && <ArrowRight />}
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AurenTour;
