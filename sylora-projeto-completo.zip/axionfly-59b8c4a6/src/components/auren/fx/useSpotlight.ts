import { useEffect, useRef } from "react";

/**
 * Faz o fundo "enxergar" o mouse, sem re-render:
 *  - --vx/--vy  (coordenadas da janela) no elemento raiz → camadas fixas (ambiente da ferramenta)
 *  - --mx/--my  (relativas) no [data-field] mais próximo → grades das seções
 *  - --sx/--sy  (relativas) no cartão/pílula sob o mouse → brilho de borda e reflexo
 */
export function useSpotlight<T extends HTMLElement>() {
  const ref = useRef<T>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    if (!window.matchMedia("(pointer: fine)").matches) return;

    let raf = 0;
    let ev: PointerEvent | null = null;
    let lastField: HTMLElement | null = null;

    const reset = (el: HTMLElement | null) => {
      if (!el) return;
      el.style.setProperty("--mx", "-999px");
      el.style.setProperty("--my", "-999px");
    };

    const apply = () => {
      raf = 0;
      if (!ev) return;
      const target = ev.target as HTMLElement | null;
      root.style.setProperty("--vx", `${ev.clientX}px`);
      root.style.setProperty("--vy", `${ev.clientY}px`);

      const field = target?.closest?.<HTMLElement>("[data-field]") ?? null;
      if (field !== lastField) { reset(lastField); lastField = field; }
      if (field) {
        const r = field.getBoundingClientRect();
        field.style.setProperty("--mx", `${ev.clientX - r.left}px`);
        field.style.setProperty("--my", `${ev.clientY - r.top}px`);
      }

      const spot = target?.closest?.<HTMLElement>("[data-spot], .au-card, .au-tile, .au-step-card") ?? null;
      if (spot && root.contains(spot)) {
        const b = spot.getBoundingClientRect();
        spot.style.setProperty("--sx", `${ev.clientX - b.left}px`);
        spot.style.setProperty("--sy", `${ev.clientY - b.top}px`);
      }
    };

    const onMove = (e: PointerEvent) => {
      ev = e;
      if (!raf) raf = requestAnimationFrame(apply);
    };
    const onLeave = () => { reset(lastField); lastField = null; root.style.setProperty("--vx", "-999px"); root.style.setProperty("--vy", "-999px"); };

    root.addEventListener("pointermove", onMove, { passive: true });
    root.addEventListener("pointerleave", onLeave);
    return () => {
      root.removeEventListener("pointermove", onMove);
      root.removeEventListener("pointerleave", onLeave);
      cancelAnimationFrame(raf);
    };
  }, []);

  return ref;
}
