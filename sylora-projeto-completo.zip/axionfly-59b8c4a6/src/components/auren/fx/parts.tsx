import { useId, type RefObject } from "react";
import { motion } from "framer-motion";
import HorizonCanvas, { type BladeInfo } from "./HorizonCanvas";
import "./fx.css";

/** Grão de filme por cima de tudo (também desfaz o "degradê em faixas" do preto). */
export const Grain = ({ soft = false }: { soft?: boolean }) => <div className={soft ? "au-grain soft" : "au-grain"} aria-hidden />;

/** Lâmina em miniatura: o gesto do logo, usado como régua/divisor. */
export const BladeRule = ({ width = 132, className }: { width?: number; className?: string }) => {
  const id = useId().replace(/:/g, "");
  return (
    <svg width={width} height={7} viewBox="0 0 132 7" className={className} aria-hidden>
      <defs>
        <linearGradient id={id} x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stopColor="#fff" stopOpacity="0" />
          <stop offset="0.55" stopColor="#fff" stopOpacity="0.5" />
          <stop offset="0.93" stopColor="#fff" stopOpacity="1" />
          <stop offset="1" stopColor="#fff" stopOpacity="0.15" />
        </linearGradient>
      </defs>
      <path d="M0 3.5 Q 44 1.1 132 3.5 Q 44 5.9 0 3.5Z" fill={`url(#${id})`} />
    </svg>
  );
};

/** Moldura de corte do herói: a lâmina é a única coisa que sai dela. */
const CropFrame = () => (
  <div
    className="absolute hidden md:block pointer-events-none"
    style={{
      left: "max(20px, calc(50% - 640px))",
      right: "max(20px, calc(50% - 640px))",
      top: 132,
      height: "calc(var(--hy, 600px) - 132px)",
    }}
  >
    <i className="au-crop tl" /><i className="au-crop tr" /><i className="au-crop bl" /><i className="au-crop br" />
  </div>
);

/** Cena do herói: céu, horizonte em canvas, vinheta. */
export const HeroScene = ({ anchorRef, onBlade }: { anchorRef: RefObject<HTMLElement | null>; onBlade?: (b: BladeInfo | null) => void }) => (
  <div className="au-scene" aria-hidden>
    <div className="au-sky" />
    <HorizonCanvas mode="hero" anchorRef={anchorRef} onBlade={onBlade} />
    <div className="au-scene-vignette" />
    <CropFrame />
    <div className="au-scene-fade" />
  </div>
);

/** Grade de projeto com marcas "+" e foco que segue o mouse. A seção precisa ter data-field. */
export const GridField = ({ className = "" }: { className?: string }) => (
  <div className={`au-field ${className}`} aria-hidden>
    <i className="g" /><i className="m" /><i className="l" />
  </div>
);

/** Colunas do layout atravessando a página, com sinais de luz descendo. */
export const PageRails = () => (
  <div className="au-rails" aria-hidden>
    {[0, 6].map((k) => (
      <i
        key={k}
        className="au-rail"
        style={{ ["--k" as string]: k, ["--d" as string]: `${9 + ((k * 7) % 6)}s`, ["--dl" as string]: `${(k * 2.3) % 7}s` }}
      />
    ))}
  </div>
);

/** Linha de dobra entre seções: uma lâmina atravessa quando ela entra na tela. */
export const FoldLine = () => (
  <div className="au-fold" aria-hidden>
    <motion.span
      className="run"
      initial={{ x: "-12%", opacity: 0 }}
      whileInView={{ x: ["-12%", "600%"], opacity: [0, 1, 1, 0] }}
      viewport={{ once: true, margin: "0px 0px -12% 0px" }}
      transition={{ duration: 1.9, ease: [0.45, 0.05, 0.3, 1], times: [0, 0.15, 0.85, 1] }}
    />
  </div>
);

/** Fundo da ferramenta: o céu e a grade da landing em baixa intensidade, com uma lâmina lenta ao fundo. */
export const AurenAmbient = () => (
  <div className="au-ambient" aria-hidden>
    <i className="top" /><i className="g" /><i className="m" /><i className="l" /><i className="blade" />
  </div>
);

/** Fundo da barra lateral: grade, brilho do horizonte, piso em perspectiva e a lâmina passando de tempos em tempos. */
export const SidebarFX = ({ anchorRef }: { anchorRef: RefObject<HTMLElement | null> }) => (
  <div className="au-side-fx" aria-hidden>
    <i className="glow" /><i className="g" /><i className="haze" />
    <HorizonCanvas mode="mini" anchorRef={anchorRef} />
    <i className="signal" />
  </div>
);

/** Piso do rodapé: o horizonte do herói, de volta, para fechar a página. */
export const FloorScene = () => (
  <div className="au-floor" aria-hidden>
    <HorizonCanvas mode="floor" horizon={0} />
  </div>
);

export { default as HorizonCanvas } from "./HorizonCanvas";
export type { BladeInfo } from "./HorizonCanvas";
