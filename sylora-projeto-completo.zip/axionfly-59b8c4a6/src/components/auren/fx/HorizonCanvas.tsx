import { useEffect, useRef, type RefObject } from "react";

/**
 * Horizonte da SYLORA: piso em perspectiva (as colunas do layout continuam além da dobra),
 * linha do limite com régua, pacotes de luz que chegam do horizonte e a lâmina,
 * que corta a cena no mesmo ângulo do swoosh do logo (-20°).
 *
 * Tudo em um único canvas 2D, sem blur nem sombras (barato), pausado fora da tela.
 */

export interface BladeInfo {
  /** progresso da passada, 0..1 (já suavizado) */
  s: number;
  /** posição da ponta da lâmina, em px dentro do canvas */
  x: number;
  y: number;
  /** 1 = passada de abertura; menor = passadas seguintes */
  strength: number;
}

interface Props {
  mode?: "hero" | "mini" | "floor";
  /** o topo deste elemento marca o horizonte (herói) */
  anchorRef?: RefObject<HTMLElement | null>;
  /** distância do horizonte até a base do canvas, em px (mini) */
  horizonFromBottom?: number;
  /** fração da altura, quando não há âncora nem horizonFromBottom */
  horizon?: number;
  onBlade?: (b: BladeInfo | null) => void;
}

const RAD = (-20 * Math.PI) / 180;
const COS = Math.cos(RAD);
const SIN = Math.sin(RAD); // negativo: a lâmina sobe para a direita

const clamp = (v: number, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
const smooth = (a: number, b: number, v: number) => {
  const t = clamp((v - a) / (b - a));
  return t * t * (3 - 2 * t);
};
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const easeInOut = (t: number) => 0.5 - 0.5 * Math.cos(Math.PI * t);

/** brilho do piso em função da proximidade (0 = horizonte, 1 = base) */
const floorAlpha = (t: number) => smooth(0, 0.12, t) * (1 - 0.82 * smooth(0.4, 1, t)) * (1 - smooth(0.94, 1, t));
const STOPS = [0.05, 0.12, 0.22, 0.36, 0.55, 0.78, 1];

export default function HorizonCanvas({ mode = "hero", anchorRef, horizonFromBottom, horizon = 0.62, onBlade }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const cb = useRef(onBlade);
  cb.current = onBlade;

  useEffect(() => {
    const canvas = ref.current;
    const parent = canvas?.parentElement;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !parent || !ctx) return;

    const floorOnly = mode === "floor";
    const mini = mode === "mini" || floorOnly; // reaproveita os parâmetros leves
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const fine = window.matchMedia("(pointer: fine)").matches;

    let W = 0, H = 0, hy = 0, cx = 0, floorH = 0, S = 100, d = 0.5, rails = 8;
    let hGrad: CanvasGradient | null = null;
    let raf = 0, running = false, inView = true;
    const start = performance.now();
    let last = start;
    let mx = 0, mxT = 0, phase = reduce ? 0.3 : 0;
    let bladeWasOn = false;
    let nextSpawn = 1.2;
    const packets: { i: number; p: number; v: number; len: number }[] = [];
    const motes: { x: number; y: number; z: number; ph: number }[] = []; // sem partículas: parecia neve
    const crossY = new Float32Array(96);

    const measure = () => {
      const r = parent.getBoundingClientRect();
      W = Math.max(1, Math.round(r.width));
      H = Math.max(1, Math.round(r.height));
      const dpr = Math.min(window.devicePixelRatio || 1, mini ? 2 : 1.5);
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      if (anchorRef?.current) hy = anchorRef.current.getBoundingClientRect().top - r.top;
      else if (horizonFromBottom != null) hy = H - horizonFromBottom;
      else hy = H * horizon;
      hy = clamp(hy, floorOnly ? 6 : 40, H - 60);
      floorH = H - hy;
      cx = W / 2;
      S = floorOnly ? clamp(floorH * 0.2, 80, 130) : mini ? clamp(floorH * 0.3, 34, 56) : clamp(floorH * 0.36, 76, 150);
      d = S / Math.max(S + 24, floorH - S);
      rails = Math.ceil((W / 2 + S * 2) / S);

      hGrad = ctx.createLinearGradient(0, 0, W, 0);
      hGrad.addColorStop(0, "rgba(224,229,240,0)");
      hGrad.addColorStop(0.16, "rgba(224,229,240,0.55)");
      hGrad.addColorStop(0.5, "rgba(236,240,248,1)");
      hGrad.addColorStop(0.84, "rgba(224,229,240,0.55)");
      hGrad.addColorStop(1, "rgba(224,229,240,0)");

      parent.style.setProperty("--hy", `${hy}px`);
    };

    const draw = (t: number, dt: number) => {
      if (W < 2 || H < 2) return;
      ctx.clearRect(0, 0, W, H);
      const rev = reduce ? 1 : easeOut(clamp((t - 0.12) / (mini ? 0.9 : 1.7)));

      mx += (mxT - mx) * Math.min(1, dt * 3.2);
      const idle = reduce ? 0 : Math.sin(t * 0.22) * (mini ? 2.5 : 9);
      const par = mini ? 0 : mx * 26;
      const vx = cx + idle + par; // ponto de fuga
      const nx = (idle + par) * 0.35; // a base se move menos que o fundo → paralaxe

      /* ---- lâmina: estado da passada ---- */
      const L = mini ? Math.max(W * 1.0, 220) : Math.min(W * 0.55, 880);
      const period = mini ? 17 : 14;
      const dur = mini ? 2.3 : 2.8;
      const first = mini ? 2.4 : 0.75;
      let blade: BladeInfo | null = null;
      if (!reduce && !floorOnly && t >= first) {
        const local = (t - first) % period;
        const idx = Math.floor((t - first) / period);
        if (local <= dur) {
          const s = easeInOut(local / dur);
          const strength = mini ? 0.45 : idx === 0 ? 1 : 0.55;
          const travel = (2 * (W * 0.5 + 60 + L * COS)) / COS;
          const off = (s - 0.5) * travel;
          blade = { s, x: cx + off * COS, y: hy + off * SIN, strength };
        }
      }
      const cross = blade ? Math.exp(-Math.pow((blade.s - 0.5) / 0.075, 2)) * blade.strength : 0;

      /* ---- poeira no céu ---- */
      if (motes.length) {
        ctx.fillStyle = "#fff";
        for (const m of motes) {
          const yy = (((m.y - t * 0.004 * (0.4 + m.z)) % 1) + 1) % 1;
          const y = yy * hy;
          const x = m.x * W + Math.sin(t * 0.3 + m.ph) * 6 * m.z;
          const tw = 0.5 + 0.5 * Math.sin(t * (0.5 + m.z) + m.ph);
          ctx.globalAlpha = (0.08 + 0.3 * m.z) * tw * (0.2 + 0.8 * (y / hy)) * rev;
          const sz = 0.7 + m.z * 0.9;
          ctx.fillRect(x, y, sz, sz);
        }
        ctx.globalAlpha = 1;
      }

      /* ---- raios discretos: a luz vem de além do limite ---- */
      if (!mini && rev > 0.02) {
        const R = hy * 1.25;
        for (let k = -6; k <= 6; k++) {
          const ang = (k * 7.4 + Math.sin(t * 0.07 + k * 1.7) * 2.2) * (Math.PI / 180);
          const half = (1.1 + 0.5 * Math.abs(Math.sin(k * 2.3))) * (Math.PI / 180);
          const tx = vx + Math.sin(ang) * R, ty = hy - Math.cos(ang) * R;
          const lx = Math.cos(ang) * R * Math.tan(half), ly = Math.sin(ang) * R * Math.tan(half);
          const g = ctx.createLinearGradient(vx, hy, tx, ty);
          const a = (0.05 + 0.025 * Math.sin(t * 0.5 + k * 1.3)) * rev * (1 - Math.abs(k) / 8);
          g.addColorStop(0, `rgba(236,240,248,${a.toFixed(4)})`);
          g.addColorStop(1, "rgba(236,240,248,0)");
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.moveTo(vx, hy);
          ctx.lineTo(tx - lx, ty - ly);
          ctx.lineTo(tx + lx, ty + ly);
          ctx.closePath();
          ctx.fill();
        }
      }

      /* ---- piso: trilhos (colunas do layout em perspectiva) ---- */
      ctx.lineWidth = 1;
      const A_RAIL = floorOnly ? 0.16 : mini ? 0.2 : 0.34;
      const A_CROSS = floorOnly ? 0.12 : mini ? 0.15 : 0.27;
      for (let i = -rails; i <= rails; i++) {
        const bx = cx + i * S + nx;
        const k = 1 - 0.62 * smooth(0, 1, Math.abs(i * S) / (W * 0.66));
        const a = A_RAIL * rev * k * (i === 0 ? 1.3 : 1);
        const g = ctx.createLinearGradient(vx, hy, bx, H);
        g.addColorStop(0, "rgba(224,229,240,0)");
        for (let s = 0; s < STOPS.length; s++) {
          g.addColorStop(STOPS[s], `rgba(224,229,240,${(a * floorAlpha(STOPS[s])).toFixed(4)})`);
        }
        ctx.strokeStyle = g;
        ctx.beginPath();
        ctx.moveTo(vx, hy);
        ctx.lineTo(bx, H);
        ctx.stroke();
      }

      /* ---- piso: linhas de profundidade que vêm em direção ao espectador ---- */
      if (!reduce) phase = (phase + dt * (mini ? 0.045 : 0.038)) % 1;
      const uMax = floorOnly ? 12 : mini ? 9 : 16;
      let nCross = 0;
      ctx.strokeStyle = hGrad!;
      for (let k = 0; k < 90; k++) {
        const u = 1 + (k - phase) * d;
        if (u < 1) continue;
        if (u > uMax) break;
        const tt = 1 / u;
        const y = hy + floorH * tt;
        const a = A_CROSS * rev * floorAlpha(tt);
        if (a < 0.003) continue;
        crossY[nCross++] = y;
        ctx.globalAlpha = a;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      /* ---- a lâmina acende o piso por onde passa ---- */
      if (blade) {
        const sigma = mini ? 62 : 175;
        const ax = blade.x - COS * L * 0.92;
        const ay = blade.y - SIN * L * 0.92;
        const abx = blade.x - ax;
        const aby = blade.y - ay;
        const ab2 = abx * abx + aby * aby;
        const boostAt = (x: number, y: number) => {
          const u = clamp(((x - ax) * abx + (y - ay) * aby) / ab2);
          const px = ax + abx * u - x;
          const py = ay + aby * u - y;
          const dd = (px * px + py * py) / (sigma * sigma);
          if (dd > 6) return 0;
          return blade!.strength * Math.exp(-dd) * (0.18 + 0.82 * u * u);
        };
        const N = 28;
        for (let i = -rails; i <= rails; i++) {
          const bxr = cx + i * S + nx;
          const kk = 1 - 0.62 * smooth(0, 1, Math.abs(i * S) / (W * 0.66));
          for (let j = 0; j < N; j++) {
            const t0 = j / N, t1 = (j + 1) / N, tm = (t0 + t1) / 2;
            const x0 = vx + (bxr - vx) * t0, y0 = hy + floorH * t0;
            const x1 = vx + (bxr - vx) * t1, y1 = hy + floorH * t1;
            const bo = boostAt((x0 + x1) / 2, (y0 + y1) / 2);
            if (bo < 0.03) continue;
            const a = bo * 0.55 * (0.35 + 0.65 * floorAlpha(tm)) * kk * rev;
            ctx.strokeStyle = `rgba(255,255,255,${a.toFixed(3)})`;
            ctx.beginPath();
            ctx.moveTo(x0, y0);
            ctx.lineTo(x1, y1);
            ctx.stroke();
          }
        }
        const step = 26;
        for (let c = 0; c < nCross; c++) {
          const y = crossY[c];
          const tm = (y - hy) / floorH;
          for (let x = 0; x < W; x += step) {
            const bo = boostAt(x + step / 2, y);
            if (bo < 0.03) continue;
            const edge = 1 - 0.7 * smooth(0.45, 1, Math.abs(x + step / 2 - cx) / (W / 2));
            const a = bo * 0.5 * (0.35 + 0.65 * floorAlpha(tm)) * edge * rev;
            ctx.strokeStyle = `rgba(255,255,255,${a.toFixed(3)})`;
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + step, y);
            ctx.stroke();
          }
        }
      }

      /* ---- linha do horizonte (o limite) + régua ---- */
      const hw = W * 0.54 * easeOut(clamp((t - 0.04) / 1.3));
      if (hw > 2) {
        const breathe = reduce ? 0.5 : 0.5 + 0.5 * Math.sin(t * 1.05);
        const g1 = ctx.createLinearGradient(cx - hw, 0, cx + hw, 0);
        g1.addColorStop(0, "rgba(255,255,255,0)");
        g1.addColorStop(0.22, "rgba(236,240,248,0.20)");
        g1.addColorStop(0.5, `rgba(255,255,255,${clamp(0.7 + 0.14 * breathe + cross * 0.3).toFixed(3)})`);
        g1.addColorStop(0.78, "rgba(236,240,248,0.20)");
        g1.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = g1;
        ctx.fillRect(cx - hw, hy - 0.5, hw * 2, 1);

        const g2 = ctx.createLinearGradient(cx - hw, 0, cx + hw, 0);
        g2.addColorStop(0, "rgba(255,255,255,0)");
        g2.addColorStop(0.5, `rgba(255,255,255,${(0.09 + cross * 0.12).toFixed(3)})`);
        g2.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = g2;
        ctx.fillRect(cx - hw, hy - 3, hw * 2, 6);

        if (!mini) {
          ctx.fillStyle = "#fff";
          for (let j = -44; j <= 44; j++) {
            const x = cx + j * 22;
            if (Math.abs(x - cx) > hw) continue;
            const major = j % 5 === 0;
            ctx.globalAlpha = (major ? 0.32 : 0.15) * Math.pow(1 - Math.abs(j) / 44, 1.5) * rev;
            const hgt = major ? 7 : 3.5;
            ctx.fillRect(x - 0.5, hy - 1 - hgt, 1, hgt);
          }
          ctx.globalAlpha = 1;
        }
      }

      /* ---- pacotes de luz: chegam do horizonte até você ---- */
      if (!reduce) {
        nextSpawn -= dt;
        if (nextSpawn <= 0 && rev > 0.8 && packets.length < (mini ? 2 : 6)) {
          const span = Math.min(rails, mini ? 3 : 7);
          packets.push({ i: Math.round((Math.random() * 2 - 1) * span), p: 0, v: 1 / (3.4 + Math.random() * 2.6), len: 0.16 + Math.random() * 0.1 });
          nextSpawn = (mini ? 2.6 : 0.8) + Math.random() * (mini ? 3 : 1.5);
        }
        for (let n = packets.length - 1; n >= 0; n--) {
          const p = packets[n];
          p.p += p.v * dt;
          if (p.p >= 1) { packets.splice(n, 1); continue; }
          const th = Math.pow(p.p, 2.3);
          const tt = Math.pow(Math.max(0, p.p - p.len), 2.3);
          const bx = cx + p.i * S + nx;
          const x1 = vx + (bx - vx) * th, y1 = hy + floorH * th;
          const x0 = vx + (bx - vx) * tt, y0 = hy + floorH * tt;
          // na barra lateral os pacotes morrem perto do horizonte, antes de passar pelo texto do rodapé
          const env = smooth(0, 0.12, p.p) * (1 - smooth(mini ? 0.4 : 0.78, mini ? 0.7 : 1, p.p)) * (mini ? 0.8 : 1);
          const lw = 0.8 + 1.7 * th;
          const g = ctx.createLinearGradient(x0, y0, x1, y1);
          g.addColorStop(0, "rgba(255,255,255,0)");
          g.addColorStop(1, `rgba(255,255,255,${(0.9 * env).toFixed(3)})`);
          ctx.lineCap = "round";
          ctx.strokeStyle = g;
          ctx.globalAlpha = 0.28;
          ctx.lineWidth = lw * 3.6;
          ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
          ctx.globalAlpha = 1;
          ctx.lineWidth = lw;
          ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
          ctx.fillStyle = `rgba(255,255,255,${(0.95 * env).toFixed(3)})`;
          ctx.beginPath(); ctx.arc(x1, y1, lw * 0.75, 0, 6.2832); ctx.fill();
          ctx.lineCap = "butt";
        }
        ctx.lineWidth = 1;
      }

      /* ---- a lâmina ---- */
      if (blade) {
        const st = blade.strength;
        const th = (mini ? 2.1 : 3.2) * Math.sqrt(st);
        const lens = (len: number, thick: number, alpha: number, dir = 1) => {
          const g = ctx.createLinearGradient(-len * dir, 0, 0, 0);
          g.addColorStop(0, "rgba(255,255,255,0)");
          g.addColorStop(0.35, `rgba(255,255,255,${(alpha * 0.1).toFixed(3)})`);
          g.addColorStop(0.82, `rgba(255,255,255,${(alpha * 0.72).toFixed(3)})`);
          g.addColorStop(1, `rgba(255,255,255,${alpha.toFixed(3)})`);
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.moveTo(-len * dir, 0);
          ctx.quadraticCurveTo(-len * 0.34 * dir, -thick, 0, 0);
          ctx.quadraticCurveTo(-len * 0.34 * dir, thick, -len * dir, 0);
          ctx.fill();
        };
        const paintBlade = (k: number) => {
          ctx.save();
          ctx.translate(blade!.x, blade!.y);
          ctx.rotate(RAD);
          lens(L, th * 20, 0.025 * st * k);
          lens(L, th * 11, 0.045 * st * k);
          lens(L, th * 6, 0.08 * st * k);
          lens(L, th * 3, 0.16 * st * k);
          lens(L * 0.94, th * 1.6, 0.5 * st * k);
          lens(L * 0.9, th, 0.95 * st * k);
          // ponta à frente: a lâmina é afiada dos dois lados
          const sp = ctx.createLinearGradient(0, 0, 78 * Math.sqrt(st), 0);
          sp.addColorStop(0, `rgba(255,255,255,${(0.9 * st * k).toFixed(3)})`);
          sp.addColorStop(1, "rgba(255,255,255,0)");
          ctx.fillStyle = sp;
          ctx.beginPath();
          ctx.moveTo(0, -th * 0.5);
          ctx.lineTo(78 * Math.sqrt(st), 0);
          ctx.lineTo(0, th * 0.5);
          ctx.closePath();
          ctx.fill();
          const hg = ctx.createRadialGradient(0, 0, 0, 0, 0, 22 * Math.sqrt(st));
          hg.addColorStop(0, `rgba(255,255,255,${(0.75 * st * k).toFixed(3)})`);
          hg.addColorStop(0.4, `rgba(255,255,255,${(0.14 * st * k).toFixed(3)})`);
          hg.addColorStop(1, "rgba(255,255,255,0)");
          ctx.fillStyle = hg;
          ctx.fillRect(-26, -26, 52, 52);
          ctx.restore();
        };
        paintBlade(1);
        // reflexo no piso: só a parte do céu se espelha no horizonte
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, hy, W, H - hy);
        ctx.clip();
        ctx.translate(0, 2 * hy);
        ctx.scale(1, -1);
        paintBlade(0.3);
        ctx.restore();

        /* clarão anamórfico quando a lâmina cruza o horizonte */
        if (cross > 0.02) {
          ctx.save();
          ctx.translate(cx, hy);
          ctx.save();
          ctx.scale(1, 0.016);
          const rg = ctx.createRadialGradient(0, 0, 0, 0, 0, W * 0.5);
          rg.addColorStop(0, `rgba(255,255,255,${(0.9 * cross).toFixed(3)})`);
          rg.addColorStop(0.18, `rgba(236,241,250,${(0.34 * cross).toFixed(3)})`);
          rg.addColorStop(1, "rgba(255,255,255,0)");
          ctx.fillStyle = rg;
          ctx.beginPath();
          ctx.arc(0, 0, W * 0.5, 0, 6.2832);
          ctx.fill();
          ctx.restore();
          const rg2 = ctx.createRadialGradient(0, 0, 0, 0, 0, 130);
          rg2.addColorStop(0, `rgba(255,255,255,${(0.5 * cross).toFixed(3)})`);
          rg2.addColorStop(1, "rgba(255,255,255,0)");
          ctx.fillStyle = rg2;
          ctx.fillRect(-130, -130, 260, 260);
          ctx.restore();
        }
        cb.current?.(blade);
        bladeWasOn = true;
      } else if (bladeWasOn) {
        cb.current?.(null);
        bladeWasOn = false;
      }
    };

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      if (mini && now - last < 32) return; // barra lateral: ~30 fps
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      draw((now - start) / 1000, dt);
    };
    const run = () => {
      if (running || reduce) return;
      running = true;
      last = performance.now();
      raf = requestAnimationFrame(loop);
    };
    const halt = () => {
      running = false;
      cancelAnimationFrame(raf);
    };
    const sync = () => (inView && !document.hidden ? run() : halt());

    measure();
    if (reduce) draw(3, 0);

    const ro = new ResizeObserver(() => {
      measure();
      if (reduce) draw(3, 0);
    });
    ro.observe(parent);
    if (anchorRef?.current) ro.observe(anchorRef.current);
    const io = new IntersectionObserver(([e]) => { inView = e.isIntersecting; sync(); }, { threshold: 0 });
    io.observe(parent);
    const onVis = () => sync();
    const onPtr = (e: PointerEvent) => { mxT = clamp((e.clientX / window.innerWidth - 0.5) * 2, -1, 1); };
    document.addEventListener("visibilitychange", onVis);
    if (fine && !mini) window.addEventListener("pointermove", onPtr, { passive: true });
    const onFonts = () => measure();
    document.fonts?.ready.then(onFonts);
    sync();

    return () => {
      halt();
      ro.disconnect();
      io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pointermove", onPtr);
    };
  }, [mode, anchorRef, horizonFromBottom, horizon]);

  return <canvas ref={ref} aria-hidden />;
}
