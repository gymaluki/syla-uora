import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Gift, GraduationCap, Megaphone, Rocket, Target, TrendingUp } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { BONUS_DAYS, DAY_MS } from "@/lib/raffleDate";
import { Countdown, useDone } from "./presente/Countdown";
import { ReferralUnlock } from "./presente/RaffleBlocks";
import "./presente/presente.css";

const MODULES = [
  { icon: Megaphone, t: "Tráfego orgânico", d: "Como atrair clientes sem pagar por anúncio." },
  { icon: TrendingUp, t: "Tráfego pago", d: "Primeiros anúncios, de forma simples e segura." },
  { icon: Target, t: "Estratégias de venda", d: "Abordagem, proposta e fechamento." },
  { icon: Rocket, t: "Primeira venda", d: "O caminho curto até o primeiro cliente." },
];

const PresenteView = () => {
  const { user } = useAuth();
  const created = (user as { created_at?: string } | null)?.created_at ?? null;
  const bonusTarget = useMemo(() => (created ? new Date(new Date(created).getTime() + BONUS_DAYS * DAY_MS) : null), [created]);
  const bonusDone = useDone(bonusTarget);
  // Administradores começam vendo o resultado demonstrativo do sorteio e podem alternar.
  const isAdmin = !!user?.email && user.email.toLowerCase() === "andreyhenriquev4@gmail.com";
  const [demoResult, setDemoResult] = useState(isAdmin);
  const [demoStart] = useState(() => new Date().toISOString());

  return (
    <motion.div className="pr-root" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
      <section className="au-card pr-hero">
        <div className="pr-head">
          <div className="au-icon-box solid" style={{ width: 60, height: 60, borderRadius: 18 }}><Gift style={{ width: 26, height: 26 }} /></div>
          <div style={{ minWidth: 0 }}>
            <h2>Seu <span className="au-shine">Presente</span></h2>
            <p>Uma cortesia para quem entra na Sylora: um curso de tráfego e vendas, previsto para seis dias depois do seu cadastro.</p>
          </div>
        </div>
        {bonusTarget && !bonusDone && (
          <div style={{ marginTop: 24 }}>
            <p className="au-label">Seu bônus em</p>
            <Countdown target={bonusTarget} />
          </div>
        )}
      </section>

      <section className="au-card pr-sec">
        <div className="pr-sec-title"><GraduationCap />O que vem no curso</div>
        <div className="pr-mods">
          {MODULES.map((m, i) => (
            <div key={m.t} className="pr-mod"><i>{String(i + 1).padStart(2, "0")}</i><h4>{m.t}</h4><p>{m.d}</p></div>
          ))}
        </div>
      </section>

      {isAdmin && (
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <span className="au-label" style={{ margin: 0 }}>Prévia do sorteio</span>
          <button type="button" className={"au-chip" + (demoResult ? " on" : "")} onClick={() => setDemoResult(true)}>Resultado</button>
          <button type="button" className={"au-chip" + (!demoResult ? " on" : "")} onClick={() => setDemoResult(false)}>Cronômetro</button>
        </div>
      )}
      <ReferralUnlock createdAt={isAdmin && !demoResult ? demoStart : created} forceUnlocked={demoResult} />
    </motion.div>
  );
};

export default PresenteView;
