import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Cpu, CircleCheck, ExternalLink } from "lucide-react";
import { toast } from "sonner";

export type GenerationKind = "site" | "app" | "portfolio";

const LINES: { t: string; c: "cmd" | "run" | "ok" | "code" }[] = [
  { t: "$ initializing auren engine...", c: "cmd" },
  { t: "→ loading neural prompt model v3.2", c: "run" },
  { t: "✓ context window: 128k tokens ready", c: "ok" },
  { t: "import { AurenAI } from '@auren/core';", c: "code" },
  { t: "const project = new AurenAI({ tier: 'pro' });", c: "code" },
  { t: "→ analyzing niche keywords...", c: "run" },
  { t: "→ optimizing conversion structure...", c: "run" },
  { t: "✓ landing sections: hero, features, cta", c: "ok" },
  { t: "→ generating responsive layout grid...", c: "run" },
  { t: "→ injecting framer-motion animations...", c: "run" },
  { t: "✓ tailwind tokens compiled", c: "ok" },
];

const PHASES = [
  { at: 0, title: "Analisando seu nicho", sub: "Lendo o mercado do cliente" },
  { at: 25, title: "Estruturando o projeto", sub: "Montando as seções" },
  { at: 50, title: "Otimizando para vendas", sub: "Aplicando gatilhos mentais" },
  { at: 75, title: "Finalizando o prompt", sub: "Ajustando os últimos detalhes" },
];

const COPY: Record<GenerationKind, { what: string; cta: string }> = {
  site: { what: "seu site", cta: "Finalizar meu site profissional" },
  app: { what: "seu app", cta: "Finalizar meu app profissional" },
  portfolio: { what: "seu portfólio", cta: "Finalizar meu portfólio profissional" },
};

const DURATION_MS = 7000;

export const AI_STUDIO_URL = "https://aistudio.google.com/apps";

export const copyText = async (text: string) => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
};

interface Props {
  open: boolean;
  kind: GenerationKind;
  prompt: string;
  onClose: () => void;
}

const GenerationModal = ({ open, kind, prompt, onClose }: Props) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!open) return;
    setProgress(0);
    copyText(prompt);
    toast.success("Texto preparado para criar seu aplicativo no Google AI Studio.");
    const start = Date.now();
    const id = window.setInterval(() => {
      const p = Math.min(100, Math.round(((Date.now() - start) / DURATION_MS) * 100));
      setProgress(p);
      if (p >= 100) window.clearInterval(id);
    }, 80);
    return () => window.clearInterval(id);
  }, [open, prompt]);

  const done = progress >= 100;
  const visibleLines = done ? LINES.length : Math.floor((progress / 100) * LINES.length) + 1;
  const phase = [...PHASES].reverse().find((p) => progress >= p.at) ?? PHASES[0];

  const finish = async () => {
    await copyText(prompt);
    window.open(`${AI_STUDIO_URL}?prompt=${encodeURIComponent(prompt)}`, "_blank", "noopener");
  };

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="auren fixed inset-0 z-[10000] flex items-center justify-center p-4"
          style={{ background: "rgba(3,3,4,0.82)", backdropFilter: "blur(6px)" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="w-full max-w-[780px]"
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.98 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="flex items-end justify-between gap-4 mb-4 px-1">
              <div className="flex items-center gap-3 min-w-0">
                <div className="au-icon-box" style={{ width: 48, height: 48 }}>
                  {done ? <CircleCheck /> : <Cpu />}
                </div>
                <div className="min-w-0">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={done ? "done" : phase.title}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.2 }}
                    >
                      <p className="au-display text-[19px] font-bold text-[var(--au-text)] truncate">
                        {done ? "Tudo pronto!" : `${phase.title} …`}
                      </p>
                      <p className="text-[14px] text-[var(--au-text-2)]">{done ? "Finalização liberada" : phase.sub}</p>
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>
              <div className="text-right shrink-0">
                <p className="au-display au-shine text-[30px] font-extrabold leading-none tabular-nums">{progress}%</p>
                <p className="au-eyebrow mt-1.5" style={{ fontSize: 9.5 }}>Processando</p>
              </div>
            </div>

            <div className="au-terminal">
              <div className="bar">
                <i style={{ background: "#FF5F57" }} />
                <i style={{ background: "#FEBC2E" }} />
                <i style={{ background: "#28C840" }} />
                <span className="ml-2">auren-engine ~ generating</span>
              </div>
              <div className="lines">
                {LINES.slice(0, visibleLines).map((l, i) => (
                  <motion.div
                    key={i}
                    className="ln"
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <span className="pr">›</span>
                    <span className={`t-${l.c}`}>{l.t}</span>
                  </motion.div>
                ))}
                {!done && <span className="au-cursor mt-1 ml-[18px]" />}
              </div>
              <div className="track">
                <div style={{ width: `${progress}%` }} />
              </div>
            </div>

            <AnimatePresence mode="wait">
              {done ? (
                <motion.div
                  key="done"
                  className="mt-5 text-center"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <p className="text-[14.5px] text-[var(--au-text)] mb-4 max-w-[560px] mx-auto leading-relaxed">
                    Abra o Google AI Studio para criar {COPY[kind].what}. O prompt já vai preenchido e também fica copiado.
                  </p>
                  <button type="button" onClick={finish} className="au-btn au-btn-primary w-full" style={{ height: 52 }}>
                    <ExternalLink /> {COPY[kind].cta}
                  </button>
                  <button type="button" onClick={onClose} className="mt-4 text-[13px] text-[var(--au-text-2)] hover:text-[var(--au-text)] transition-colors">
                    Fechar
                  </button>
                </motion.div>
              ) : (
                <motion.p
                  key="wait"
                  className="mt-5 text-center text-[12.5px] text-[var(--au-text-2)]"
                  style={{ fontFamily: "var(--au-font-mono)" }}
                  exit={{ opacity: 0 }}
                >
                  [ NÃO FECHE ESTA JANELA — preparando seu prompt ]
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
};

export default GenerationModal;
