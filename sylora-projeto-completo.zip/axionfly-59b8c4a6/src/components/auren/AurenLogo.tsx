import { MARK_PATH, MARK_RATIO, MARK_VIEWBOX } from "./syloraMark";
import "./auren.css";
import "./fx/fx.css";

/** Marca da SYLORA: o S, em vetor, na cor do texto ao redor (preto no claro, branco no escuro). */
export const AurenMark = ({ size = 32, className }: { size?: number; className?: string }) => (
  <svg width={size} height={size / MARK_RATIO} viewBox={MARK_VIEWBOX} fill="currentColor" className={className} role="img" aria-label="Sylora">
    <path fillRule="evenodd" d={MARK_PATH} />
  </svg>
);

/** Só a marca: o nome não acompanha mais o logo. */
export const AurenWordmark = ({ size = 28 }: { size?: number }) => <AurenMark size={size} />;
