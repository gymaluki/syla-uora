import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarDays, CheckCircle2, Gift, Trophy, Users, Video, X } from "lucide-react";
import {
  DAY_MS, RAFFLE_BUYER, RAFFLE_DAYS, RAFFLE_PRIZE, RAFFLE_SLOTS,
  ensureFirstSeen, getDiasRestantesSorteio, getSorteioDataFormatada, hasFirstSeen,
} from "@/lib/raffleDate";
import { Countdown } from "./Countdown";
import "./presente.css";

/* ---------- Banner no topo do painel (não Protocolo) ---------- */
export const RaffleCountdownBanner = ({ userId }: { userId: string }) => {
  const data = getSorteioDataFormatada(userId);
  return (
    <div className="pr-banner">
      <span className="ico"><Trophy /></span>
      <div>
        <div className="tt">Sorteio em andamento</div>
        <div className="ss">Prêmio de até {RAFFLE_PRIZE},00 · apenas {RAFFLE_SLOTS} participantes</div>
      </div>
      <div className="date">Sorteio em<b>{data}</b></div>
    </div>
  );
};

/* ---------- Aviso inicial (depois do tour, só na primeira visita) ---------- */
export const RaffleWelcomeModal = ({ userId, enabled, forceOpen }: { userId: string; enabled: boolean; forceOpen?: number }) => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    // Só abre se esta for mesmo a primeira visita; a marca é gravada aqui, não durante a renderização.
    if (hasFirstSeen(userId)) return;
    ensureFirstSeen(userId);
    const t = setTimeout(() => setOpen(true), 1200);
    return () => clearTimeout(t);
  }, [enabled, userId]);

  // A prévia administrativa reabre o aviso sem mexer em nada salvo.
  useEffect(() => { if (forceOpen) setOpen(true); }, [forceOpen]);

  const dias = getDiasRestantesSorteio(userId);
  const data = getSorteioDataFormatada(userId);

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="auren auren-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)}>
          <motion.div
            role="dialog" aria-modal="true" aria-label="Sorteio"
            className="auren-modal"
            initial={{ opacity: 0, y: 24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            onClick={(e) => e.stopPropagation()}
          >
            <span className="blade" />
            <button type="button" className="au-icon-btn x" onClick={() => setOpen(false)} aria-label="Fechar"><X /></button>
            <div className="tour-body">
              <div className="au-icon-box solid" style={{ width: 56, height: 56, borderRadius: 16 }}><Trophy style={{ width: 24, height: 24 }} /></div>
              <p className="tour-step" style={{ marginTop: 18 }}>Sorteio · {data}</p>
              <h2 className="tour-title">Não esqueça: você está concorrendo a {RAFFLE_PRIZE}</h2>
              <p className="tour-desc">O comprador número 10 mil leva até {RAFFLE_PRIZE},00. São somente {RAFFLE_SLOTS} participantes.</p>
              <div className="ad-rows" style={{ marginTop: 18 }}>
                {([
                  [CalendarDays, `Faltam ${dias} dia${dias === 1 ? "" : "s"}`, `Sorteio em ${data}.`],
                  [Users, `${RAFFLE_SLOTS} participantes`, "Vagas limitadas."],
                  [CheckCircle2, "Participação confirmada", "Você não precisa fazer mais nada."],
                  [Video, "Vídeo oficial ao vivo", "O sorteio será mostrado em vídeo."],
                  [Gift, "Acompanhe em Recompensas", "O andamento fica na aba Recompensas."],
                ] as const).map(([I, t, d]) => (
                  <div key={t} style={{ display: "flex", gap: 12, padding: "11px 0", borderTop: "1px solid var(--au-border)" }}>
                    <I style={{ width: 16, height: 16, color: "var(--au-silver)", flexShrink: 0, marginTop: 2 }} />
                    <div><div style={{ fontSize: 13, fontWeight: 600 }}>{t}</div><div style={{ fontSize: 12, color: "var(--au-text-2)", marginTop: 2 }}>{d}</div></div>
                  </div>
                ))}
              </div>
              <button type="button" className="au-btn au-btn-primary" style={{ width: "100%", marginTop: 18 }} onClick={() => setOpen(false)}>Entendi, estou participando!</button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* ---------- Sorteio na aba Recompensas (criação da conta + 13 dias) ---------- */
const DEMO = Array.from({ length: RAFFLE_SLOTS }, (_, i) => `Participante ${String(i + 1).padStart(2, "0")}`);
const WINNER = 6;

export const ReferralUnlock = ({ createdAt, forceUnlocked }: { createdAt?: string | null; forceUnlocked?: boolean }) => {
  const target = useMemo(() => (createdAt ? new Date(new Date(createdAt).getTime() + RAFFLE_DAYS * DAY_MS) : null), [createdAt]);
  if (!target && !forceUnlocked) return null;

  return (
    <section className="au-card pr-sec">
      <div className="pr-sec-title"><Trophy />{forceUnlocked ? "Resultado do sorteio" : "Sorteio"}</div>
      {forceUnlocked ? (
        <>
          <p className="ad-sub" style={{ marginTop: 8 }}>Prêmio de até {RAFFLE_PRIZE},00 para o comprador número {RAFFLE_BUYER}.</p>
          <div className="ad-note warn" style={{ marginTop: 14 }}>
            <Trophy /><div><b>Demonstração.</b> Participantes e vencedor abaixo são fictícios, só para visualizar como o resultado aparece. Nada aqui foi sorteado.</div>
          </div>
          <div className="pr-people">
            {DEMO.map((n, i) => (
              <div key={n} className={"pr-person" + (i === WINNER ? " win" : "")}><i>{i + 1}</i>{n}{i === WINNER ? " · vencedor" : ""}</div>
            ))}
          </div>
        </>
      ) : (
        <>
          <p className="ad-sub" style={{ marginTop: 8, marginBottom: 16 }}>
            Você está concorrendo a até {RAFFLE_PRIZE},00. São somente {RAFFLE_SLOTS} participantes. Faltam:
          </p>
          <Countdown target={target!} />
          <p className="ad-sub" style={{ marginTop: 14 }}>
            Quando o tempo zerar, o contador apenas para em zero: o resultado não aparece sozinho nesta tela.
          </p>
        </>
      )}
    </section>
  );
};
