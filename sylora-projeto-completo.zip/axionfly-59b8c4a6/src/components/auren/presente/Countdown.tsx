import { useEffect, useState } from "react";
import { splitRemaining } from "@/lib/raffleDate";
import "./presente.css";

/** Contagem regressiva com dias/horas/minutos/segundos, atualizada a cada segundo (arredonda para baixo). */
export const Countdown = ({ target, small }: { target: Date; small?: boolean }) => {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const r = splitRemaining(target, now);
  const cells: [number, string][] = [[r.days, "dias"], [r.hours, "horas"], [r.minutes, "min"], [r.seconds, "seg"]];
  return (
    <div className={"pr-count" + (small ? " sm" : "")} role="timer" aria-label={`${r.days} dias, ${r.hours} horas, ${r.minutes} minutos e ${r.seconds} segundos`}>
      {cells.map(([n, l]) => (
        <div key={l} className="pr-tile"><b>{String(n).padStart(2, "0")}</b><span>{l}</span></div>
      ))}
    </div>
  );
};

/** Bônus: criação da conta + 6 dias. Ao zerar, o bloco some; o contador sozinho não libera nada. */
export const useDone = (target: Date | null) => {
  const [done, setDone] = useState(() => !!target && target.getTime() <= Date.now());
  useEffect(() => {
    if (!target) return;
    const t = setInterval(() => setDone(target.getTime() <= Date.now()), 1000);
    return () => clearInterval(t);
  }, [target]);
  return done;
};
