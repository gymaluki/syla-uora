import { useEffect, useState } from "react";
import { Bell, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { NOTICE_KEYS } from "./admin/SitePanels";

const seenKey = (text: string) => {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) | 0;
  return `sylora_notice_${h}`;
};

/** Faixa de aviso do Painel Admin. Cada membro pode fechar; texto novo volta a aparecer. */
const MemberNotice = () => {
  const [text, setText] = useState("");
  const [hidden, setHidden] = useState(true);
  useEffect(() => {
    let on = true;
    (async () => {
      try {
        const { data } = await supabase.from("site_settings").select("key,value").in("key", [NOTICE_KEYS.on, NOTICE_KEYS.text]);
        const m: Record<string, string> = {};
        (data || []).forEach((r) => { m[r.key] = r.value ?? ""; });
        const t = (m[NOTICE_KEYS.text] || "").trim();
        if (!on || m[NOTICE_KEYS.on] !== "true" || !t) return;
        let closed = false;
        try { closed = localStorage.getItem(seenKey(t)) === "1"; } catch { /* sem storage */ }
        setText(t);
        setHidden(closed);
      } catch { /* sem aviso */ }
    })();
    return () => { on = false; };
  }, []);
  if (hidden || !text) return null;
  const close = () => {
    setHidden(true);
    try { localStorage.setItem(seenKey(text), "1"); } catch { /* sem storage */ }
  };
  return (
    <div role="status" className="mb-4 flex items-start gap-3 rounded-2xl border border-[var(--au-border)] bg-[var(--au-surface)] px-4 py-3">
      <Bell className="w-4 h-4 mt-0.5 shrink-0 text-[var(--au-text)]" />
      <p className="flex-1 text-[13.5px] leading-relaxed text-[var(--au-text)]">{text}</p>
      <button type="button" onClick={close} aria-label="Fechar aviso" className="shrink-0 text-[var(--au-text-3)] hover:text-[var(--au-text)]"><X className="w-4 h-4" /></button>
    </div>
  );
};

export default MemberNotice;
