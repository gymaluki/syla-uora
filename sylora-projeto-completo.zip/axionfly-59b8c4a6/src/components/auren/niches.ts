import {
  Activity, Apple, Beef, Brain, Brush, Bug, Building2, Cake, Calculator, Camera, Car, ChefHat, Croissant, DraftingCompass, Droplets, Dumbbell, FileText, Flower2, Glasses, Hand, HeartHandshake, HeartPulse, IceCreamCone, KeyRound, Languages, Leaf, Megaphone, Music, NotebookPen, PaintRoller, PawPrint, Pill, Pizza, Scale, Scissors, Smartphone, Smile, Soup, Sparkles, Stethoscope, Store, Swords, UtensilsCrossed, Waves, Wrench, Zap,
  type LucideIcon,
} from "lucide-react";

// Os 52 nichos do gerador de prompts. Aqui ficam só nome, ícone e cores sugeridas;
// o texto do prompt de cada nicho é montado no backend (função gerar-prompt).
export interface Niche {
  key: string;
  label: string;
  icon: LucideIcon;
  /** Label usado na Busca de Leads (trava o nicho lá). */
  leadsLabel?: string;
  defaultPrimary: string;
  defaultSecondary: string;
  /** Disponível também como aplicativo (PWA). */
  permiteApp: boolean;
}

export const NICHES: Niche[] = [
  { key: "barbearia", label: "Barbearia", icon: Scissors, leadsLabel: "Barbearias", defaultPrimary: "#D4AF37", defaultSecondary: "#1A1A2E", permiteApp: true },
  { key: "pizzaria", label: "Pizzaria", icon: Pizza, leadsLabel: "Pizzarias", defaultPrimary: "#E31837", defaultSecondary: "#FF6B35", permiteApp: true },
  { key: "fine-dining", label: "Restaurante Fine Dining", icon: UtensilsCrossed, leadsLabel: "Restaurantes", defaultPrimary: "#D4AF37", defaultSecondary: "#1A1410", permiteApp: true },
  { key: "restaurante-bairro", label: "Restaurante de Bairro", icon: UtensilsCrossed, leadsLabel: "Restaurantes", defaultPrimary: "#C2410C", defaultSecondary: "#FACC15", permiteApp: true },
  { key: "clinica", label: "Clínica Odontológica", icon: Smile, leadsLabel: "Clínicas", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981", permiteApp: true },
  { key: "petshop", label: "Pet Shop", icon: PawPrint, leadsLabel: "Pet Shops", defaultPrimary: "#E8734A", defaultSecondary: "#E8A644", permiteApp: true },
  { key: "sobrancelhas", label: "Design de Sobrancelhas", icon: Brush, leadsLabel: "Estética", defaultPrimary: "#D4AF37", defaultSecondary: "#F472B6", permiteApp: true },
  { key: "mecanica", label: "Mecânica Automotiva", icon: Wrench, leadsLabel: "Mecânicas", defaultPrimary: "#F97316", defaultSecondary: "#1A1A1A", permiteApp: false },
  { key: "hamburgueria", label: "Hamburgueria", icon: Beef, leadsLabel: "Hamburguerias", defaultPrimary: "#F97316", defaultSecondary: "#1A1A1A", permiteApp: true },
  { key: "acaiteria", label: "Açaiteria", icon: IceCreamCone, leadsLabel: "Açaiteria", defaultPrimary: "#6B21A8", defaultSecondary: "#16A34A", permiteApp: true },
  { key: "lavarapido", label: "Lava-Rápido", icon: Car, leadsLabel: "Lava Jato", defaultPrimary: "#0EA5E9", defaultSecondary: "#1A1A1A", permiteApp: false },
  { key: "vidracaria", label: "Vidraçaria", icon: Store, defaultPrimary: "#0EA5E9", defaultSecondary: "#374151", permiteApp: false },
  { key: "assistencia", label: "Assistência Técnica", icon: Smartphone, leadsLabel: "Assistência Técnica", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981", permiteApp: false },
  { key: "academia", label: "Academia", icon: Dumbbell, leadsLabel: "Academias", defaultPrimary: "#DC2626", defaultSecondary: "#F97316", permiteApp: true },
  { key: "advogado", label: "Escritório de Advocacia", icon: Scale, leadsLabel: "Advogados", defaultPrimary: "#D4AF37", defaultSecondary: "#1E3A8A", permiteApp: false },
  { key: "imobiliaria", label: "Imobiliária", icon: Building2, leadsLabel: "Imobiliárias", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37", permiteApp: false },
  { key: "salaobeleza", label: "Salão de Beleza", icon: Sparkles, leadsLabel: "Salões de Beleza", defaultPrimary: "#F472B6", defaultSecondary: "#D4AF37", permiteApp: true },
  { key: "contabilidade", label: "Contabilidade", icon: Calculator, leadsLabel: "Contadores", defaultPrimary: "#16A34A", defaultSecondary: "#1E3A8A", permiteApp: false },
  { key: "estetica", label: "Estética / Depilação", icon: Leaf, leadsLabel: "Estética", defaultPrimary: "#F472B6", defaultSecondary: "#D4AF37", permiteApp: true },
  { key: "marmitaria", label: "Marmitaria", icon: Soup, leadsLabel: "Restaurantes", defaultPrimary: "#16A34A", defaultSecondary: "#FACC15", permiteApp: true },
  { key: "idiomas", label: "Escola de Idiomas", icon: Languages, leadsLabel: "Escolas de Idiomas", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981", permiteApp: false },
  { key: "fotografo", label: "Fotógrafo", icon: Camera, leadsLabel: "Fotógrafos", defaultPrimary: "#F8FAFC", defaultSecondary: "#1A1A1A", permiteApp: false },
  { key: "marketing-digital", label: "Marketing Digital", icon: Megaphone, defaultPrimary: "#2563EB", defaultSecondary: "#7C3AED", permiteApp: false },
  { key: "artes-marciais", label: "Academia de Artes Marciais", icon: Swords, leadsLabel: "Academias", defaultPrimary: "#DC2626", defaultSecondary: "#1A1A1A", permiteApp: true },
  { key: "papelaria", label: "Papelaria / Artesanato", icon: NotebookPen, defaultPrimary: "#F472B6", defaultSecondary: "#10B981", permiteApp: false },
  { key: "manicure", label: "Manicure", icon: Hand, leadsLabel: "Manicures", defaultPrimary: "#F472B6", defaultSecondary: "#D4AF37", permiteApp: true },
  { key: "dentista", label: "Dentista", icon: Stethoscope, leadsLabel: "Dentistas", defaultPrimary: "#0EA5E9", defaultSecondary: "#10B981", permiteApp: true },
  { key: "restaurante", label: "Restaurante", icon: ChefHat, leadsLabel: "Restaurantes", defaultPrimary: "#8B2E2E", defaultSecondary: "#D4AF37", permiteApp: true },
  { key: "padaria", label: "Padaria", icon: Croissant, leadsLabel: "Padarias", defaultPrimary: "#A0522D", defaultSecondary: "#E8B84A", permiteApp: true },
  { key: "farmacia", label: "Farmácia", icon: Pill, leadsLabel: "Farmácias", defaultPrimary: "#16A34A", defaultSecondary: "#0EA5E9", permiteApp: true },
  { key: "otica", label: "Ótica", icon: Glasses, leadsLabel: "Óticas", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37", permiteApp: true },
  { key: "floricultura", label: "Floricultura", icon: Flower2, leadsLabel: "Floricultura", defaultPrimary: "#F472B6", defaultSecondary: "#16A34A", permiteApp: false },
  { key: "estetica-corporal", label: "Clínica de Estética", icon: Waves, leadsLabel: "Estética Corporal", defaultPrimary: "#D4AF37", defaultSecondary: "#F8FAFC", permiteApp: true },
  { key: "nutricionista", label: "Nutricionista", icon: Apple, leadsLabel: "Nutricionista", defaultPrimary: "#16A34A", defaultSecondary: "#F8FAFC", permiteApp: true },
  { key: "psicologo", label: "Psicólogo / Terapeuta", icon: Brain, leadsLabel: "Psicólogo", defaultPrimary: "#1E3A8A", defaultSecondary: "#F1F5F9", permiteApp: true },
  { key: "personal-trainer", label: "Personal Trainer", icon: Dumbbell, leadsLabel: "Personal Trainer", defaultPrimary: "#FACC15", defaultSecondary: "#0F172A", permiteApp: true },
  { key: "fisioterapeuta", label: "Fisioterapeuta", icon: Activity, leadsLabel: "Fisioterapeuta", defaultPrimary: "#0891B2", defaultSecondary: "#F8FAFC", permiteApp: true },
  { key: "buffet", label: "Buffet / Eventos", icon: Cake, leadsLabel: "Buffet / Eventos", defaultPrimary: "#D4AF37", defaultSecondary: "#1A1A1A", permiteApp: true },
  { key: "escola-musica", label: "Escola de Música", icon: Music, leadsLabel: "Escola de Música", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37", permiteApp: false },
  { key: "veterinaria", label: "Clínica Veterinária", icon: HeartPulse, leadsLabel: "Veterinária", defaultPrimary: "#14B8A6", defaultSecondary: "#F8FAFC", permiteApp: true },
  { key: "dedetizadora", label: "Dedetizadora", icon: Bug, leadsLabel: "Dedetizadora", defaultPrimary: "#FACC15", defaultSecondary: "#0F172A", permiteApp: false },
  { key: "chaveiro", label: "Chaveiro", icon: KeyRound, leadsLabel: "Chaveiro", defaultPrimary: "#2563EB", defaultSecondary: "#F8FAFC", permiteApp: false },
  { key: "arquiteto", label: "Arquiteto / Designer", icon: DraftingCompass, leadsLabel: "Arquiteto", defaultPrimary: "#374151", defaultSecondary: "#F8FAFC", permiteApp: false },
  { key: "eletricista", label: "Eletricista", icon: Zap, leadsLabel: "Eletricista", defaultPrimary: "#2563EB", defaultSecondary: "#FACC15", permiteApp: false },
  { key: "encanador", label: "Encanador", icon: Droplets, leadsLabel: "Encanador", defaultPrimary: "#0284C7", defaultSecondary: "#F8FAFC", permiteApp: false },
  { key: "pintor", label: "Pintor de Obras", icon: PaintRoller, leadsLabel: "Pintor", defaultPrimary: "#EA580C", defaultSecondary: "#F8FAFC", permiteApp: false },
  { key: "despachante", label: "Despachante", icon: FileText, leadsLabel: "Despachante", defaultPrimary: "#1E3A8A", defaultSecondary: "#D4AF37", permiteApp: false },
  { key: "saude-mental", label: "Clínica de Saúde Mental", icon: HeartHandshake, leadsLabel: "Saúde Mental", defaultPrimary: "#8B5CF6", defaultSecondary: "#FDF4FF", permiteApp: true },
  { key: "cuidador-idosos", label: "Cuidador de Idosos", icon: HeartPulse, leadsLabel: "Cuidador de Idosos", defaultPrimary: "#3B82F6", defaultSecondary: "#FEF2F2", permiteApp: false },
  { key: "produtos-naturais", label: "Produtos Naturais", icon: Leaf, leadsLabel: "Produtos Naturais", defaultPrimary: "#15803D", defaultSecondary: "#FEFCE8", permiteApp: false },
  { key: "pilates", label: "Studio de Pilates", icon: Waves, leadsLabel: "Pilates", defaultPrimary: "#78716c", defaultSecondary: "#F1F5F9", permiteApp: true },
  { key: "quiropraxia", label: "Quiropraxia / Acupuntura", icon: Hand, leadsLabel: "Quiropraxia", defaultPrimary: "#0F172A", defaultSecondary: "#F8FAFC", permiteApp: true },
];
export const nicheByKey = (key: string) => NICHES.find((n) => n.key === key);
