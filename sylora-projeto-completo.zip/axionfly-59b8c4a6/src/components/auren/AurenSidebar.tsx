import { motion, useReducedMotion } from "framer-motion";
import { LayoutGrid, Sparkles, Search, Rocket, Bot, Gift, UserCircle, Plus, ChevronUp, LogOut, Shield, Users, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Sidebar, useSidebar } from "@/components/ui/sidebar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { AurenMark } from "./AurenLogo";
import "./sylora-shell.css";

export type AurenView =
  | "vendas" | "criar" | "creditos" | "analise" | "portfolio" | "mentor" | "presente"
  | "perfil" | "admin" | "meu-grupo";

const navItems: { id: AurenView; label: string; icon: React.ElementType }[] = [
  { id: "vendas", label: "Dashboard", icon: LayoutGrid },
  { id: "creditos", label: "Ativar Créditos", icon: Sparkles },
  { id: "analise", label: "Diagnóstico de Sites", icon: Search },
  { id: "portfolio", label: "Meu Portfólio", icon: Rocket },
  { id: "mentor", label: "Mentor de Vendas", icon: Bot },
  { id: "presente", label: "Recompensas", icon: Gift },
];

interface Props {
  active: AurenView;
  onNavigate: (view: AurenView) => void;
  onSignOut: () => void;
  userEmail?: string;
  userName?: string;
  isAdmin?: boolean;
  showGrupo?: boolean;
}

const SPRING = { type: "spring", stiffness: 480, damping: 40, mass: 0.8 } as const;

const AurenSidebar = ({ active, onNavigate, onSignOut, userEmail, userName, isAdmin, showGrupo }: Props) => {
  const { isMobile, setOpenMobile } = useSidebar();
  const reduce = useReducedMotion();

  const go = (v: AurenView) => {
    onNavigate(v);
    if (isMobile) setOpenMobile(false);
  };

  const items = [
    ...navItems,
    ...(showGrupo ? [{ id: "meu-grupo" as AurenView, label: "Seu Grupo", icon: Users }] : []),
    ...(isAdmin ? [{ id: "admin" as AurenView, label: "Painel Admin", icon: Shield }] : []),
  ];

  const displayName = userName || userEmail?.split("@")[0] || "Usuário";
  const initials = displayName.slice(0, 2).toUpperCase();

  const sepAfter = new Set<AurenView>(["vendas", "mentor"]);

  return (
    <Sidebar collapsible="offcanvas" className="auren au-dark border-transparent">
      {/* No celular a barra abre num Sheet fora do .auren, por isso o tema é reaplicado aqui dentro */}
      <div className="auren au-dark sy-side">
        <div className="sy-brand">
          <AurenMark size={50} className="text-white" />
        </div>

        <button type="button" onClick={() => go("criar")} className="sy-new">
          <Plus className="plus" />
          Criar Site ou App
          <span className="go"><ArrowUpRight /></span>
        </button>

        <nav className="sy-nav" aria-label="Principal">
          {items.map(({ id, label, icon: Icon }) => {
            const on = active === id;
            return (
              <div key={id} className="contents">
                <button
                  type="button"
                  onClick={() => go(id)}
                  aria-current={on ? "page" : undefined}
                  className={cn("sy-item", on && "active")}
                >
                  {on && <motion.span layoutId="au-nav-ind" className="bar" initial={false} transition={reduce ? { duration: 0 } : SPRING} />}
                  <span className="ico"><Icon /></span>
                  {label}
                </button>
                {sepAfter.has(id) && <div className="sep" aria-hidden />}
              </div>
            );
          })}
        </nav>

        <div className="sy-grow" aria-hidden />

        <div className="sy-foot">
          <button
            type="button"
            onClick={() => go("perfil")}
            aria-current={active === "perfil" ? "page" : undefined}
            className={cn("sy-item", active === "perfil" && "active")}
          >
            {active === "perfil" && <span className="bar" />}
            <span className="ico"><UserCircle /></span>
            Perfil
          </button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className="sy-user">
                <div className="sy-avatar">{initials}<i /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13.5px] font-bold text-white truncate leading-tight">{displayName}</p>
                  <p className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-[#6C6F79] mt-1">Membro Premium</p>
                </div>
                <ChevronUp className="w-4 h-4 text-[#6C6F79] shrink-0" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="w-56 bg-[#0B0B0D] border-white/10 text-white">
              <DropdownMenuItem onClick={() => go("perfil")} className="focus:bg-white/5 py-2.5">
                <UserCircle className="w-4 h-4 mr-3" /> Meu Perfil
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onSignOut} className="text-red-400 focus:bg-red-400/10 focus:text-red-400 py-2.5">
                <LogOut className="w-4 h-4 mr-3" /> Sair da conta
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </Sidebar>
  );
};

export default AurenSidebar;
