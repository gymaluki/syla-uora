import { useState } from "react";
import { motion } from "framer-motion";
import {
  Briefcase, Globe, Layers, MessageSquare, Palette, Rocket, Star, Target, User, WandSparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";
import GenerationModal, { copyText } from "./GenerationModal";

const TIPOS = [
  "Portfólio pessoal (profissional autônomo)",
  "Portfólio de agência / estúdio",
  "Site institucional de empresa",
  "Página de serviço único",
];

const ESTILOS = [
  "Moderno minimalista, com muito espaço, hierarquia forte e visual limpo",
  "Escuro e premium, com alto contraste e detalhes metálicos",
  "Editorial, com tipografia grande e fotos em destaque",
  "Criativo e ousado, com cores vibrantes e formas marcantes",
  "Clássico e elegante, com serifas e tons neutros",
];

const PALETAS = [
  "Azul marinho + branco + preto",
  "Preto + prata + branco",
  "Preto + dourado",
  "Verde + bege + branco",
  "Roxo + rosa + branco",
  "Terracota + creme + marrom",
  "Tons de cinza + um destaque vibrante",
];

const SECOES: { label: string; on: boolean }[] = [
  { label: "Seção inicial impactante", on: true },
  { label: "Sobre / quem sou", on: true },
  { label: "Serviços", on: true },
  { label: "Portfólio / projetos", on: true },
  { label: "Depoimentos", on: true },
  { label: "Estatísticas (anos, projetos, clientes)", on: false },
  { label: "Processo de trabalho", on: false },
  { label: "Blog / conteúdo", on: false },
  { label: "Preços / planos", on: false },
  { label: "FAQ", on: false },
  { label: "Formulário de contato", on: true },
  { label: "WhatsApp flutuante", on: true },
];

const PortfolioIAView = () => {
  const [f, setF] = useState({
    tipo: TIPOS[0], nome: "", profissao: "", tagline: "", sobre: "", servicos: "", diferenciais: "",
    publico: "", cidade: "", acao: "", estilo: ESTILOS[0], paleta: PALETAS[0], whatsapp: "", instagram: "", referencias: "",
  });
  const [secoes, setSecoes] = useState(SECOES.filter((x) => x.on).map((x) => x.label));
  const [genOpen, setGenOpen] = useState(false);
  const [prompt, setPrompt] = useState("");

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF((prev) => ({ ...prev, [k]: e.target.value }));
  const toggle = (label: string) =>
    setSecoes((prev) => (prev.includes(label) ? prev.filter((x) => x !== label) : [...prev, label]));

  const ready = f.nome.trim().length > 0 && f.profissao.trim().length > 0;
  const v = (x: string, fallback = "(crie com base no nicho)") => x.trim() || fallback;

  const generate = () => {
    const p = `Você é um especialista em UI/UX, branding pessoal e copywriting de alta conversão. Crie um site de portfólio profissional, responsivo e pronto para publicar:

### 1. QUEM É
- **Tipo de site:** ${f.tipo}
- **Nome / marca:** ${f.nome.trim()}
- **Profissão ou nicho:** ${f.profissao.trim()}
- **Tagline (abre o site):** ${v(f.tagline)}
- **Sobre:** ${v(f.sobre)}

### 2. OFERTA
- **Serviços:** ${v(f.servicos)}
- **Diferenciais competitivos:** ${v(f.diferenciais)}
- **Público-alvo:** ${v(f.publico)}
- **Cidade / região:** ${v(f.cidade, "não informado")}
- **Ação principal do visitante:** ${v(f.acao, "Solicitar orçamento no WhatsApp")}

### 3. VISUAL
- **Estilo:** ${f.estilo}
- **Paleta de cores:** ${f.paleta}
- **Referências de inspiração:** ${v(f.referencias, "nenhuma")}

### 4. SEÇÕES
${secoes.map((s) => `- ${s}`).join("\n")}

### 5. CONTATO
- **WhatsApp:** ${v(f.whatsapp, "não informado")}
- **Instagram:** ${v(f.instagram, "não informado")}

### 6. REQUISITOS
- Mobile-first, contraste WCAG AA, animações suaves com Framer Motion.
- Textos persuasivos em português do Brasil, escritos para o público-alvo acima.
- O botão principal de toda página executa a ação principal informada.`;
    setPrompt(p);
    copyText(p);
    setGenOpen(true);
  };

  return (
    <div className="max-w-[1000px] mx-auto pt-10 pb-16">
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <h2 className="au-display text-[36px] md:text-[44px] font-bold text-[var(--au-text)] leading-[1.1]">
          Monte <span className="au-shine">seu portfólio perfeito</span>
        </h2>
        <p className="text-[15px] text-[var(--au-text-2)] mt-3">
          Responda as perguntas abaixo e a Sylora gera o seu portfólio profissional na hora.
        </p>
      </motion.div>

      <motion.div
        className="au-card p-6 md:p-8 mt-9 space-y-6"
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
      >
        <Field icon={Layers} label="Tipo de site">
          <select className="au-select" value={f.tipo} onChange={set("tipo")}>
            {TIPOS.map((t) => <option key={t}>{t}</option>)}
          </select>
        </Field>

        <div className="grid md:grid-cols-2 gap-5">
          <Field icon={User} label="Seu nome ou nome da marca *">
            <input className="au-input" placeholder="ex: Marina Costa / Studio Norte" value={f.nome} onChange={set("nome")} />
          </Field>
          <Field icon={Briefcase} label="Profissão ou nicho *">
            <input className="au-input" placeholder="ex: arquiteta de interiores / agência de sites" value={f.profissao} onChange={set("profissao")} />
          </Field>
        </div>

        <Field icon={MessageSquare} label="Tagline (frase de impacto que abre o site)">
          <input className="au-input" placeholder={'ex: "Projetos que vendem antes do cliente entrar."'} value={f.tagline} onChange={set("tagline")} />
        </Field>

        <Field icon={User} label="Sobre você / sua empresa (1 parágrafo)">
          <textarea className="au-textarea" placeholder="quem é, quantos anos de mercado, especialidade, propósito" value={f.sobre} onChange={set("sobre")} />
        </Field>

        <Field icon={Star} label="Serviços (separe por vírgula)">
          <textarea className="au-textarea" placeholder="ex: criação de sites, páginas de venda, identidade visual, gestão de tráfego" value={f.servicos} onChange={set("servicos")} />
        </Field>

        <Field icon={WandSparkles} label="Diferenciais competitivos">
          <textarea className="au-textarea" placeholder="ex: entrego em 7 dias, atendimento humano, garantia de revisão, +100 sites no ar" value={f.diferenciais} onChange={set("diferenciais")} />
        </Field>

        <div className="grid md:grid-cols-2 gap-5">
          <Field icon={Target} label="Público-alvo">
            <input className="au-input" placeholder="ex: pequenas empresas locais que querem profissionalizar" value={f.publico} onChange={set("publico")} />
          </Field>
          <Field icon={Globe} label="Cidade / região (opcional)">
            <input className="au-input" placeholder="ex: Curitiba e região" value={f.cidade} onChange={set("cidade")} />
          </Field>
        </div>

        <Field icon={Rocket} label="Ação principal que o visitante deve tomar">
          <input className="au-input" placeholder={'ex: "Solicitar orçamento no WhatsApp" / "Agendar reunião"'} value={f.acao} onChange={set("acao")} />
        </Field>

        <div className="grid md:grid-cols-2 gap-5">
          <Field icon={WandSparkles} label="Estilo visual">
            <select className="au-select" value={f.estilo} onChange={set("estilo")}>
              {ESTILOS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field icon={Palette} label="Paleta de cores">
            <select className="au-select" value={f.paleta} onChange={set("paleta")}>
              {PALETAS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
        </div>

        <Field icon={Layers} label="Seções que o site deve ter (clique pra escolher)">
          <div className="flex flex-wrap gap-2">
            {SECOES.map(({ label }) => (
              <button key={label} type="button" onClick={() => toggle(label)} className={cn("au-chip", secoes.includes(label) && "on")}>
                {label}
              </button>
            ))}
          </div>
        </Field>

        <div className="grid md:grid-cols-2 gap-5">
          <Field icon={MessageSquare} label="WhatsApp (com DDI/DDD)">
            <input className="au-input" placeholder="ex: 5541999999999" value={f.whatsapp} onChange={set("whatsapp")} />
          </Field>
          <Field icon={Globe} label="Instagram">
            <input className="au-input" placeholder="ex: @marinacosta.arq" value={f.instagram} onChange={set("instagram")} />
          </Field>
        </div>

        <Field icon={Star} label="Referências de inspiração (opcional)">
          <textarea className="au-textarea" placeholder="ex: gosto do site da Apple, da Linear e do estúdio Pentagram" value={f.referencias} onChange={set("referencias")} />
        </Field>
      </motion.div>

      <motion.div
        className="au-card au-light mt-6 p-7 text-center"
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
      >
        <button type="button" disabled={!ready} onClick={generate} className="au-btn au-btn-primary px-5 sm:px-10 max-w-full" style={{ height: "auto", minHeight: 52, paddingBlock: 10, letterSpacing: "0.14em", fontSize: 13.5, whiteSpace: "normal", lineHeight: 1.3 }}>
          <Rocket /> GERAR MEU PORTFÓLIO PROFISSIONAL
        </button>
        <p className="text-[12px] text-[var(--au-text-3)] mt-4">
          {ready ? "Tudo certo — a Sylora monta o prompt completo pra você." : "Preencha pelo menos o nome e a profissão para liberar."}
        </p>
      </motion.div>

      <GenerationModal open={genOpen} kind="portfolio" prompt={prompt} onClose={() => setGenOpen(false)} />
    </div>
  );
};

const Field = ({ icon: Icon, label, children }: { icon: React.ElementType; label: string; children: React.ReactNode }) => (
  <div>
    <label className="au-label"><Icon />{label}</label>
    {children}
  </div>
);

export default PortfolioIAView;
