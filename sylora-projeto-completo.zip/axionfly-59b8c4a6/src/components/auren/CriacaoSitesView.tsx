import React, { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft, ArrowRight, Check, Copy, Lightbulb, Link2, MapPin, MessageSquare, Palette, Phone, RotateCcw,
  Search, Smartphone, Sparkles, Store,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import ProspeccaoView from "@/components/views/ProspeccaoView";
import { useBuilderConfig, fillPrompt, type NamedColor } from "@/lib/builderConfig";
import { useSiteText, markParts } from "@/lib/siteContent";
import GenerationModal, { copyText } from "./GenerationModal";
import "./sylora-shell.css";

type Kind = "site" | "app";

const KIND_INFO: Record<Kind, {
  icon: React.ElementType; tag: string; title: string; desc: string; checks: string[];
}> = {
  site: {
    icon: Store, tag: "Landing page", title: "Site",
    desc: "Página profissional para captar clientes, mostrar serviços e converter visitantes em vendas reais.",
    checks: ["Hero + seções de conversão", "WhatsApp integrado", "SEO local pronto"],
  },
  app: {
    icon: Smartphone, tag: "Mobile · PWA", title: "App",
    desc: "Aplicativo instalável no celular para delivery, cardápio digital ou agendamento de horários 24h.",
    checks: ["Instalável no celular", "Carrinho ou agenda", "Sem comissão de marketplace"],
  },
};

const STEPS = ["Leads", "Negócio", "Abordagem"];
const PROGRESS = [33, 66, 100];
const OBJETIVO = "agendar uma conversa";

const maskPhone = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length > 6) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length > 2) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length > 0) return `(${d}`;
  return d;
};

const cityFrom = (address: string) => {
  const a = address.trim();
  if (!a) return "sua cidade";
  const afterDash = a.split("—").pop() ?? a;
  return (afterDash.split(",").pop() ?? afterDash).trim() || a;
};

const shine = (text: string) => markParts(text).map((p, i) => (p.mark ? <span key={i} className="au-shine">{p.t}</span> : <React.Fragment key={i}>{p.t}</React.Fragment>));

interface Saved {
  kind: Kind | null; step: number; niche: string; projectName: string;
  primary: string; secondary: string; address: string; phone: string;
  sendWithSite: boolean; siteLink: string;
}
const EMPTY: Saved = {
  kind: null, step: 0, niche: "", projectName: "", primary: "", secondary: "",
  address: "", phone: "", sendWithSite: false, siteLink: "",
};

const fade = {
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -10 },
  transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
};

const CriacaoSitesView = () => {
  const { niches, colors, nicheByKey } = useBuilderConfig();
  const t = useSiteText();
  const { user } = useAuth();
  const storageKey = user ? `auren-builder-${user.id}` : "";
  const [s, setS] = useState<Saved>(EMPTY);
  const [loaded, setLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [resetOpen, setResetOpen] = useState(false);
  const [genOpen, setGenOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [generating, setGenerating] = useState(false);

  const set = (patch: Partial<Saved>) => setS((prev) => ({ ...prev, ...patch }));

  // ---- persistência local ----
  useEffect(() => {
    if (!storageKey) return;
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) setS({ ...EMPTY, ...JSON.parse(raw) });
    } catch { /* sem armazenamento disponível */ }
    setLoaded(true);
  }, [storageKey]);

  useEffect(() => {
    if (!storageKey || !loaded) return;
    try { localStorage.setItem(storageKey, JSON.stringify(s)); } catch { /* idem */ }
  }, [s, storageKey, loaded]);

  const niche = nicheByKey(s.niche);
  const kind = s.kind;

  const selectNiche = (key: string) => {
    const n = nicheByKey(key);
    set({
      niche: key,
      primary: s.primary || n?.defaultPrimary || "",
      secondary: s.secondary || n?.defaultSecondary || "",
    });
    setSearch("");
  };

  // app só existe para os nichos que têm fluxo de pedido ou agendamento
  const pool = useMemo(() => (kind === "app" ? niches.filter((n) => n.permiteApp) : niches), [kind, niches]);
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
    if (!q) return pool;
    return pool.filter((n) => n.label.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").includes(q));
  }, [search, pool]);

  const canAdvance = s.step === 0 ? !!s.niche : s.step === 1 ? s.projectName.trim().length > 0 : true;
  const validation = s.step === 0 && !s.niche ? "Selecione o tipo de negócio"
    : s.step === 1 && !s.projectName.trim() ? "Preencha o nome do site" : "";

  // ---- script de abordagem ----
  const empresa = s.projectName.trim() || "[Empresa]";
  const nichoLabel = niche?.label || "";
  const cidade = cityFrom(s.address);
  const isApp = kind === "app";

  const vars: Record<string, string> = {
    empresa, cidade, nicho: nichoLabel.toLowerCase(),
    entrega: isApp ? "aplicativos próprios" : "sites profissionais de alta conversão",
    pronto: isApp ? "o app pronto" : "o site pronto",
    link: s.siteLink.trim() || "[link do projeto]",
  };
  const blocks = [
    { title: "Abertura", sub: "Quebre o gelo com cordialidade", text: fillPrompt(t("bld_ab_abertura"), vars) },
    { title: "Apresentação", sub: "Quem é você e o que faz", text: fillPrompt(t("bld_ab_apresentacao"), vars) },
    { title: "Diagnóstico", sub: "Mostre que estudou o cliente", text: fillPrompt(t("bld_ab_diagnostico"), vars) },
    { title: "Proposta de valor", sub: "Os 3 resultados que entrega", text: fillPrompt(t(isApp ? "bld_ab_proposta_app" : "bld_ab_proposta_site"), vars) },
    { title: "Fechamento", sub: "Chamada para ação direta", text: fillPrompt(t(s.sendWithSite ? "bld_ab_fechamento_link" : "bld_ab_fechamento"), vars) },
  ];
  const fullScript = blocks.map((b) => b.text).join("\n\n");

  const openWhats = (text: string) => window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener");
  const copy = async (text: string) => {
    if (await copyText(text)) toast.success("Copiado!");
    else toast.error("Não foi possível copiar");
  };

  // ---- prompt final ----
  // Montado no backend (sem IA, sem gastar crédito): o nicho já tem o prompt completo próprio.
  const generate = async () => {
    if (!niche || generating) return;
    setGenerating(true);
    try {
      if (niche.prompt) {
        const own = fillPrompt(niche.prompt, {
          nome: s.projectName.trim(), endereco: s.address.trim(), telefone: s.phone.trim(),
          cor1: s.primary, cor2: s.secondary, tipo: kind === "app" ? "app" : "site", nicho: niche.label,
        });
        setPrompt(own);
        copyText(own);
        setGenOpen(true);
        return;
      }
      const { data, error } = await supabase.functions.invoke("gerar-prompt", {
        body: {
          niche: niche.key,
          projectType: kind,
          projectName: s.projectName.trim(),
          primaryColor: s.primary,
          secondaryColor: s.secondary,
          address: s.address.trim(),
          phone: s.phone.trim(),
          ctaPrincipal: "whatsapp",
        },
      });
      if (error || !data?.prompt) throw error ?? new Error(data?.error);
      setPrompt(data.prompt);
      copyText(data.prompt);
      setGenOpen(true);
    } catch {
      toast.error("Não foi possível gerar agora. Tente de novo.");
    } finally {
      setGenerating(false);
    }
  };

  const reset = () => {
    setS({ ...EMPTY, kind: s.kind });
    setSearch("");
    toast.success("Processo reiniciado!");
  };

  // ============================================================
  // ESCOLHA DO TIPO
  // ============================================================
  if (!kind) {
    return (
      <motion.div {...fade} className="max-w-[860px] mx-auto pt-4 pb-16">
        <div className="text-center mb-12">
          <span className="au-badge"><Sparkles /> Sylora Builder</span>
          <h2 className="au-display text-[40px] md:text-[48px] font-bold text-[var(--au-text)] mt-6 leading-[1.05]">
            O que vamos <span className="au-shine">criar</span> hoje?
          </h2>
          <p className="text-[15px] text-[var(--au-text-2)] mt-4 max-w-[520px] mx-auto leading-relaxed">
            Escolha o tipo de projeto. O processo seguinte — nicho, leads, negócio e abordagem — é o mesmo nos dois.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          {(Object.keys(KIND_INFO) as Kind[]).map((k, i) => {
            const info = KIND_INFO[k];
            const Icon = info.icon;
            return (
              <motion.button
                key={k}
                type="button"
                onClick={() => set({ ...EMPTY, kind: k })}
                className="au-card au-card-hover au-dark text-left p-6 group"
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.08 + i * 0.08, duration: 0.4 }}
              >
                <div className="flex items-start justify-between">
                  <div className="au-icon-box" style={{ width: 50, height: 50 }}><Icon /></div>
                  <span className="au-badge" style={{ padding: "5px 11px", fontSize: 9.5, letterSpacing: "0.2em" }}>{info.tag}</span>
                </div>
                <h3 className="au-display text-[24px] font-bold text-[var(--au-text)] mt-6">{info.title}</h3>
                <p className="text-[14px] text-[var(--au-text-2)] mt-2 leading-relaxed">{t(k === "site" ? "bld_site_desc" : "bld_app_desc")}</p>
                <ul className="mt-5 space-y-2.5">
                  {info.checks.map((c) => (
                    <li key={c} className="flex items-center gap-2.5 text-[13.5px] text-[var(--au-text)]">
                      <span className="au-check"><Check /></span>{c}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 flex items-center justify-between h-[52px] px-4 rounded-xl border border-white/[0.14] bg-white/[0.02] group-hover:bg-white/[0.06] transition-colors">
                  <span className="text-[14px] font-bold text-[var(--au-text)]">Continuar</span>
                  <span className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "var(--au-silver-grad)" }}>
                    <ArrowRight className="w-3.5 h-3.5 text-white" />
                  </span>
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>
    );
  }

  // ============================================================
  // CONSTRUTOR EM 3 ETAPAS
  // ============================================================
  const KindIcon = KIND_INFO[kind].icon;
  const pct = PROGRESS[s.step];
  const stepStatus = (i: number) => (i < s.step ? "Concluída" : i === s.step ? "Em andamento" : "A seguir");

  const summaryOf = (i: number) => (i === 0 ? nichoLabel : i === 1 ? s.projectName.trim() : "");

  const footer = (i: number) => (
    <div className="sy-stage-ft">
      {i > 0 ? (
        <button type="button" className="au-btn au-btn-ghost" onClick={() => set({ step: i - 1 })}>
          <ArrowLeft /> Voltar
        </button>
      ) : <span />}
      {i < 2 ? (
        <div className="flex flex-col items-end gap-1.5">
          {!canAdvance && validation && <span className="text-[12px] text-[#F87171]">{validation}</span>}
          <button type="button" className="au-btn au-btn-primary" disabled={!canAdvance} onClick={() => set({ step: i + 1 })}>
            Avançar <ArrowRight />
          </button>
        </div>
      ) : (
        <button type="button" className="au-btn au-btn-danger" onClick={() => setResetOpen(true)}>
          <RotateCcw /> Reiniciar processo
        </button>
      )}
    </div>
  );

  const bodies = [
(
                <div>
                  <h3 className="au-display text-[28px] md:text-[32px] font-bold text-[var(--au-text)] leading-tight">
                    {shine(t("bld_h_1"))}
                  </h3>

                  {!niche ? (
                    <>
                      <p className="text-[14.5px] text-[var(--au-text-2)] mt-2">{t("bld_s_1")}</p>
                      <div className="au-command mt-6">
                        <Search className="w-[18px] h-[18px] text-[var(--au-text-2)] shrink-0" />
                        <input
                          placeholder="Buscar nicho... (ex: barbearia, pizzaria, advocacia)"
                          value={search}
                          onChange={(e) => setSearch(e.target.value)}
                        />
                        <span className="text-[10.5px] font-bold text-[var(--au-text-2)] border border-white/[0.12] rounded-full px-2.5 py-1 shrink-0">
                          {pool.length} nichos
                        </span>
                      </div>
                      <div className="au-scroll grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3 mt-5 max-h-[460px] overflow-y-auto pr-1 pb-1">
                        {filtered.map((n, i) => {
                          const Icon = n.icon;
                          return (
                            <motion.button
                              key={n.key}
                              type="button"
                              onClick={() => selectNiche(n.key)}
                              className="au-tile"
                              lang="pt-BR"
                              initial={{ opacity: 0, y: 8 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: Math.min(i * 0.012, 0.3) }}
                            >
                              <span className="ic"><Icon /></span>
                              <span className="lb">{n.label}</span>
                            </motion.button>
                          );
                        })}
                        {filtered.length === 0 && (
                          <p className="col-span-full text-center text-[13px] text-[var(--au-text-3)] py-8">Nenhum nicho encontrado.</p>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      <p className="text-[14.5px] text-[var(--au-text-2)] mt-2">Nicho selecionado. Agora busque seus leads abaixo.</p>
                      <div className="mt-6 flex items-center gap-4 rounded-2xl border border-white/[0.14] bg-white/[0.03] p-4">
                        <span className="au-icon-box solid" style={{ width: 52, height: 52, borderRadius: 14 }}>
                          <niche.icon />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--au-text-3)]">Nicho</p>
                          <p className="au-display text-[18px] font-bold text-[var(--au-text)] truncate">{niche.label}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => set({ niche: "" })}
                          className="h-9 px-4 rounded-full border border-white/[0.14] text-[10px] font-bold tracking-[0.16em] uppercase text-[var(--au-text)] hover:bg-white/[0.06] transition-colors shrink-0"
                        >
                          Trocar
                        </button>
                      </div>

                      <div className="mt-10">
                        <h3 className="au-display text-[22px] font-bold text-[var(--au-text)]">Encontre seus clientes</h3>
                        <p className="text-[14px] text-[var(--au-text-2)] mt-1.5 mb-5">
                          Use a busca para achar negócios reais do seu nicho. Quando terminar, clique em{" "}
                          <span className="text-[var(--au-text)] font-semibold">Avançar</span> para criar o {isApp ? "app" : "site"}.
                        </p>
                        <div className="au-leads-wrap rounded-2xl overflow-hidden border border-white/[0.08]">
                          <ProspeccaoView key={niche.key} lockedNicho={niche.leadsLabel} />
                        </div>
                        <style>{`
                          .au-leads-wrap .prospeccao-root { min-height: 0 !important; margin: 0 !important; }
                          .au-leads-wrap .pp-scroll { max-height: none !important; overflow: visible !important; }
                        `}</style>
                      </div>
                    </>
                  )}
                </div>
  ),
(
                <div>
                  <h3 className="au-display text-[28px] md:text-[32px] font-bold text-[var(--au-text)] leading-tight">
                    {shine(t("bld_h_2"))}
                  </h3>
                  <p className="text-[14.5px] text-[var(--au-text-2)] mt-2">
                    Preencha os dados abaixo para gerarmos um {isApp ? "app" : "site"} sob medida.
                  </p>

                  <div className="mt-8">
                    <Section icon={Store} title="Identidade" desc={`O nome que aparece no ${isApp ? "app" : "site"}.`}>
                      <label className="au-label">Nome do {isApp ? "app" : "site"} *</label>
                      <input
                        className="au-input"
                        placeholder="Ex: Forno & Massa"
                        value={s.projectName}
                        onChange={(e) => set({ projectName: e.target.value })}
                      />
                    </Section>

                    <Section icon={Palette} title="Identidade visual" desc="Escolha as duas cores principais da marca.">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <ColorSelect colors={colors} label="Cor principal *" value={s.primary} onChange={(v) => set({ primary: v })} />
                        <ColorSelect colors={colors} label="Cor secundária *" value={s.secondary} onChange={(v) => set({ secondary: v })} />
                      </div>
                      <div className="mt-4 rounded-xl overflow-hidden border border-white/[0.1]">
                        <div className="flex h-14">
                          <motion.div className="flex-[3]" animate={{ backgroundColor: s.primary || "#1C1C21" }} transition={{ duration: 0.4 }} />
                          <motion.div className="flex-[2]" animate={{ backgroundColor: s.secondary || "#111114" }} transition={{ duration: 0.4 }} />
                        </div>
                        <p className="text-[10.5px] font-bold tracking-[0.16em] uppercase text-[var(--au-text-2)] px-4 py-2.5 bg-white/[0.02]">
                          Pré-visualização da paleta
                        </p>
                      </div>
                    </Section>

                    <Section icon={MapPin} title="Contato e localização" desc="Como os clientes encontram e falam com você." last>
                      <label className="au-label"><MapPin /> Endereço</label>
                      <input
                        className="au-input"
                        placeholder="Ex: Rua das Flores, 123 — Centro, São Paulo"
                        value={s.address}
                        onChange={(e) => set({ address: e.target.value })}
                      />
                      <label className="au-label mt-5"><Phone /> Telefone / WhatsApp</label>
                      <input
                        className="au-input"
                        placeholder="(11) 99999-9999"
                        value={s.phone}
                        onChange={(e) => set({ phone: maskPhone(e.target.value) })}
                      />
                    </Section>
                  </div>
                </div>
  ),
(
                <div>
                  <h3 className="au-display text-[28px] md:text-[32px] font-bold text-[var(--au-text)] leading-tight">
                    {shine(t("bld_h_3"))}
                  </h3>
                  <p className="text-[14.5px] text-[var(--au-text-2)] mt-2 max-w-[560px] leading-relaxed">
                    {t("bld_s_3")}
                  </p>

                  <div className="mt-7 grid grid-cols-2 md:grid-cols-4 rounded-2xl border border-white/[0.08] overflow-hidden">
                    {[
                      ["Empresa", empresa],
                      ["Nicho", nichoLabel],
                      ["Cidade", cidade],
                      ["Objetivo", OBJETIVO],
                    ].map(([k, v], i) => (
                      <div key={k} className={cn("min-w-0 px-4 py-3.5 bg-white/[0.015]", i > 0 && "md:border-l border-white/[0.08]", i % 2 === 1 && "border-l md:border-l", i > 1 && "border-t md:border-t-0")}>
                        <p className="text-[9.5px] font-bold tracking-[0.2em] uppercase text-[var(--au-text-3)]">{k}</p>
                        <p className="text-[14px] font-semibold text-[var(--au-text)] mt-1.5 truncate">{v}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex-1 rounded-2xl border border-white/[0.08] px-4 py-3">
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          role="switch"
                          aria-checked={s.sendWithSite}
                          onClick={() => set({ sendWithSite: !s.sendWithSite })}
                          className={cn("au-switch", s.sendWithSite && "on")}
                        />
                        <span className="flex items-center gap-2 text-[13.5px] font-semibold text-[var(--au-text)]">
                          <Link2 className="w-4 h-4 text-[var(--au-text-2)]" /> Enviar com {isApp ? "app" : "site"} pronto
                        </span>
                      </div>
                      <AnimatePresence>
                        {s.sendWithSite && (
                          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                            <input
                              className="au-input mt-3"
                              placeholder={`Cole aqui o link do ${isApp ? "app" : "site"} pronto`}
                              value={s.siteLink}
                              onChange={(e) => set({ siteLink: e.target.value })}
                            />
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  <div className="mt-8 flex items-center justify-between gap-3">
                    <span className="flex items-center gap-2 text-[15px] font-bold text-[var(--au-text)]">
                      <MessageSquare className="w-4 h-4 text-[var(--au-text-2)]" /> Por etapas
                    </span>
                    <button type="button" onClick={() => openWhats(fullScript)} className="au-btn au-btn-whats">
                      <MessageSquare /> Enviar no WhatsApp
                    </button>
                  </div>

                  {/* Linha do tempo */}
                  <ol className="au-timeline mt-5">
                    {blocks.map((b, i) => (
                      <motion.li
                        key={b.title}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.06 * i, duration: 0.3 }}
                      >
                        <span className="node">
                          {i + 1}
                        </span>
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-[14.5px] font-bold text-[var(--au-text)]">{i + 1}. {b.title}</p>
                            <p className="text-[11.5px] mt-0.5 text-[var(--au-text-3)]">{b.sub}</p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <button type="button" title="Enviar no WhatsApp" onClick={() => openWhats(b.text)} className="au-icon-btn whats">
                              <MessageSquare />
                            </button>
                            <button type="button" title="Copiar" onClick={() => copy(b.text)} className="au-icon-btn">
                              <Copy />
                            </button>
                          </div>
                        </div>
                        <div className="au-bubble">{b.text}</div>
                      </motion.li>
                    ))}
                  </ol>

                  <div className="mt-6 rounded-2xl border border-white/[0.12] px-4 py-3.5 flex gap-3" style={{ background: "linear-gradient(90deg, rgba(255,255,255,0.05), transparent)" }}>
                    <Lightbulb className="w-4 h-4 text-[var(--au-text)] shrink-0 mt-0.5" />
                    <p className="text-[12.5px] text-[var(--au-text-2)] leading-relaxed">
                      <span className="text-[var(--au-text)] font-bold">Dica de ouro:</span> envie a abordagem antes de gerar o {isApp ? "app" : "site"}.
                      Quando o cliente demonstrar interesse, gere a prévia ao vivo e fecha a venda na hora.
                    </p>
                  </div>

                  <button type="button" onClick={generate} disabled={generating} className="au-btn au-btn-primary w-full mt-5" style={{ height: 56, fontSize: 15 }}>
                    <Sparkles /> {generating ? "Preparando…" : `Agora sim — gerar o ${isApp ? "app" : "site"} com IA`}
                  </button>
                </div>
  )
  ];

  return (
    <motion.div {...fade} className="sy-flow max-w-[920px] mx-auto pt-2 pb-16">
      {/* ================= CABEÇALHO DO FLUXO ================= */}
      <header className="sy-flow-hd au-dark">
        <div className="flex items-center gap-3 min-w-0">
          <div className="au-icon-box solid"><KindIcon /></div>
          <div className="min-w-0">
            <p className="au-eyebrow" style={{ fontSize: 9.5 }}>Sylora Builder</p>
            <p className="au-display text-[19px] font-bold text-[var(--au-text)] leading-tight mt-0.5">
              Criando um <span className="au-shine">{KIND_INFO[kind].title}</span>
            </p>
          </div>
        </div>
        <ol className="sy-flow-steps">
          {STEPS.map((label, i) => (
            <li key={label} className={cn(i < s.step && "done", i === s.step && "on")}>
              <span>{i < s.step ? <Check /> : i + 1}</span>{label}
            </li>
          ))}
        </ol>
        <div className="flex items-center gap-4">
          <p className="au-display text-[22px] font-bold text-[var(--au-text)] tabular-nums leading-none">{pct}%</p>
          <button type="button" onClick={() => set({ kind: null })} className="sy-flow-swap">Trocar tipo</button>
        </div>
        <i className="sy-flow-bar"><b style={{ width: `${pct}%` }} /></i>
      </header>

      {/* ================= ETAPAS NA MESMA TELA ================= */}
      {STEPS.map((label, i) => {
        const state = i < s.step ? "done" : i === s.step ? "on" : "next";
        return (
          <section key={label} className={cn("sy-stage", state, state === "on" && "au-builder")}>
            <button type="button" className="sy-stage-hd" disabled={state !== "done"} onClick={() => set({ step: i })}>
              <span className="num">{state === "done" ? <Check /> : i + 1}</span>
              <span className="min-w-0 flex-1 text-left">
                <span className="k">Etapa {i + 1}</span>
                <span className="t">{label}</span>
              </span>
              {state === "done" && <span className="sum">{summaryOf(i)}</span>}
              <span className="st">{stepStatus(i)}</span>
            </button>
            {state === "on" && (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className="sy-stage-body"
              >
                {bodies[i]}
                {footer(i)}
              </motion.div>
            )}
          </section>
        );
      })}

      <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
        <AlertDialogContent className="bg-[var(--au-surface)] border border-[var(--au-border)]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-[var(--au-text)]">Reiniciar processo?</AlertDialogTitle>
            <AlertDialogDescription className="text-[var(--au-text)]/60">
              Todas as respostas serão apagadas. Essa ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent border-[var(--au-border)] text-[var(--au-text)] hover:bg-[var(--au-surface-2)] hover:text-[var(--au-text)]">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={reset} className="bg-[#F87171] hover:bg-[#ef5f5f] text-white font-bold">
              Sim, reiniciar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <GenerationModal open={genOpen} kind={kind} prompt={prompt} onClose={() => setGenOpen(false)} />
    </motion.div>
  );
};

const Section = ({ icon: Icon, title, desc, children, last }: {
  icon: React.ElementType; title: string; desc: string; children: React.ReactNode; last?: boolean;
}) => (
  <div className={cn("grid md:grid-cols-[220px_minmax(0,1fr)] gap-4 md:gap-8 py-7", !last && "border-b border-white/[0.07]")}>
    <div className="flex md:flex-col items-start gap-3">
      <div className="au-icon-box" style={{ width: 40, height: 40 }}><Icon /></div>
      <div>
        <p className="text-[15px] font-bold text-[var(--au-text)]">{title}</p>
        <p className="text-[12.5px] text-[var(--au-text-3)] mt-1 leading-relaxed">{desc}</p>
      </div>
    </div>
    <div className="min-w-0">{children}</div>
  </div>
);

const ColorSelect = ({ colors, label, value, onChange }: { colors: NamedColor[]; label: string; value: string; onChange: (v: string) => void }) => {
  const options = colors.some((c) => c.hex === value) || !value
    ? colors
    : [{ name: value, hex: value }, ...colors];
  const colorName = (hex: string) => options.find((c) => c.hex === hex)?.name || hex;
  return (
    <div>
      <label className="au-label">{label}</label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="au-input flex items-center justify-between [&>svg]:text-[var(--au-text-2)]">
          <SelectValue placeholder="Selecione a cor">
            {value && (
              <span className="inline-flex items-center gap-2.5">
                <span className="w-[18px] h-[18px] rounded-full border-2 border-[var(--au-border-strong)]" style={{ background: value }} />
                {colorName(value)}
              </span>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="bg-[var(--au-surface)] border-[var(--au-border)] text-[var(--au-text)]">
          {options.map((c) => (
            <SelectItem key={c.hex} value={c.hex} className="focus:bg-white/[0.06] focus:text-[var(--au-text)]">
              <span className="inline-flex items-center gap-2.5">
                <span className="w-4 h-4 rounded-full border-2 border-[var(--au-border-strong)]" style={{ background: c.hex }} />
                {c.name}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default CriacaoSitesView;
