import { motion, useReducedMotion } from "framer-motion";
import { BladeRule } from "./fx/parts";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Cabeçalho padrão das telas: pílula + título com palavra em prata + régua de lâmina + subtítulo. */
const PageHero = ({ badge, before, shine, after, sub }: {
  badge?: string; before: string; shine: string; after?: string; sub?: React.ReactNode;
}) => {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className="text-center au-glow-wrap"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: EASE }}
    >
      {badge && <span className="au-badge"><span className="dot" />{badge}</span>}
      <h2 className="au-display text-[40px] md:text-[56px] font-bold text-[var(--au-text)] leading-[1.05] mt-6">
        {before} <span className="au-shine">{shine}</span>{after ? ` ${after}` : ""}
      </h2>
      {/* a lâmina do logo desenha o limite sob o título */}
      <motion.div
        aria-hidden
        className="flex justify-center mt-5"
        style={{ transformOrigin: "50% 50%" }}
        initial={reduce ? false : { opacity: 0, scaleX: 0.15 }}
        animate={{ opacity: 1, scaleX: 1 }}
        transition={{ duration: 0.9, delay: 0.28, ease: EASE }}
      >
        <BladeRule width={168} />
      </motion.div>
      {sub && <p className="text-[15.5px] md:text-[17px] text-[var(--au-text-2)] mt-5 max-w-[680px] mx-auto leading-relaxed">{sub}</p>}
    </motion.div>
  );
};

export default PageHero;
