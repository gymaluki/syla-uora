import { motion } from "framer-motion";
import { Check, Download } from "lucide-react";
import PageHero from "./PageHero";
import { AurenMark } from "./AurenLogo";

const ZIP_URL = "/HyperBuild-Pro-v6.9.4.zip";

const gains = [
  "Créditos ilimitados para criar",
  "Tecnologia Exclusiva Sylora",
  "Acesso liberado para membros Sylora",
  "Velocidade máxima em cada projeto",
  "Atualizações inclusas",
  "Suporte direto da equipe Sylora",
];

const CreditosInfinitosView = () => (
  <div className="max-w-[780px] mx-auto pt-8 pb-16">
    <PageHero
      badge="Parceria exclusiva"
      before="Créditos"
      shine="infinitos"
      sub={<>Tecnologia exclusiva da <span className="text-[var(--au-text)] font-semibold">Sylora</span>. Gratuito para membros.</>}
    />
    <div className="flex items-center justify-center gap-2 mt-7">
      <AurenMark size={38} />
    </div>

    <motion.div
      className="au-card au-light p-6 md:p-8 mt-12"
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15, duration: 0.4 }}
    >
      <div className="flex gap-4">
        <span className="w-9 h-9 rounded-full flex items-center justify-center text-[13px] font-bold text-[var(--au-text)] border border-white/[0.18] bg-white/[0.04] shrink-0">
          1
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-[17px] font-bold text-[var(--au-text)]">Baixar o pacote Créditos Infinitos</h3>
          <p className="text-[14px] text-[var(--au-text-2)] mt-1.5">Faça o download do pacote oficial da Sylora. É rápido, leve e já vem tudo pronto.</p>
          <a href={ZIP_URL} download className="au-btn au-btn-primary mt-5 w-full sm:w-auto" style={{ height: 50, fontSize: 15 }}>
            <Download /> Baixar Créditos Infinitos (.zip)
          </a>
        </div>
      </div>
    </motion.div>

    <div className="au-hairline mt-12" />

    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.25, duration: 0.4 }}
    >
      <p className="au-eyebrow text-center mt-12">O que você ganha</p>
      <ul className="grid sm:grid-cols-2 gap-x-12 gap-y-4 mt-7 max-w-[640px] mx-auto">
        {gains.map((g) => (
          <li key={g} className="flex items-center gap-3 text-[14.5px] text-[var(--au-text)]">
            <span className="au-check"><Check /></span>
            {g}
          </li>
        ))}
      </ul>
    </motion.div>
  </div>
);

export default CreditosInfinitosView;
