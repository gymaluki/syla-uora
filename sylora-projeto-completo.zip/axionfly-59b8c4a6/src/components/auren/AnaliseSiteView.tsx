import { motion } from "framer-motion";
import PageHero from "./PageHero";

const tiers = [
  { tier: "Tier 01", name: "Site Simples", from: "R$ 200", to: "R$ 500",
    desc: "Landing page única, design padrão, cliente pequeno (autônomo, MEI, bairro). Entrega rápida e barata." },
  { tier: "Tier 02", name: "Site Médio", from: "R$ 500", to: "R$ 1.000",
    desc: "Site institucional de 3 a 7 páginas, design personalizado, PME estruturada. Equilíbrio entre preço e qualidade." },
  { tier: "Tier 03", name: "Site Premium", from: "R$ 1.000", to: "R$ 2.500",
    desc: "Projeto profissional com design forte, várias páginas, integrações, animações e identidade visual completa. Para marcas consolidadas ou e-commerce." },
];

const tips = [
  "A maioria dos sites vale entre R$ 200 e R$ 1.000.",
  "Use Simples para autônomos e MEIs.",
  "Use Médio para PMEs que já têm faturamento.",
  "Só venda na faixa Premium quando o projeto tiver design forte e várias integrações.",
];

const AnaliseSiteView = () => (
  <div className="max-w-[1040px] mx-auto pt-8 pb-16">
    <PageHero
      badge="Precificação de mercado"
      before="Análise de"
      shine="Site"
      sub={<>Faixas reais de preço para você fechar com o cliente sem cálculo complicado.<br className="hidden md:block" /> Escolha o tier, apresente com confiança.</>}
    />

    <div className="grid md:grid-cols-3 gap-4 mt-14">
      {tiers.map((t, i) => (
        <motion.div
          key={t.tier}
          className="au-card au-card-hover p-6"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 + i * 0.08, duration: 0.4 }}
        >
          <p className="au-eyebrow" style={{ fontSize: 9.5 }}>{t.tier}</p>
          <h3 className="au-display text-[20px] font-bold text-[var(--au-text)] mt-5">{t.name}</h3>
          <p className="au-display font-bold mt-4 flex items-baseline gap-2 flex-wrap">
            <span className="text-[28px] text-[var(--au-text)]">{t.from}</span>
            <span className="text-[13px] text-[var(--au-text-3)] font-medium">a</span>
            <span className="text-[28px] au-shine">{t.to}</span>
          </p>
          <div className="au-hairline my-5" />
          <p className="text-[14px] text-[var(--au-text-2)] leading-relaxed">{t.desc}</p>
        </motion.div>
      ))}
    </div>

    <motion.div
      className="au-card au-light p-7 md:p-9 mt-10"
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.35, duration: 0.4 }}
    >
      <p className="au-eyebrow" style={{ color: "#F4F5F7" }}>Como usar essas faixas</p>
      <ul className="grid md:grid-cols-2 gap-x-10 gap-y-4 mt-6">
        {tips.map((tip) => (
          <li key={tip} className="flex gap-3 text-[14.5px] text-[var(--au-text)] leading-relaxed">
            <span className="w-1.5 h-1.5 rounded-full mt-2.5 shrink-0" style={{ background: "#DADDE3", boxShadow: "0 0 8px rgba(255,255,255,.6)" }} />
            {tip}
          </li>
        ))}
      </ul>
    </motion.div>
  </div>
);

export default AnaliseSiteView;
