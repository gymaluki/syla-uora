import { useEffect, useMemo, useState } from "react";
import { Clock, Crown, Shield, ShieldCheck, UserPlus, Users } from "lucide-react";
import { toast } from "sonner";
import { adminApi } from "@/lib/adminData";
import { PLAN_LABELS, calcRemaining, fmtDate, type AdminRecord, type AdminUser, type PendingPayment } from "@/lib/adminTypes";
import { Btn, ConfirmBtn, Empty, Field, Note, Panel, Pill, RefreshBtn, SearchBox, Switch, errMsg } from "./ui";

interface UsersProps { users: AdminUser[]; reload: () => Promise<void> | void; busy?: boolean }

const matchUser = (u: AdminUser, q: string) => {
  const s = q.trim().toLowerCase();
  return !s || u.email?.toLowerCase().includes(s) || u.display_name?.toLowerCase().includes(s);
};

/* ============================ Usuários ============================ */
export const UsersPanel = ({ users, reload, busy }: UsersProps) => {
  const [q, setQ] = useState("");
  const [working, setWorking] = useState<string | null>(null);
  const [form, setForm] = useState({ email: "", password: "", plan: "monthly" });
  const [creating, setCreating] = useState(false);
  const [open, setOpen] = useState(false);
  const rows = useMemo(() => users.filter((u) => matchUser(u, q)), [users, q]);

  const run = async (key: string, fn: () => Promise<unknown>, ok = "Atualizado") => {
    setWorking(key);
    try {
      await fn();
      toast.success(ok);
      await reload();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setWorking(null);
    }
  };

  const create = async () => {
    const email = form.email.trim().toLowerCase();
    if (!email || form.password.length < 6) {
      toast.error("Informe o e-mail e uma senha com pelo menos 6 caracteres.");
      return;
    }
    setCreating(true);
    try {
      await adminApi.act("create_user", { email, password: form.password, plan: form.plan });
      toast.success("Conta criada");
      setForm({ email: "", password: "", plan: "monthly" });
      await reload();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setCreating(false);
    }
  };

  return (
    <Panel
      title="Gerenciar usuários"
      icon={<Users />}
      sub={`${users.length} conta${users.length === 1 ? "" : "s"} carregada${users.length === 1 ? "" : "s"}. As contagens consideram só o que foi carregado (até 100 por consulta).`}
      tools={
        <>
          <SearchBox value={q} onChange={setQ} placeholder="Buscar por e-mail ou nome" />
          <Btn onClick={() => setOpen((v) => !v)}><UserPlus />Criar conta manualmente</Btn>
          <RefreshBtn onClick={() => reload()} busy={busy} />
        </>
      }
    >
      {open && (
        <div className="ad-box">
          <div className="ad-form">
            <Field label="E-mail">
              <input className="au-input ad-in" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="cliente@email.com" />
            </Field>
            <Field label="Senha" hint="Mínimo de 6 caracteres.">
              <input className="au-input ad-in" type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Senha inicial" autoComplete="off" />
            </Field>
            <Field label="Plano">
              <select className="au-select ad-in" value={form.plan} onChange={(e) => setForm({ ...form, plan: e.target.value })}>
                {Object.entries(PLAN_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </Field>
            <Btn variant="primary" busy={creating} onClick={create}>Criar conta</Btn>
          </div>
          <div style={{ marginTop: 12 }}>
            <Note tone="warn">
              <b>Atenção:</b> se o e-mail já tiver conta, a senha dela é <b>redefinida</b>. Para quem comprou, deixe o próprio cliente criar a senha pelo fluxo de compra, sem compartilhar senha.
            </Note>
          </div>
        </div>
      )}

      {rows.length === 0 ? (
        <Empty icon={<Users />}>Nenhum usuário encontrado.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <thead>
              <tr>
                <th>Nome</th><th>E-mail</th><th>Status</th><th>Plano</th><th>Restante</th><th>Cadastro</th><th>Protocolo</th><th className="r">Ações</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((u) => {
                const sub = u.subscription;
                const active = sub?.status === "active";
                const plan = sub?.plan || "monthly";
                return (
                  <tr key={u.user_id}>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 7, flexWrap: "wrap" }}>
                        <span>{u.display_name || "—"}</span>
                        {u.is_owner ? <Pill tone="silver">Dono</Pill> : u.is_admin ? <Pill plain>Admin</Pill> : null}
                      </div>
                    </td>
                    <td className="mut">{u.email}</td>
                    <td><Pill tone={active ? "ok" : "bad"}>{active ? "Ativo" : "Sem acesso"}</Pill></td>
                    <td>
                      <select
                        className="au-select ad-select-sm"
                        value={plan}
                        disabled={working === u.user_id + "set_plan"}
                        onChange={(e) => run(u.user_id + "set_plan", () => adminApi.act("set_plan", { user_id: u.user_id, plan: e.target.value }))}
                        aria-label={`Plano de ${u.email}`}
                      >
                        {Object.entries(PLAN_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                      </select>
                    </td>
                    <td className="mut">{calcRemaining(sub)}</td>
                    <td className="mut">{fmtDate(u.created_at)}</td>
                    <td>
                      <Switch
                        on={!!u.is_protocolo}
                        label={`Protocolo de ${u.email}`}
                        disabled={working === u.user_id + "set_protocolo"}
                        onChange={(v) => run(u.user_id + "set_protocolo", () => adminApi.act("set_protocolo", { user_id: u.user_id, is_protocolo: v }))}
                      />
                    </td>
                    <td className="r">
                      {active ? (
                        <Btn sm busy={working === u.user_id + "deactivate"} onClick={() => run(u.user_id + "deactivate", () => adminApi.act("deactivate", { user_id: u.user_id }))}>Revogar</Btn>
                      ) : (
                        <Btn sm variant="primary" busy={working === u.user_id + "activate"} onClick={() => run(u.user_id + "activate", () => adminApi.act("activate", { user_id: u.user_id, plan }))}>Liberar acesso</Btn>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <Note>
        Liberar e revogar não cancelam cobrança no provedor de pagamento. Depois de qualquer alteração, confira o status na tabela: o aviso de sucesso não é a prova da gravação.
      </Note>
    </Panel>
  );
};

/* ============================ Pendentes ============================ */
export const PendingPanel = ({ pendings, reload, busy }: { pendings: PendingPayment[]; reload: () => void; busy?: boolean }) => {
  const [q, setQ] = useState("");
  const rows = useMemo(
    () => pendings.slice(0, 50).filter((p) => !q.trim() || p.email.toLowerCase().includes(q.trim().toLowerCase())),
    [pendings, q],
  );
  return (
    <Panel
      title="Pagamentos pendentes"
      icon={<Clock />}
      sub="Os 50 registros mais recentes. É uma lista de acompanhamento: aqui não dá para aprovar, editar, excluir ou reenviar."
      tools={<><SearchBox value={q} onChange={setQ} placeholder="Buscar por e-mail" /><RefreshBtn onClick={reload} busy={busy} /></>}
    >
      {rows.length === 0 ? (
        <Empty icon={<Clock />}>Nenhum pagamento pendente.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <thead><tr><th>E-mail</th><th>Situação</th><th>Plano</th><th>Provedor</th><th>Transação</th><th>Criado</th><th>Atualizado</th></tr></thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id}>
                  <td>{p.email}</td>
                  <td><Pill tone={p.status === "active" ? "warn" : "ok"}>{p.status === "active" ? "Aguardando cadastro" : "Ativado"}</Pill></td>
                  <td className="mut">{p.plan || "—"}</td>
                  <td className="mut">{p.payment_provider || "—"}</td>
                  <td className="mono">{p.transaction_id || "—"}</td>
                  <td className="mut">{fmtDate(p.created_at)}</td>
                  <td className="mut">{fmtDate(p.updated_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note>Um registro pendente não significa conta pronta: o acesso só é liberado depois que o servidor vincula o pagamento a uma conta.</Note>
    </Panel>
  );
};

/* ============================ Protocolo ============================ */
export const ProtocoloAdminPanel = ({ users, reload, busy }: UsersProps) => {
  const [q, setQ] = useState("");
  const [working, setWorking] = useState<string | null>(null);
  const rows = useMemo(() => users.filter((u) => matchUser(u, q)), [users, q]);
  const marked = users.filter((u) => u.is_protocolo).length;

  const toggle = async (u: AdminUser, v: boolean) => {
    setWorking(u.user_id);
    try {
      await adminApi.act("set_protocolo", { user_id: u.user_id, is_protocolo: v });
      toast.success(v ? "Conta marcada como Protocolo" : "Protocolo removido");
      await reload();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setWorking(null);
    }
  };

  return (
    <Panel
      title="Protocolo"
      icon={<ShieldCheck />}
      sub={`${marked} conta${marked === 1 ? "" : "s"} marcada${marked === 1 ? "" : "s"}. Protocolo é uma classificação da conta, não um plano de cobrança.`}
      tools={<><SearchBox value={q} onChange={setQ} placeholder="Buscar conta" /><RefreshBtn onClick={() => reload()} busy={busy} /></>}
    >
      <Note>
        Ao ligar o interruptor, o servidor só grava a marca <b>is_protocolo</b> no perfil. As demonstrações acontecem do lado do usuário e todo valor mostrado ali é fictício, nunca venda real. Contas Protocolo não veem o banner nem o aviso do sorteio.
      </Note>
      {rows.length === 0 ? (
        <Empty icon={<ShieldCheck />}>Nenhuma conta encontrada.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <thead><tr><th>Conta</th><th>E-mail</th><th>Plano</th><th className="r">Protocolo</th></tr></thead>
            <tbody>
              {rows.map((u) => (
                <tr key={u.user_id}>
                  <td>{u.display_name || "—"}</td>
                  <td className="mut">{u.email}</td>
                  <td className="mut">{u.subscription?.status === "active" ? PLAN_LABELS[u.subscription.plan || "monthly"] || u.subscription.plan : "Sem acesso"}</td>
                  <td className="r">
                    <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
                      {u.is_protocolo && <Pill tone="silver">Protocolo</Pill>}
                      <Switch on={!!u.is_protocolo} disabled={working === u.user_id} label={`Protocolo de ${u.email}`} onChange={(v) => toggle(u, v)} />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Panel>
  );
};

/* ============================ Admins (dono) ============================ */
export const AdminsPanel = ({ users, reload: reloadUsers }: UsersProps) => {
  const [admins, setAdmins] = useState<AdminRecord[] | null>(null);
  const [err, setErr] = useState("");
  const [pick, setPick] = useState("");
  const [working, setWorking] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    setErr("");
    try { setAdmins(await adminApi.admins()); } catch (e) { setErr(errMsg(e)); setAdmins([]); } finally { setLoading(false); }
  };
  useEffect(() => { void load(); }, []);

  const adminIds = new Set((admins || []).map((a) => a.user_id));
  const eligible = users.filter((u) => !adminIds.has(u.user_id));

  const set = async (user_id: string, is_admin: boolean) => {
    setWorking(user_id);
    try {
      await adminApi.act("set_admin", { user_id, is_admin });
      toast.success(is_admin ? "Administração concedida" : "Administração removida");
      setPick("");
      await Promise.all([load(), reloadUsers()]);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setWorking(null);
    }
  };

  return (
    <Panel
      title="Administradores"
      icon={<Crown />}
      sub="Somente o dono vê e altera esta lista. A permissão é validada no servidor a cada ação."
      tools={<RefreshBtn onClick={load} busy={loading} />}
    >
      {err && <Note tone="bad">{err}</Note>}
      <div className="ad-box">
        <div className="ad-form">
          <Field label="Conceder administração a" hint="Só aparecem contas que ainda não são admin.">
            <select className="au-select ad-in" value={pick} onChange={(e) => setPick(e.target.value)}>
              <option value="">Escolha uma conta…</option>
              {eligible.map((u) => <option key={u.user_id} value={u.user_id}>{u.email}</option>)}
            </select>
          </Field>
          <Btn variant="primary" disabled={!pick} busy={working === pick} onClick={() => set(pick, true)}><Shield />Conceder admin</Btn>
        </div>
      </div>
      {!admins ? null : admins.length === 0 ? (
        <Empty icon={<Crown />}>Nenhum administrador encontrado.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <thead><tr><th>E-mail</th><th>Papel</th><th className="r">Ações</th></tr></thead>
            <tbody>
              {admins.map((a) => (
                <tr key={a.user_id}>
                  <td>{a.email}</td>
                  <td>{a.is_owner ? <Pill tone="silver">Dono</Pill> : <Pill plain>Admin</Pill>}</td>
                  <td className="r">
                    {a.is_owner ? <span className="mut" style={{ fontSize: 12, color: "var(--au-text-3)" }}>Não removível aqui</span> : (
                      <ConfirmBtn busy={working === a.user_id} confirmLabel="Remover admin" onConfirm={() => set(a.user_id, false)}>Remover</ConfirmBtn>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note>Não há transferência de propriedade por esta tela. Depois de conceder ou remover, confira a lista recarregada.</Note>
    </Panel>
  );
};
