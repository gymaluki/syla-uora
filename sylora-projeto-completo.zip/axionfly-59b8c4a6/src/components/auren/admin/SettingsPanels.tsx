import { Fragment, useEffect, useRef, useState } from "react";
import { Bug, Cloud, DollarSign, Film, Globe, Search as SearchIcon, ShieldCheck, Sparkles, TrendingUp, Upload, Zap, Code2, Check } from "lucide-react";
import { toast } from "sonner";
import { adminApi } from "@/lib/adminData";
import { fmtDate, type AdminUser, type SystemError } from "@/lib/adminTypes";
import { Btn, ConfirmBtn, Empty, Loading, Note, Panel, Pill, RefreshBtn, SearchBox, Switch, errMsg } from "./ui";
import { useLoad } from "./useLoad";

/* ============================ Landing Page (vídeos) ============================ */
const SLOTS = [
  { id: "desktop", key: "demo_video_desktop_url", label: "Vídeo do computador", tall: false },
  { id: "mobile", key: "demo_video_mobile_url", label: "Vídeo do celular", tall: true },
  { id: "testimonial", key: "demo_video_testimonial_url", label: "Vídeo de depoimento", tall: false },
] as const;

const Slot = ({ slot, saved, onSaved }: { slot: (typeof SLOTS)[number]; saved: string; onSaved: () => void }) => {
  const [url, setUrl] = useState(saved);
  const [preview, setPreview] = useState(saved);
  const [busy, setBusy] = useState<"" | "up" | "save">("");
  const [over, setOver] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { setUrl(saved); setPreview(saved); }, [saved]);

  const save = async (value = url) => {
    setBusy("save");
    try {
      await adminApi.saveSettings({ [slot.key]: value.trim() });
      toast.success("Vídeo salvo");
      onSaved();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy("");
    }
  };

  const upload = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("video/")) return toast.error("Escolha um arquivo de vídeo.");
    setBusy("up");
    try {
      const r = await adminApi.uploadVideo(file, slot.id);
      setPreview(r.url);
      setUrl(r.path);
      await adminApi.saveSettings({ [slot.key]: r.path });
      toast.success("Vídeo enviado e salvo");
      onSaved();
    } catch (e) {
      toast.error("Erro no envio: " + errMsg(e));
    } finally {
      setBusy("");
    }
  };

  return (
    <div className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <p className="ad-title" style={{ fontSize: 13 }}><Film />{slot.label}</p>
      {preview ? <video className={"ad-video" + (slot.tall ? " tall" : "")} src={preview} controls preload="metadata" /> : <div className={"ad-video" + (slot.tall ? " tall" : "")} style={{ display: "grid", placeItems: "center", color: "var(--au-text-3)", fontSize: 12 }}>Sem vídeo</div>}
      <input className="au-input ad-in" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Cole a URL do vídeo" />
      <div className="ad-tools">
        <Btn variant="primary" sm busy={busy === "save"} onClick={() => save()}>Salvar</Btn>
      </div>
      <div
        className={"ad-drop" + (over ? " over" : "")}
        onClick={() => input.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); void upload(e.dataTransfer.files?.[0]); }}
        role="button" tabIndex={0}
        onKeyDown={(e) => { if (e.key === "Enter") input.current?.click(); }}
      >
        <Upload style={{ width: 16, height: 16, margin: "0 auto 6px", display: "block" }} />
        {busy === "up" ? "Enviando…" : "Selecione ou arraste um vídeo"}
      </div>
      <input ref={input} type="file" accept="video/*" hidden onChange={(e) => { void upload(e.target.files?.[0]); e.target.value = ""; }} />
    </div>
  );
};

export const LandingPanel = () => {
  const keys = SLOTS.map((s) => s.key);
  const { data, loading, error, reload } = useLoad(() => adminApi.getSettings(keys), {} as Record<string, string>);
  return (
    <Panel
      title="Landing Page"
      icon={<Film />}
      sub="Os três vídeos de demonstração da página de vendas. Aqui só vídeos: texto, preço e layout não se editam por esta aba."
      tools={<RefreshBtn onClick={reload} busy={loading} />}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && Object.keys(data).length === 0 && !error ? <Loading /> : (
        <div className="ad-grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
          {SLOTS.map((s) => <Slot key={s.id} slot={s} saved={data[s.key] ?? ""} onSaved={reload} />)}
        </div>
      )}
      <Note tone="warn">
        Enviar um arquivo grava o link público dele na configuração. Colar um link assinado (que expira) salva um link temporário. Não há versões nem remoção do arquivo anterior, e enviar + salvar não é uma operação única.
      </Note>
    </Panel>
  );
};

/* ============================ Aviso Domínio ============================ */
export const DomainPanel = () => {
  const { data, loading, error, reload } = useLoad(() => adminApi.getSettings(["domain_notice_enabled"]), {} as Record<string, string>);
  const [on, setOn] = useState(false);
  const [saving, setSaving] = useState(false);
  useEffect(() => { setOn(data.domain_notice_enabled === "true"); }, [data]);

  const toggle = async (v: boolean) => {
    const prev = on;
    setOn(v);
    setSaving(true);
    try {
      await adminApi.saveSettings({ domain_notice_enabled: String(v) });
      toast.success(v ? "Aviso ativado" : "Aviso desativado");
      await reload();
    } catch (e) {
      setOn(prev);
      toast.error("Não foi possível salvar: " + errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Panel title="Aviso Domínio" icon={<Globe />} sub="Liga ou desliga o aviso de domínio dentro da aplicação." tools={<RefreshBtn onClick={reload} busy={loading} />}>
      {error && <Note tone="bad">{error}</Note>}
      <div className="ad-box">
        <div className="ad-row">
          <div>
            <div className="t">Mostrar aviso de domínio</div>
            <div className="d">{on ? "O aviso aparece para os usuários." : "O aviso está desligado (padrão)."}</div>
          </div>
          <Switch on={on} onChange={toggle} disabled={saving || loading} label="Mostrar aviso de domínio" />
        </div>
      </div>
      <Note>Alternar salva na hora. Esta aba não altera DNS, hospedagem nem o domínio publicado, e não edita texto, destino ou calendário do aviso.</Note>
    </Panel>
  );
};

/* ============================ Cloud (dono) ============================ */
export const CloudPanel = ({ users }: { users: AdminUser[] }) => {
  const active = users.filter((u) => u.subscription?.status === "active").length;
  const conv = users.length ? ((active / users.length) * 100).toFixed(1) : "0";
  return (
    <Panel title="Financeiro Cloud" icon={<Cloud />} sub="Visão do dono sobre custos de infraestrutura.">
      <Note tone="warn">Os valores desta aba são <b>estimativas fixas</b> escritas na tela. Ela não consulta saldo, fatura ou custos reais do Lovable Cloud.</Note>
      <div className="ad-grid">
        <div className="ad-kpi">
          <div className="k"><Cloud />Saldo mensal grátis</div>
          <div className="v">US$ 25,00</div>
          <div className="s">Franquia padrão do Lovable Cloud</div>
          <div className="ad-bar thin" style={{ marginTop: 12 }}><i style={{ width: "8%" }} /></div>
          <div className="s" style={{ marginTop: 8 }}>~US$ 2,00 utilizados</div>
        </div>
        <div className="ad-kpi">
          <div className="k"><TrendingUp />Conversão de vendas</div>
          <div className="v">{conv}%</div>
          <div className="s">Cadastros vs assinaturas ativas (contas carregadas)</div>
        </div>
        <div className="ad-kpi">
          <div className="k"><DollarSign />Custo por lead</div>
          <div className="v">R$ 0,00</div>
          <div className="s">Estimativa de custo de infra por usuário</div>
        </div>
      </div>
      <div className="ad-box">
        <p className="ad-title" style={{ fontSize: 14 }}>Detalhamento de estimativas de gasto</p>
        <div className="ad-rows" style={{ marginTop: 14 }}>
          {[
            ["Banco de dados (Postgres)", "Instância padrão P-1 (AWS eu-west-1)", "GRÁTIS", "No seu plano"],
            ["Armazenamento (Storage)", "Bucket: /videos (hospedagem de aulas)", "~US$ 0,15", "Estimado/mês"],
            ["Webhooks de pagamento", "Cakto e PerfectPay (processamento de vendas)", "~US$ 1,20", "Estimado/mês"],
          ].map(([t, d, v, s]) => (
            <div key={t} className="ad-row">
              <div><div className="t">{t}</div><div className="d">{d}</div></div>
              <div style={{ textAlign: "right" }}><div className="t" style={{ color: v === "GRÁTIS" ? "#6EE7B7" : undefined }}>{v}</div><div className="d">{s}</div></div>
            </div>
          ))}
        </div>
      </div>
      <div className="ad-box">
        <p className="ad-title" style={{ fontSize: 14 }}><Sparkles />Agentes de IA integrados</p>
        <div className="ad-grid" style={{ marginTop: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
          {([[Code2, "Criador de Sites (Lovable)"], [SearchIcon, "Prospecção (Firecrawl API)"], [ShieldCheck, "Gestor de Acesso (Auto-Admin)"], [Zap, "Extensão Infinito (Hyperbuild)"]] as const).map(([I, t]) => (
            <div key={t} className="ad-note" style={{ alignItems: "center" }}><I /><span style={{ color: "var(--au-text)" }}>{t}</span></div>
          ))}
        </div>
      </div>
      <Note>
        <b>Instância P-1:</b> é a menor, com custo fixo zero no bônus. <b>Webhooks:</b> Pix gerado e não pago não consome saldo; o processamento acontece só na aprovação.
      </Note>
    </Panel>
  );
};

/* ============================ Sistema (dono) ============================ */
const levelTone = (l: string) => (l === "error" || l === "fatal" ? "bad" : l === "warn" || l === "warning" ? "warn" : undefined);

export const SystemPanel = () => {
  const { data: errs, loading, error, reload } = useLoad(() => adminApi.systemErrors(100), [] as SystemError[]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [live, setLive] = useState(false);

  useEffect(() => {
    setLive(true);
    const off = adminApi.onErrorsChange(() => { void reload(); });
    return () => { setLive(false); off(); };
  }, [reload]);

  const s = q.trim().toLowerCase();
  const rows = errs.filter((e) => !s || e.message.toLowerCase().includes(s) || (e.source || "").toLowerCase().includes(s) || (e.user_email || "").toLowerCase().includes(s));
  const openCount = errs.filter((e) => !e.resolved).length;

  const resolve = async (id: string) => {
    try { await adminApi.resolveError(id); toast.success("Marcado como resolvido"); await reload(); } catch (e) { toast.error(errMsg(e)); }
  };
  const del = async (id: string) => {
    try { await adminApi.deleteError(id); toast.success("Registro excluído"); await reload(); } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <Panel
      title="Sistema"
      icon={<Bug />}
      sub={`${openCount} erro${openCount === 1 ? "" : "s"} em aberto entre os 100 mais recentes.`}
      tools={<>{live && <Pill tone="ok">Ao vivo</Pill>}<SearchBox value={q} onChange={setQ} placeholder="Buscar mensagem, origem ou e-mail" /><RefreshBtn onClick={reload} busy={loading} /></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && errs.length === 0 ? <Loading /> : rows.length === 0 ? (
        <Empty icon={<Check />}>Nenhum erro registrado.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table" style={{ minWidth: 760 }}>
            <thead><tr><th>Nível</th><th>Mensagem</th><th>Origem</th><th>Data</th><th>Situação</th><th className="r">Ações</th></tr></thead>
            <tbody>
              {rows.map((e) => (
                <Fragment key={e.id}>
                  <tr style={{ cursor: "pointer" }} onClick={() => setOpen(open === e.id ? null : e.id)}>
                    <td><Pill tone={levelTone(e.level)} plain={!levelTone(e.level)}>{e.level}</Pill></td>
                    <td className="clip" title={e.message} style={{ maxWidth: 360 }}>{e.message}</td>
                    <td className="mut">{e.source || e.url || "—"}</td>
                    <td className="mut" style={{ whiteSpace: "nowrap" }}>{fmtDate(e.created_at)}</td>
                    <td>{e.resolved ? <Pill tone="ok">Resolvido</Pill> : <Pill tone="warn">Aberto</Pill>}</td>
                    <td className="r" onClick={(ev) => ev.stopPropagation()}>
                      <span style={{ display: "inline-flex", gap: 8, justifyContent: "flex-end" }}>
                        {!e.resolved && <Btn sm onClick={() => resolve(e.id)}>Resolver</Btn>}
                        <ConfirmBtn confirmLabel="Excluir" onConfirm={() => del(e.id)}>Excluir</ConfirmBtn>
                      </span>
                    </td>
                  </tr>
                  {open === e.id && (
                    <tr><td colSpan={6} style={{ background: "rgba(255,255,255,.02)" }}>
                      <div className="mut" style={{ whiteSpace: "pre-wrap", fontFamily: "var(--au-font-mono)", fontSize: 11, lineHeight: 1.6 }}>
                        {e.message}{e.user_email ? `\nUsuário: ${e.user_email}` : ""}{e.url ? `\nURL: ${e.url}` : ""}{e.stack ? `\n\n${e.stack}` : ""}
                      </div>
                    </td></tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note>Resolver não corrige a origem do problema e excluir apaga o registro de vez. “Ao vivo” só indica que a escuta de mudanças está ligada, não a saúde geral do sistema.</Note>
    </Panel>
  );
};
