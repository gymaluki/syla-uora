import { useState, type ReactNode } from "react";
import { AlertTriangle, Check, Copy, Info, Loader2, RefreshCw, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import "./admin.css";

export const Panel = ({
  title, icon, sub, tools, children, className,
}: { title: ReactNode; icon?: ReactNode; sub?: ReactNode; tools?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={cn("au-card ad-panel", className)}>
    <header className="ad-head">
      <div>
        <h3 className="ad-title">{icon}{title}</h3>
        {sub && <p className="ad-sub">{sub}</p>}
      </div>
      {tools && <div className="ad-tools">{tools}</div>}
    </header>
    <div className="ad-body">{children}</div>
  </section>
);

export const SearchBox = ({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) => (
  <div className="ad-search">
    <Search />
    <input className="au-input ad-in" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} aria-label={placeholder} />
  </div>
);

export const Btn = ({
  children, onClick, variant = "ghost", busy, disabled, sm, title, type = "button",
}: {
  children: ReactNode; onClick?: () => void; variant?: "ghost" | "primary" | "danger"; busy?: boolean;
  disabled?: boolean; sm?: boolean; title?: string; type?: "button" | "submit";
}) => (
  <button
    type={type}
    title={title}
    onClick={onClick}
    disabled={disabled || busy}
    className={cn("au-btn ad-btn", `au-btn-${variant}`, sm && "sm", busy && "spin")}
  >
    {busy ? <Loader2 style={{ animation: "ad-spin 1s linear infinite" }} /> : null}
    {children}
  </button>
);

export const RefreshBtn = ({ onClick, busy }: { onClick: () => void; busy?: boolean }) => (
  <button type="button" className="au-icon-btn" onClick={onClick} disabled={busy} title="Atualizar" aria-label="Atualizar">
    <RefreshCw style={busy ? { animation: "ad-spin 1s linear infinite" } : undefined} />
  </button>
);

export const Pill = ({ tone, children, plain }: { tone?: "ok" | "bad" | "warn" | "silver"; children: ReactNode; plain?: boolean }) => (
  <span className={cn("ad-pill", tone, plain && "plain")}>{children}</span>
);

export const Switch = ({ on, onChange, disabled, label }: { on: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string }) => (
  <button
    type="button"
    role="switch"
    aria-checked={on}
    aria-label={label}
    disabled={disabled}
    onClick={() => onChange(!on)}
    className={cn("au-switch", on && "on")}
    style={disabled ? { opacity: 0.5, cursor: "wait" } : { cursor: "pointer" }}
  />
);

export const Note = ({ tone, children }: { tone?: "warn" | "bad"; children: ReactNode }) => (
  <div className={cn("ad-note", tone)}>
    {tone ? <AlertTriangle /> : <Info />}
    <div>{children}</div>
  </div>
);

export const Empty = ({ icon, children }: { icon?: ReactNode; children: ReactNode }) => (
  <div className="ad-empty">{icon}{children}</div>
);

export const Loading = () => (
  <div className="ad-loading"><div className="ad-pulse"><i /></div></div>
);

export const Field = ({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) => (
  <div className="ad-field">
    <label>{label}</label>
    {children}
    {hint && <p className="hint">{hint}</p>}
  </div>
);

export const CopyBtn = ({ text, label = "Copiar" }: { text: string; label?: string }) => {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="au-icon-btn"
      title={label}
      aria-label={label}
      onClick={async () => {
        try { await navigator.clipboard.writeText(text); } catch { /* sem permissão de área de transferência */ }
        setDone(true);
        setTimeout(() => setDone(false), 1400);
        toast.success("Copiado");
      }}
    >
      {done ? <Check /> : <Copy />}
    </button>
  );
};

/** Botão que pede uma segunda confirmação antes de agir (ações destrutivas). */
export const ConfirmBtn = ({
  children, onConfirm, confirmLabel = "Confirmar", sm = true, busy,
}: { children: ReactNode; onConfirm: () => void; confirmLabel?: string; sm?: boolean; busy?: boolean }) => {
  const [ask, setAsk] = useState(false);
  if (!ask) return <Btn variant="danger" sm={sm} onClick={() => setAsk(true)}>{children}</Btn>;
  return (
    <span className="ad-confirm">
      <Btn variant="danger" sm={sm} busy={busy} onClick={() => { setAsk(false); onConfirm(); }}>{confirmLabel}</Btn>
      <button type="button" className="au-icon-btn" aria-label="Cancelar" onClick={() => setAsk(false)}><X /></button>
    </span>
  );
};

export const errMsg = (e: unknown) => (e instanceof Error ? e.message : typeof e === "object" && e && "message" in e ? String((e as { message: unknown }).message) : "Erro inesperado");

/** Neutraliza fórmulas de planilha (=, +, -, @) e escapa aspas ao montar CSV. */
export const csvCell = (v: unknown) => {
  let s = v == null ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
};
