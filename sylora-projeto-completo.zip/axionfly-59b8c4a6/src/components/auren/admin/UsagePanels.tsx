import { useMemo, useState } from "react";
import { Activity, BarChart3, ChevronDown, Download, MessageSquare } from "lucide-react";
import { adminApi } from "@/lib/adminData";
import { PLAN_LABELS, fmtDate, type MentorLog, type UsageRow } from "@/lib/adminTypes";
import { Btn, Empty, Loading, Note, Panel, Pill, RefreshBtn, SearchBox, csvCell } from "./ui";
import { useLoad } from "./useLoad";

/* ============================ Prova de uso ============================ */
export const UsagePanel = () => {
  const { data: rows, loading, error, reload } = useLoad(() => adminApi.usageReport(), [] as UsageRow[]);
  const [q, setQ] = useState("");
  const [onlyActive, setOnlyActive] = useState(false);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (onlyActive && !(r.total_acoes > 0)) return false;
      return !s || r.email?.toLowerCase().includes(s) || r.display_name?.toLowerCase().includes(s) || r.user_id.toLowerCase().includes(s);
    });
  }, [rows, q, onlyActive]);
  const shown = filtered.slice(0, 500);

  const exportCsv = () => {
    const head = ["email", "nome", "plano", "situacao", "cadastro", "ultimo_login", "mentor", "prospeccao", "aulas", "sites", "vendas", "licencas", "total_acoes", "ultima_atividade"];
    const lines = filtered.map((r) =>
      [r.email, r.display_name, r.plan, r.status, r.created_at, r.last_sign_in_at, r.mentor, r.prospeccao, r.aulas, r.sites, r.vendas, r.licencas, r.total_acoes, r.ultima_atividade].map(csvCell).join(","),
    );
    const blob = new Blob(["﻿" + [head.join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `prova-de-uso-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };

  return (
    <Panel
      title="Prova de uso"
      icon={<Activity />}
      sub="Quanto cada conta usou as ferramentas: Mentor, prospecção, aulas, sites, vendas e licenças."
      tools={
        <>
          <SearchBox value={q} onChange={setQ} placeholder="Buscar nome, e-mail ou ID" />
          <button type="button" className={"au-chip" + (onlyActive ? " on" : "")} onClick={() => setOnlyActive((v) => !v)} style={{ height: 36 }}>Somente ativos</button>
          <Btn onClick={exportCsv} disabled={filtered.length === 0}><Download />Exportar CSV</Btn>
          <RefreshBtn onClick={reload} busy={loading} />
        </>
      }
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && rows.length === 0 ? <Loading /> : shown.length === 0 ? (
        <Empty icon={<Activity />}>Nenhuma conta encontrada.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table" style={{ minWidth: 980 }}>
            <thead>
              <tr><th>Conta</th><th>Plano</th><th>Cadastro</th><th>Último login</th><th className="num">Mentor</th><th className="num">Busca</th><th className="num">Aulas</th><th className="num">Sites</th><th className="num">Vendas</th><th className="num">Lic.</th><th className="num">Total</th><th>Última atividade</th></tr>
            </thead>
            <tbody>
              {shown.map((r) => (
                <tr key={r.user_id}>
                  <td><div>{r.display_name || "—"}</div><div className="mut">{r.email}</div></td>
                  <td>{r.status === "active" ? <Pill tone="ok">{PLAN_LABELS[r.plan || "monthly"]?.split(" ")[0] || r.plan}</Pill> : <Pill tone="bad">Sem acesso</Pill>}</td>
                  <td className="mut">{fmtDate(r.created_at)}</td>
                  <td className="mut">{fmtDate(r.last_sign_in_at)}</td>
                  <td className="num">{r.mentor}</td><td className="num">{r.prospeccao}</td><td className="num">{r.aulas}</td>
                  <td className="num">{r.sites}</td><td className="num">{r.vendas}</td><td className="num">{r.licencas}</td>
                  <td className="num"><b>{r.total_acoes}</b></td>
                  <td className="mut">{fmtDate(r.ultima_atividade)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note>
        “Somente ativos” significa <b>total de ações maior que zero</b>, não assinatura ativa. A tela mostra até 500 linhas e o servidor lê até 1.000 contas por página. A contagem de aulas é de registros de progresso. O CSV pode ter IDs e chaves: guarde com cuidado.
      </Note>
    </Panel>
  );
};

/* ============================ Mentor IA ============================ */
export const MentorLogsPanel = () => {
  const { data: logs, loading, error, reload } = useLoad(() => adminApi.mentorLogs(100), [] as MentorLog[]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const s = q.trim().toLowerCase();
  const rows = logs.filter((l) => !s || (l.user_email || "").toLowerCase().includes(s) || l.question.toLowerCase().includes(s) || (l.response || "").toLowerCase().includes(s));

  return (
    <Panel
      title="Mentor IA"
      icon={<MessageSquare />}
      sub="As 100 interações mais recentes. Só consulta: não há edição de respostas, limpeza de cache nem paginação."
      tools={<><SearchBox value={q} onChange={setQ} placeholder="Buscar e-mail, pergunta ou resposta" /><RefreshBtn onClick={reload} busy={loading} /></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && logs.length === 0 ? <Loading /> : rows.length === 0 ? (
        <Empty icon={<MessageSquare />}>Nenhuma interação encontrada.</Empty>
      ) : (
        <div>
          {rows.map((l) => (
            <div key={l.id} className={"ad-qa" + (open === l.id ? " open" : "")}>
              <button type="button" onClick={() => setOpen(open === l.id ? null : l.id)} aria-expanded={open === l.id}>
                <div style={{ minWidth: 0 }}>
                  <div className="q">{l.question}</div>
                  <div className="m">{l.user_email || "Anônimo"} · {fmtDate(l.created_at)}{l.source ? ` · ${l.source}` : ""}</div>
                </div>
                <span style={{ display: "inline-flex", gap: 10, alignItems: "center" }}>
                  {l.cached && <Pill plain>Cache</Pill>}
                  <ChevronDown className="chev" />
                </span>
              </button>
              {open === l.id && <div className="a">{l.response || "Sem resposta registrada."}</div>}
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
};

/* ============================ Dúvidas TOP ============================ */
const STOP = new Set(("a o as os um uma uns umas de do da dos das em no na nos nas por para pra com sem sobre entre e ou mas que se como qual quais quando onde quem eu me meu minha meus minhas voce você vc seu sua seus suas ele ela eles elas isso isto esse essa esses essas aquele aquela ao aos à às é são ser ter tem tenho fazer faço posso pode podem preciso quero queria gostaria muito mais menos já ja não nao sim só so também tambem então entao ainda favor ajuda ajudar me dá da dar dizer qual-é").split(" "));
const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9\s]/g, " ");
const stem = (w: string) => (w.length > 4 && w.endsWith("s") ? w.slice(0, -1) : w);
const STOP_N = new Set([...STOP].map((w) => norm(w).trim()));

interface Group { key: string; count: number; examples: string[] }

export const TopQuestionsPanel = () => {
  const { data: logs, loading, error, reload } = useLoad(() => adminApi.mentorLogs(1000), [] as MentorLog[]);

  const groups = useMemo<Group[]>(() => {
    const m = new Map<string, Group>();
    logs.forEach((l) => {
      const terms = [...new Set(norm(l.question).split(/\s+/).filter((w) => w.length > 2 && !STOP_N.has(w)).map(stem))];
      if (terms.length === 0) return;
      const key = terms.sort().slice(0, 3).join(" ");
      const g = m.get(key) || { key, count: 0, examples: [] };
      g.count++;
      if (g.examples.length < 2 && !g.examples.includes(l.question)) g.examples.push(l.question);
      m.set(key, g);
    });
    return [...m.values()].sort((a, b) => b.count - a.count).slice(0, 50);
  }, [logs]);
  const max = groups[0]?.count || 1;

  return (
    <Panel
      title="Dúvidas TOP"
      icon={<BarChart3 />}
      sub="As perguntas mais repetidas ao Mentor IA, agrupadas pelas palavras em comum (até 1.000 perguntas, 50 grupos)."
      tools={<RefreshBtn onClick={reload} busy={loading} />}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && logs.length === 0 ? <Loading /> : groups.length === 0 ? (
        <Empty icon={<BarChart3 />}>Ainda não há perguntas para agrupar.</Empty>
      ) : (
        <div className="ad-rows">
          {groups.map((g, i) => (
            <div key={g.key}>
              <div className="ad-row" style={{ alignItems: "flex-start" }}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div className="t"><span className="mono" style={{ color: "var(--au-text-3)", marginRight: 10, fontFamily: "var(--au-font-mono)", fontSize: 11 }}>{String(i + 1).padStart(2, "0")}</span>{g.key}</div>
                  {g.examples.map((e) => <div key={e} className="d" style={{ fontStyle: "italic" }}>“{e}”</div>)}
                  <div className="ad-bar thin" style={{ marginTop: 10, maxWidth: 360 }}><i style={{ width: `${(g.count / max) * 100}%` }} /></div>
                </div>
                <Pill plain>{g.count}×</Pill>
              </div>
            </div>
          ))}
        </div>
      )}
      <Note>É uma heurística por palavras (sem acentos, sem plural simples, até três termos), não uma classificação por IA: perguntas equivalentes podem ficar separadas e perguntas diferentes podem se juntar.</Note>
    </Panel>
  );
};
