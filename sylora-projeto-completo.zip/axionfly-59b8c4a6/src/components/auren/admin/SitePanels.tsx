import { useEffect, useState } from "react";
import { Bell, ExternalLink, Link2, RotateCcw, Type } from "lucide-react";
import { toast } from "sonner";
import { adminApi } from "@/lib/adminData";
import { CHECKOUT_KEYS, SITE_FIELDS, isCheckoutUrlOk } from "@/lib/siteContent";
import { Btn, Field, Loading, Note, Panel, RefreshBtn, Switch, errMsg } from "./ui";
import { useLoad } from "./useLoad";

/** Edita uma lista de chaves de site_settings; vazio = volta ao padrão. */
const useDrafts = (keys: string[]) => {
  const { data, loading, error, reload } = useLoad(() => adminApi.getSettings(keys), {} as Record<string, string>);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  useEffect(() => { setDraft(data); }, [data]);
  const dirty = keys.some((k) => (draft[k] ?? "") !== (data[k] ?? ""));
  const save = async (extra?: (d: Record<string, string>) => string | null) => {
    const bad = extra?.(draft);
    if (bad) { toast.error(bad); return false; }
    setSaving(true);
    try {
      const values: Record<string, string> = {};
      keys.forEach((k) => { values[k] = (draft[k] ?? "").trim(); });
      await adminApi.saveSettings(values);
      toast.success("Salvo");
      await reload();
      return true;
    } catch (e) {
      toast.error("Não foi possível salvar: " + errMsg(e));
      return false;
    } finally {
      setSaving(false);
    }
  };
  return { draft, setDraft, data, loading, error, reload, dirty, saving, save };
};

/* ============================ Textos do site ============================ */
export const SiteTextPanel = () => {
  const keys = SITE_FIELDS.map((f) => f.key);
  const { draft, setDraft, loading, error, reload, dirty, saving, save, data } = useDrafts(keys);
  const groups = Array.from(new Set(SITE_FIELDS.map((f) => f.group)));
  return (
    <Panel
      title="Textos do site"
      icon={<Type />}
      sub="Troque a faixa, o título, os botões e os textos das seções da landing sem pedir para ninguém. Campo vazio volta ao texto padrão."
      tools={<><RefreshBtn onClick={reload} busy={loading} /><Btn variant="primary" sm busy={saving} disabled={!dirty} onClick={() => void save()}>Salvar alterações</Btn></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && Object.keys(data).length === 0 && !error ? <Loading /> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          {groups.map((g) => (
            <div key={g} className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <p className="ad-title" style={{ fontSize: 13 }}>{g}</p>
              {SITE_FIELDS.filter((f) => f.group === g).map((f) => (
                <Field key={f.key} label={f.label} hint={f.hint}>
                  <div style={{ display: "flex", gap: 8, alignItems: f.long ? "flex-start" : "center" }}>
                    {f.long ? (
                      <textarea className="au-input" style={{ flex: 1, minHeight: 72, padding: 12, fontSize: 13 }} value={draft[f.key] ?? ""} placeholder={f.def} onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })} />
                    ) : (
                      <input className="au-input ad-in" style={{ flex: 1 }} value={draft[f.key] ?? ""} placeholder={f.def} onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })} />
                    )}
                    <button type="button" className="au-icon-btn" title="Voltar ao padrão" aria-label="Voltar ao padrão" onClick={() => setDraft({ ...draft, [f.key]: "" })}><RotateCcw /></button>
                  </div>
                </Field>
              ))}
            </div>
          ))}
        </div>
      )}
      <Note>As mudanças aparecem para quem abrir ou recarregar a landing. Os textos dos cards de funcionalidades e dos 3 passos ainda são fixos.</Note>
    </Panel>
  );
};

/* ============================ Planos e checkout ============================ */
const PLAN_FIELDS = [
  { key: CHECKOUT_KEYS.monthly, label: "Plano Mensal — link do checkout" },
  { key: CHECKOUT_KEYS.lifetime, label: "Plano Anual — link do checkout" },
];

export const PlansPanel = () => {
  const keys = PLAN_FIELDS.map((f) => f.key);
  const { draft, setDraft, loading, error, reload, dirty, saving, save, data } = useDrafts(keys);
  const validate = (d: Record<string, string>) => {
    for (const f of PLAN_FIELDS) {
      const v = (d[f.key] ?? "").trim();
      if (v && !isCheckoutUrlOk(v)) return `${f.label}: use um link https de um checkout aceito (ApplyFy, Cakto, Kirvano, PerfectPay ou Abacate Pay).`;
    }
    return null;
  };
  return (
    <Panel
      title="Planos e checkout"
      icon={<Link2 />}
      sub="Os links para onde os botões “Assinar” levam. Vazio usa o link padrão do site."
      tools={<><RefreshBtn onClick={reload} busy={loading} /><Btn variant="primary" sm busy={saving} disabled={!dirty} onClick={() => void save(validate)}>Salvar links</Btn></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && Object.keys(data).length === 0 && !error ? <Loading /> : (
        <div className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {PLAN_FIELDS.map((f) => (
            <Field key={f.key} label={f.label}>
              <div style={{ display: "flex", gap: 8 }}>
                <input className="au-input ad-in" style={{ flex: 1 }} value={draft[f.key] ?? ""} placeholder="https://checkout.applyfy.com.br/…" onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })} />
                {isCheckoutUrlOk((draft[f.key] ?? "").trim()) && (
                  <a className="au-icon-btn" href={(draft[f.key] ?? "").trim()} target="_blank" rel="noreferrer" title="Abrir o checkout" aria-label="Abrir o checkout"><ExternalLink /></a>
                )}
              </div>
            </Field>
          ))}
        </div>
      )}
      <Note tone="warn">Quem chega por um link de afiliado continua indo para os links cadastrados do afiliado. Os dois links precisam ser de checkouts aceitos; outro endereço é recusado ao salvar.</Note>
    </Panel>
  );
};

/* ============================ Aviso aos membros ============================ */
export const NOTICE_KEYS = { on: "notice_enabled", text: "notice_text" };

export const NoticePanel = () => {
  const keys = [NOTICE_KEYS.on, NOTICE_KEYS.text];
  const { draft, setDraft, loading, error, reload, dirty, saving, save, data } = useDrafts(keys);
  const on = draft[NOTICE_KEYS.on] === "true";
  return (
    <Panel
      title="Aviso aos membros"
      icon={<Bell />}
      sub="Uma faixa no topo do app para todos os membros: novidade, manutenção, bônus, prazo."
      tools={<><RefreshBtn onClick={reload} busy={loading} /><Btn variant="primary" sm busy={saving} disabled={!dirty} onClick={() => void save((d) => (d[NOTICE_KEYS.on] === "true" && !(d[NOTICE_KEYS.text] ?? "").trim() ? "Escreva o texto do aviso antes de ligar." : null))}>Salvar aviso</Btn></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && Object.keys(data).length === 0 && !error ? <Loading /> : (
        <div className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="ad-row">
            <div>
              <div className="t">Mostrar o aviso</div>
              <div className="d">{on ? "Aparece para todos os membros logados." : "Desligado: ninguém vê."}</div>
            </div>
            <Switch on={on} onChange={(v) => setDraft({ ...draft, [NOTICE_KEYS.on]: String(v) })} label="Mostrar o aviso" />
          </div>
          <Field label="Texto do aviso" hint="Curto e direto. Cada membro pode fechar a faixa; se você mudar o texto, ela volta a aparecer para todos.">
            <textarea className="au-input" style={{ minHeight: 84, padding: 12, fontSize: 13, width: "100%" }} maxLength={280} value={draft[NOTICE_KEYS.text] ?? ""} onChange={(e) => setDraft({ ...draft, [NOTICE_KEYS.text]: e.target.value })} placeholder="Ex.: Novo módulo liberado! Confira em Recompensas." />
          </Field>
        </div>
      )}
    </Panel>
  );
};
