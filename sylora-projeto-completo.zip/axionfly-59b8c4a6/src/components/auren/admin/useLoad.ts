import { useCallback, useEffect, useRef, useState } from "react";
import { errMsg } from "./ui";

/** Carrega dados ao montar e expõe reload. Ignora respostas de uma carga que já foi substituída. */
export function useLoad<T>(fn: () => Promise<T>, initial: T) {
  const [data, setData] = useState<T>(initial);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const seq = useRef(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  const reload = useCallback(async () => {
    const id = ++seq.current;
    setLoading(true);
    setError("");
    try {
      const d = await fnRef.current();
      if (id === seq.current) setData(d);
    } catch (e) {
      if (id === seq.current) setError(errMsg(e));
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);
  return { data, loading, error, reload, setData };
}
