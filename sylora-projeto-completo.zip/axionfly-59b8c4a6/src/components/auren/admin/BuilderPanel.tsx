import { useEffect, useMemo, useState } from "react";
import { Plus, RotateCcw, SlidersHorizontal, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { adminApi } from "@/lib/adminData";
import { namedColors } from "@/components/views/SitesView";
import {
  BUILDER_KEY, EMPTY_CONFIG, mergeNiches, parseConfig, setBuilderConfig,
  type BuilderConfig, type NicheOverride, type NamedColor,
} from "@/lib/builderConfig";
import { Btn, Field, Loading, Note, Panel, RefreshBtn, SearchBox, Switch, errMsg } from "./ui";
import { useLoad } from "./useLoad";

const HEX = /^#[0-9a-fA-F]{6}$/;
const slug = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const PROMPT_HINT = "Variáveis: {{nome}} {{endereco}} {{telefone}} {{cor1}} {{cor2}} {{tipo}} {{nicho}}";
const colorInput = { width: 38, height: 34, padding: 2, border: "1px solid var(--au-border)", borderRadius: 8, background: "transparent", cursor: "pointer" } as const;

type NewNiche = { label: string; app: boolean; primary: string; secondary: string; prompt: string };
const BLANK: NewNiche = { label: "", app: false, primary: "#0F172A", secondary: "#F8FAFC", prompt: "" };

/** Painel do fluxo "Criar Site ou App": nichos, paleta de cores e prompts próprios. Os textos das telas ficam em "Textos do site". */
export const BuilderPanel = () => {
  const { data, loading, error, reload } = useLoad(() => adminApi.getSettings([BUILDER_KEY]), {} as Record<string, string>);
  const [cfg, setCfg] = useState<BuilderConfig>(EMPTY_CONFIG);
  const [saved, setSaved] = useState("");
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [draft, setDraft] = useState<NewNiche>(BLANK);

  useEffect(() => {
    const c = parseConfig(data[BUILDER_KEY]);
    setCfg(c);
    setSaved(JSON.stringify(c));
  }, [data]);

  const dirty = JSON.stringify(cfg) !== saved;
  const rows = useMemo(() => {
    const all = mergeNiches(cfg, true);
    const n = slug(q);
    return n ? all.filter((r) => slug(r.label).includes(n)) : all;
  }, [cfg, q]);
  const colors: NamedColor[] = cfg.colors ?? namedColors;

  const patch = (key: string, o: NicheOverride) => setCfg((c) => ({ ...c, niches: { ...c.niches, [key]: { ...c.niches[key], ...o } } }));
  const reset = (key: string) => setCfg((c) => { const n = { ...c.niches }; delete n[key]; return { ...c, niches: n }; });
  const patchCustom = (key: string, o: Partial<BuilderConfig["custom"][number]>) =>
    setCfg((c) => ({ ...c, custom: c.custom.map((x) => (x.key === key ? { ...x, ...o } : x)) }));

  const addNiche = () => {
    const label = draft.label.trim();
    if (!label) return toast.error("Dê um nome ao nicho.");
    if (!draft.prompt.trim()) return toast.error("Escreva o prompt do nicho: é ele que gera o site ou app.");
    const base = "x-" + (slug(label) || "nicho");
    let key = base, i = 2;
    while (cfg.custom.some((x) => x.key === key)) key = `${base}-${i++}`;
    setCfg((c) => ({ ...c, custom: [...c.custom, { key, label, app: draft.app, primary: draft.primary, secondary: draft.secondary, prompt: draft.prompt.trim() }] }));
    setDraft(BLANK);
    toast.success("Nicho adicionado. Clique em Salvar para publicar.");
  };

  const save = async () => {
    for (const c of cfg.custom) if (!c.prompt.trim()) return toast.error(`O nicho "${c.label}" precisa de um prompt.`);
    const clean: BuilderConfig = { ...cfg, colors: cfg.colors && cfg.colors.length ? cfg.colors.filter((c) => HEX.test(c.hex)) : null };
    const json = JSON.stringify(clean);
    if (json.length > 400_000) return toast.error("Configuração grande demais. Encurte alguns prompts.");
    setSaving(true);
    try {
      await adminApi.saveSettings({ [BUILDER_KEY]: json });
      setBuilderConfig(parseConfig(json));
      toast.success("Salvo. Já vale para quem abrir o Criar Site ou App.");
      await reload();
    } catch (e) {
      toast.error("Não foi possível salvar: " + errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Panel
      title="Criar Site ou App"
      icon={<SlidersHorizontal />}
      sub="Controle os nichos, as cores e os prompts do fluxo de criação. Os textos das telas e do script de abordagem estão em “Textos do site”."
      tools={<><RefreshBtn onClick={reload} busy={loading} /><Btn variant="primary" sm busy={saving} disabled={!dirty} onClick={() => void save()}>Salvar alterações</Btn></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && Object.keys(data).length === 0 && !error ? <Loading /> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          {/* ---------- novo nicho ---------- */}
          <div className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <p className="ad-title" style={{ fontSize: 13 }}>Adicionar nicho</p>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
              <input className="au-input ad-in" style={{ flex: "1 1 220px" }} placeholder="Nome do nicho (ex.: Estúdio de Tatuagem)" value={draft.label} onChange={(e) => setDraft({ ...draft, label: e.target.value })} />
              <input type="color" style={colorInput} aria-label="Cor principal" value={draft.primary} onChange={(e) => setDraft({ ...draft, primary: e.target.value })} />
              <input type="color" style={colorInput} aria-label="Cor secundária" value={draft.secondary} onChange={(e) => setDraft({ ...draft, secondary: e.target.value })} />
              <span style={{ display: "inline-flex", alignItems: "center", gap: 8, fontSize: 13 }}>Aceita app <Switch on={draft.app} onChange={(v) => setDraft({ ...draft, app: v })} label="Aceita app" /></span>
            </div>
            <Field label="Prompt do nicho" hint={PROMPT_HINT}>
              <textarea className="au-input" style={{ minHeight: 120, padding: 12, fontSize: 13, width: "100%" }} value={draft.prompt} onChange={(e) => setDraft({ ...draft, prompt: e.target.value })} placeholder="Crie um {{tipo}} profissional para {{nome}}, do segmento {{nicho}}, nas cores {{cor1}} e {{cor2}}. Contato: {{telefone}}, {{endereco}}." />
            </Field>
            <div><Btn variant="primary" sm onClick={addNiche}><Plus /> Adicionar nicho</Btn></div>
          </div>

          {/* ---------- lista de nichos ---------- */}
          <div className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <p className="ad-title" style={{ fontSize: 13 }}>Nichos ({rows.length})</p>
            <SearchBox value={q} onChange={setQ} placeholder="Buscar nicho" />
            {rows.map((n) => {
              const o = cfg.niches[n.key] || {};
              const hidden = !!o.hidden;
              const isOpen = open === n.key;
              return (
                <div key={n.key} style={{ borderTop: "1px solid var(--au-border)", paddingTop: 10, opacity: hidden ? 0.55 : 1 }}>
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                    <Switch on={!hidden} onChange={(v) => (n.custom ? undefined : patch(n.key, { hidden: !v }))} disabled={n.custom} label={`Mostrar ${n.label}`} />
                    <input className="au-input ad-in" style={{ flex: "1 1 200px" }} value={n.label} aria-label="Nome do nicho"
                      onChange={(e) => (n.custom ? patchCustom(n.key, { label: e.target.value }) : patch(n.key, { label: e.target.value }))} />
                    <input type="color" style={colorInput} aria-label="Cor principal" value={n.defaultPrimary}
                      onChange={(e) => (n.custom ? patchCustom(n.key, { primary: e.target.value }) : patch(n.key, { primary: e.target.value }))} />
                    <input type="color" style={colorInput} aria-label="Cor secundária" value={n.defaultSecondary}
                      onChange={(e) => (n.custom ? patchCustom(n.key, { secondary: e.target.value }) : patch(n.key, { secondary: e.target.value }))} />
                    <span style={{ display: "inline-flex", alignItems: "center", gap: 8, fontSize: 12.5 }}>App
                      <Switch on={n.permiteApp} onChange={(v) => (n.custom ? patchCustom(n.key, { app: v }) : patch(n.key, { app: v }))} label="Aceita app" />
                    </span>
                    <Btn sm onClick={() => setOpen(isOpen ? null : n.key)}>{isOpen ? "Fechar prompt" : n.prompt ? "Prompt próprio ✓" : "Prompt"}</Btn>
                    {n.custom ? (
                      <button type="button" className="au-icon-btn" title="Excluir nicho" aria-label="Excluir nicho" onClick={() => setCfg((c) => ({ ...c, custom: c.custom.filter((x) => x.key !== n.key) }))}><Trash2 /></button>
                    ) : (
                      <button type="button" className="au-icon-btn" title="Voltar ao padrão" aria-label="Voltar ao padrão" onClick={() => reset(n.key)}><RotateCcw /></button>
                    )}
                  </div>
                  {isOpen && (
                    <div style={{ marginTop: 10 }}>
                      <Field label="Prompt próprio" hint={n.custom ? PROMPT_HINT : `${PROMPT_HINT}. Vazio usa o prompt original do sistema para este nicho.`}>
                        <textarea className="au-input" style={{ minHeight: 140, padding: 12, fontSize: 13, width: "100%" }} value={n.prompt ?? ""}
                          onChange={(e) => (n.custom ? patchCustom(n.key, { prompt: e.target.value }) : patch(n.key, { prompt: e.target.value }))} />
                      </Field>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* ---------- paleta ---------- */}
          <div className="ad-box" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
              <p className="ad-title" style={{ fontSize: 13 }}>Paleta de cores oferecida ({colors.length}){cfg.colors ? "" : " · padrão"}</p>
              <div style={{ display: "flex", gap: 8 }}>
                <Btn sm onClick={() => setCfg((c) => ({ ...c, colors: [...colors, { name: "Nova cor", hex: "#2563EB" }] }))}><Plus /> Cor</Btn>
                {cfg.colors && <Btn sm onClick={() => setCfg((c) => ({ ...c, colors: null }))}><RotateCcw /> Padrão</Btn>}
              </div>
            </div>
            {colors.map((c, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <input type="color" style={colorInput} aria-label="Cor" value={c.hex} onChange={(e) => setCfg((x) => ({ ...x, colors: colors.map((y, j) => (j === i ? { ...y, hex: e.target.value } : y)) }))} />
                <input className="au-input ad-in" style={{ flex: 1 }} value={c.name} aria-label="Nome da cor" onChange={(e) => setCfg((x) => ({ ...x, colors: colors.map((y, j) => (j === i ? { ...y, name: e.target.value } : y)) }))} />
                <button type="button" className="au-icon-btn" title="Remover cor" aria-label="Remover cor" disabled={colors.length <= 1} onClick={() => setCfg((x) => ({ ...x, colors: colors.filter((_, j) => j !== i) }))}><Trash2 /></button>
              </div>
            ))}
          </div>
        </div>
      )}
      <Note>Nicho novo ou com prompt próprio gera o texto direto, sem passar pelo sistema original. Nichos escondidos somem para os usuários, mas não perdem nada.</Note>
    </Panel>
  );
};
