import { useMemo, useState } from "react";
import { Eye, Trophy } from "lucide-react";
import { BONUS_DAYS, DAY_MS } from "@/lib/raffleDate";
import { Countdown } from "../presente/Countdown";
import { RaffleWelcomeModal, ReferralUnlock } from "../presente/RaffleBlocks";
import { Btn, Note, Panel } from "./ui";

/** Prévia do sorteio: não grava participante, resultado ou data no servidor. */
export const RafflePanel = ({ onShowTour }: { onShowTour: () => void }) => {
  const [mode, setMode] = useState<"wait" | "done">("wait");
  const [modal, setModal] = useState(0);
  const start = useMemo(() => new Date().toISOString(), []);
  const bonus = useMemo(() => new Date(new Date(start).getTime() + BONUS_DAYS * DAY_MS), [start]);

  return (
    <Panel
      title="Sorteio"
      icon={<Trophy />}
      sub="Pré-visualização de como o bônus, o sorteio e o aviso aparecem para o usuário."
      tools={
        <>
          <button type="button" className={"au-chip" + (mode === "wait" ? " on" : "")} onClick={() => setMode("wait")}>Aguardando sorteio</button>
          <button type="button" className={"au-chip" + (mode === "done" ? " on" : "")} onClick={() => setMode("done")}>Sorteio realizado</button>
        </>
      }
    >
      <div className="ad-box">
        <p className="au-label">Bônus de {BONUS_DAYS} dias (data simulada: agora)</p>
        <Countdown target={bonus} small />
      </div>
      <ReferralUnlock createdAt={start} forceUnlocked={mode === "done"} />
      <div className="ad-tools">
        <Btn onClick={() => setModal((n) => n + 1)}><Eye />Ver modal de boas-vindas</Btn>
        <Btn onClick={onShowTour}><Eye />Ver apresentação de 7 passos</Btn>
      </div>
      <RaffleWelcomeModal userId="admin-preview" enabled={false} forceOpen={modal} />
      <Note tone="warn">
        Alternar entre os estados <b>não grava nada</b>: não há cadastro de campanha, inscritos, elegibilidade, apuração, ganhador, prêmio ou vídeo. Participantes e vencedor do “resultado” são fictícios. O prazo real vem da criação da conta de cada usuário (13 dias para o sorteio, 6 para o bônus).
      </Note>
    </Panel>
  );
};
