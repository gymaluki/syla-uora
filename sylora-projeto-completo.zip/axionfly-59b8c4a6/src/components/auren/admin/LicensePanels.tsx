import { useEffect, useMemo, useState } from "react";
import { History, KeyRound, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { adminApi } from "@/lib/adminData";
import { fmtDate, type AdminUser, type License, type LicenseLog } from "@/lib/adminTypes";
import { Btn, ConfirmBtn, Empty, Loading, Note, Panel, Pill, RefreshBtn, SearchBox, errMsg } from "./ui";
import { useLoad } from "./useLoad";

/* ============================ Licenças ============================ */
export const LicensesPanel = ({ users, onTested }: { users: AdminUser[]; onTested?: () => void }) => {
  const { data: licenses, loading, error, reload } = useLoad(() => adminApi.licenses(), [] as License[]);
  const [q, setQ] = useState("");
  const [testing, setTesting] = useState(false);
  const byId = useMemo(() => new Map(users.map((u) => [u.user_id, u.email])), [users]);

  const available = licenses.filter((l) => l.status === "active" && !l.used_by).length;
  const used = licenses.filter((l) => !!l.used_by).length;
  const level = available <= 10 ? { t: "bad" as const, n: "Estoque crítico" } : available <= 30 ? { t: "warn" as const, n: "Estoque baixo" } : { t: "ok" as const, n: "Estoque saudável" };

  const s = q.trim().toLowerCase();
  const rows = licenses
    .filter((l) => !s || l.key.toLowerCase().includes(s) || (l.lote || "").toLowerCase().includes(s) || (l.used_by && (byId.get(l.used_by) || "").toLowerCase().includes(s)))
    .slice(0, 200);

  const test = async () => {
    setTesting(true);
    try {
      const r = await adminApi.testLicense();
      toast.success(r.message);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setTesting(false);
      await reload();
      onTested?.();
    }
  };

  return (
    <Panel
      title="Licenças Hyperbuild"
      icon={<KeyRound />}
      sub={`${licenses.length} licença${licenses.length === 1 ? "" : "s"} no banco de dados.`}
      tools={
        <>
          <SearchBox value={q} onChange={setQ} placeholder="Buscar chave, lote ou e-mail" />
          <ConfirmBtn sm={false} busy={testing} confirmLabel="Testar mesmo assim" onConfirm={test}>Testar API</ConfirmBtn>
          <RefreshBtn onClick={reload} busy={loading} />
        </>
      }
    >
      {error && <Note tone="bad">{error}</Note>}
      <div className="ad-grid">
        <div className="ad-kpi"><div className="k">Disponíveis</div><div className="v">{available}</div><div className="s"><Pill tone={level.t}>{level.n}</Pill></div></div>
        <div className="ad-kpi"><div className="k">Em uso</div><div className="v">{used}</div></div>
        <div className="ad-kpi"><div className="k">Total</div><div className="v">{licenses.length}</div></div>
      </div>
      {loading && licenses.length === 0 ? <Loading /> : rows.length === 0 ? (
        <Empty icon={<KeyRound />}>Nenhuma licença encontrada.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <thead><tr><th>Chave</th><th>Lote</th><th>Situação</th><th>Usuário</th><th>Usado em</th><th>Expira em</th></tr></thead>
            <tbody>
              {rows.map((l) => (
                <tr key={l.id}>
                  <td className="mono" style={{ color: "var(--au-text)" }}>{l.key}</td>
                  <td className="mut">{l.lote || "—"}</td>
                  <td>{l.used_by ? <Pill plain>Em uso</Pill> : <Pill tone="ok">Disponível</Pill>}</td>
                  <td className="mut">{l.used_by ? byId.get(l.used_by) || "Fora da página carregada" : "—"}</td>
                  <td className="mut">{fmtDate(l.used_at)}</td>
                  <td className="mut">{fmtDate(l.expires_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note tone="warn">
        <b>Testar API não é um ping neutro:</b> a chamada pode atribuir e consumir uma chave de verdade. A tabela mostra até 200 linhas filtradas, e aqui não há criar, importar, revogar, excluir nem renovar licenças. Não exporte chaves reais.
      </Note>
    </Panel>
  );
};

/* ============================ Auditoria ============================ */
export const AuditPanel = ({ users, refreshKey }: { users: AdminUser[]; refreshKey?: number }) => {
  const { data: logs, loading, error, reload } = useLoad(() => adminApi.licenseLogs(50), [] as LicenseLog[]);
  const byId = useMemo(() => new Map(users.map((u) => [u.user_id, u.email])), [users]);
  useEffect(() => { if (refreshKey) void reload(); }, [refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Panel
      title="Histórico de auditoria"
      icon={<History />}
      sub="Os 50 registros mais recentes das licenças."
      tools={<Btn onClick={reload} busy={loading}>Atualizar logs</Btn>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && logs.length === 0 ? <Loading /> : logs.length === 0 ? (
        <Empty icon={<ShieldCheck />}>Nenhum log registrado ainda.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table" style={{ minWidth: 720 }}>
            <thead><tr><th>Data/Hora</th><th>Usuário</th><th>Ação</th><th>Chave</th><th>Detalhes</th></tr></thead>
            <tbody>
              {logs.map((l) => (
                <tr key={l.id}>
                  <td className="mut" style={{ whiteSpace: "nowrap" }}>{fmtDate(l.created_at)}</td>
                  <td>{l.user_id ? byId.get(l.user_id) || "Sistema" : "Sistema"}</td>
                  <td><Pill tone={l.action === "claim" ? "ok" : l.action === "error" ? "bad" : undefined} plain={l.action !== "claim" && l.action !== "error"}>{l.action}</Pill></td>
                  <td className="mono">{l.license_key || "—"}</td>
                  <td className="mut clip">{l.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note>Esta auditoria cobre só as licenças, não todas as mudanças de senha, administração ou plano. O nome do usuário depende da lista carregada; sem correspondência aparece “Sistema”.</Note>
    </Panel>
  );
};
