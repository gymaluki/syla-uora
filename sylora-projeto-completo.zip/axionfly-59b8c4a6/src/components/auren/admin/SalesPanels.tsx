import { useEffect, useMemo, useState } from "react";
import { ExternalLink, Mail, Megaphone, Pencil, Plus, Target, Trophy } from "lucide-react";
import { toast } from "sonner";
import { adminApi } from "@/lib/adminData";
import { PAID_STATUSES, fmtBRL, fmtDate, isLive, type Affiliate, type AdminUser, type PendingPayment, type PlatformSale } from "@/lib/adminTypes";
import { Btn, ConfirmBtn, CopyBtn, Empty, Field, Loading, Note, Panel, Pill, RefreshBtn, SearchBox, errMsg } from "./ui";
import { useLoad } from "./useLoad";

/* ============================ Meta 50K ============================ */
const EST = { lifetimeDirect: 179, monthlyDirect: 139.9, lifetimeAff: 102, monthlyAff: 61 } as const;

const parseMoney = (v: string) => {
  const s = v.replace(/[^\d,.-]/g, "");
  if (!s) return 0;
  const n = s.includes(",") ? Number(s.replace(/\./g, "").replace(",", ".")) : Number(s);
  return Number.isFinite(n) ? n : 0;
};

export const MetaPanel = ({ users }: { users: AdminUser[] }) => {
  const { data: saved, loading, error, reload } = useLoad(() => adminApi.getSettings(["meta_vendas_total", "meta_vendas_goal"]), {} as Record<string, string>);
  const [total, setTotal] = useState("0");
  const [goal, setGoal] = useState("50000");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setTotal(saved.meta_vendas_total ?? "0");
    setGoal(saved.meta_vendas_goal ?? "50000");
  }, [saved]);

  const live = users.map((u) => u.subscription).filter((s) => isLive(s));
  const c = { lifetimeDirect: 0, monthlyDirect: 0, lifetimeAff: 0, monthlyAff: 0 };
  live.forEach((s) => {
    const aff = !!s?.affiliate_slug;
    if (s?.plan === "lifetime") { if (aff) c.lifetimeAff++; else c.lifetimeDirect++; }
    else if (s?.plan === "monthly") { if (aff) c.monthlyAff++; else c.monthlyDirect++; }
  });
  const estimate =
    c.lifetimeDirect * EST.lifetimeDirect + c.monthlyDirect * EST.monthlyDirect + c.lifetimeAff * EST.lifetimeAff + c.monthlyAff * EST.monthlyAff;

  const t = parseMoney(total);
  const g = parseMoney(goal) || 50000;
  const pct = Math.min(100, (t / g) * 100);
  const missing = Math.max(0, g - t);
  const hit = t >= g;

  const save = async (nextTotal = t, nextGoal = g) => {
    setSaving(true);
    try {
      await adminApi.saveSettings({ meta_vendas_total: String(nextTotal), meta_vendas_goal: String(nextGoal) });
      toast.success("Meta salva");
      await reload();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Panel
      title="Meta de vendas"
      icon={<Target />}
      sub="Acompanhamento manual da meta. O total salvo aqui é digitado ou estimado, não é o dinheiro recebido."
      tools={<RefreshBtn onClick={reload} busy={loading} />}
    >
      {error && <Note tone="bad">{error}</Note>}
      {loading && !saved.meta_vendas_total && !error ? <Loading /> : (
        <>
          <div className="ad-box">
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
              <div>
                <div className="ad-big">{fmtBRL(t)}</div>
                <p className="ad-sub" style={{ marginTop: 6 }}>de {fmtBRL(g)}</p>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="ad-big" style={{ fontSize: 26 }}>{pct.toFixed(1)}%</div>
                <p className="ad-sub" style={{ marginTop: 6 }}>{hit ? "Meta atingida" : `Faltam ${fmtBRL(missing)}`}</p>
              </div>
            </div>
            <div className="ad-bar" style={{ marginTop: 16 }}><i style={{ width: `${pct}%` }} /></div>
            {hit && (
              <div style={{ marginTop: 14 }}>
                <Pill tone="silver"><Trophy style={{ width: 12, height: 12 }} />Meta batida. Parabéns!</Pill>
              </div>
            )}
          </div>

          <div className="ad-form">
            <Field label="Total acumulado (R$)">
              <input className="au-input ad-in" inputMode="decimal" value={total} onChange={(e) => setTotal(e.target.value)} />
            </Field>
            <Field label="Meta (R$)">
              <input className="au-input ad-in" inputMode="decimal" value={goal} onChange={(e) => setGoal(e.target.value)} />
            </Field>
            <Btn variant="primary" busy={saving} onClick={() => save()}>Salvar</Btn>
          </div>

          <div className="ad-box">
            <p className="ad-title" style={{ fontSize: 13 }}>Estimativa pelas assinaturas ativas</p>
            <div className="ad-table-wrap" style={{ marginTop: 12 }}>
              <table className="ad-table" style={{ minWidth: 420 }}>
                <thead><tr><th>Tipo</th><th className="num">Qtd.</th><th className="num">Valor estimado</th><th className="num">Subtotal</th></tr></thead>
                <tbody>
                  {([
                    ["Vitalício direto", c.lifetimeDirect, EST.lifetimeDirect],
                    ["Mensal direto", c.monthlyDirect, EST.monthlyDirect],
                    ["Vitalício afiliado", c.lifetimeAff, EST.lifetimeAff],
                    ["Mensal afiliado", c.monthlyAff, EST.monthlyAff],
                  ] as const).map(([n, q, v]) => (
                    <tr key={n}><td>{n}</td><td className="num">{q}</td><td className="num mut">{fmtBRL(v)}</td><td className="num">{fmtBRL(q * v)}</td></tr>
                  ))}
                  <tr><td><b>Total estimado</b></td><td className="num">{live.length}</td><td /><td className="num"><b>{fmtBRL(estimate)}</b></td></tr>
                </tbody>
              </table>
            </div>
            <div className="ad-tools" style={{ marginTop: 14 }}>
              <Btn onClick={() => setTotal(String(t + estimate))}>Somar vendas ativas</Btn>
              <ConfirmBtn sm={false} busy={saving} confirmLabel={`Substituir por ${fmtBRL(estimate)}`} onConfirm={() => { setTotal(String(estimate)); void save(estimate); }}>Sincronizar com vendas reais</ConfirmBtn>
            </div>
          </div>

          <Note tone="warn">
            Os valores por tipo são <b>estimativas fixas</b>, não preços oficiais nem comissões comprovadas. “Somar vendas ativas” só preenche o campo (falta salvar, e somar de novo duplica). “Sincronizar” <b>substitui</b> o total manual e já salva.
          </Note>
        </>
      )}
    </Panel>
  );
};

/* ============================ E-mails Cakto ============================ */
export const CaktoEmailsPanel = ({ pendings }: { pendings: PendingPayment[] }) => {
  const { data: sales, loading, error, reload } = useLoad(() => adminApi.platformSales(1000), [] as PlatformSale[]);
  const [sub, setSub] = useState<"vendas" | "pendentes">("vendas");
  const [q, setQ] = useState("");
  const pend = pendings.slice(0, 1000);

  const emails = new Set([...sales.map((s) => s.email), ...pend.map((p) => p.email)].map((e) => e.toLowerCase()));
  const revenue = sales.filter((s) => PAID_STATUSES.includes(s.status)).reduce((a, s) => a + (s.amount || 0), 0);
  const needle = q.trim().toLowerCase();
  const sRows = sales.filter((s) => !needle || s.email.toLowerCase().includes(needle) || (s.transaction_id || "").toLowerCase().includes(needle));
  const pRows = pend.filter((p) => !needle || p.email.toLowerCase().includes(needle) || (p.transaction_id || "").toLowerCase().includes(needle));

  return (
    <Panel
      title="E-mails de compra"
      icon={<Mail />}
      sub="Monitor dos registros de compra e pendências por e-mail. Não envia e-mail e não prova entrega."
      tools={<><SearchBox value={q} onChange={setQ} placeholder="Buscar e-mail ou transação" /><RefreshBtn onClick={reload} busy={loading} /></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      <div className="ad-grid">
        <div className="ad-kpi"><div className="k">E-mails únicos</div><div className="v">{emails.size}</div></div>
        <div className="ad-kpi"><div className="k">Receita registrada</div><div className="v">{fmtBRL(revenue)}</div><div className="s">Status pago, ativo, aprovado ou concluído</div></div>
        <div className="ad-kpi"><div className="k">Pendentes</div><div className="v">{pend.length}</div></div>
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        {(["vendas", "pendentes"] as const).map((k) => (
          <button key={k} type="button" className={"au-chip" + (sub === k ? " on" : "")} onClick={() => setSub(k)}>
            {k === "vendas" ? `Vendas (${sRows.length})` : `Pendentes (${pRows.length})`}
          </button>
        ))}
      </div>
      {loading && sales.length === 0 ? <Loading /> : sub === "vendas" ? (
        sRows.length === 0 ? <Empty icon={<Mail />}>Nenhuma venda encontrada.</Empty> : (
          <div className="ad-table-wrap">
            <table className="ad-table">
              <thead><tr><th>E-mail</th><th>Plano</th><th>Valor</th><th>Situação</th><th>Origem</th><th>Transação</th><th>Data</th><th /></tr></thead>
              <tbody>
                {sRows.map((s) => (
                  <tr key={s.id}>
                    <td>{s.email}</td>
                    <td className="mut">{s.plan || "—"}</td>
                    <td className="num">{s.amount != null ? fmtBRL(s.amount) : "—"}</td>
                    <td><Pill tone={PAID_STATUSES.includes(s.status) ? "ok" : "warn"}>{s.status}</Pill></td>
                    <td className="mut">{s.affiliate_slug ? `Afiliado: ${s.affiliate_slug}` : "Direto"}</td>
                    <td className="mono">{s.transaction_id || "—"}</td>
                    <td className="mut">{fmtDate(s.created_at)}</td>
                    <td className="r"><CopyBtn text={s.email} label="Copiar e-mail" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      ) : pRows.length === 0 ? <Empty icon={<Mail />}>Nenhum pendente encontrado.</Empty> : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <thead><tr><th>E-mail</th><th>Plano</th><th>Situação</th><th>Provedor</th><th>Transação</th><th>Data</th><th /></tr></thead>
            <tbody>
              {pRows.map((p) => (
                <tr key={p.id}>
                  <td>{p.email}</td>
                  <td className="mut">{p.plan || "—"}</td>
                  <td><Pill tone={p.status === "active" ? "warn" : "ok"}>{p.status === "active" ? "Aguardando cadastro" : "Ativado"}</Pill></td>
                  <td className="mut">{p.payment_provider || "—"}</td>
                  <td className="mono">{p.transaction_id || "—"}</td>
                  <td className="mut">{fmtDate(p.created_at)}</td>
                  <td className="r"><CopyBtn text={p.email} label="Copiar e-mail" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Note>As consultas não filtram só um provedor e têm limite de 1.000 registros. A receita soma os valores gravados, não confirma recebimento no banco.</Note>
    </Panel>
  );
};

/* ============================ Afiliados ============================ */
const ALLOWED_HOSTS = ["applyfy.com.br", "cakto.com.br", "kirvano.com", "perfectpay.com.br", "abacatepay.com", "pay.cakto.com.br"];
const hostOk = (url: string) => {
  try {
    const u = new URL(url);
    if (u.protocol !== "https:") return false;
    const h = u.hostname.toLowerCase();
    return ALLOWED_HOSTS.some((d) => h === d || h.endsWith("." + d));
  } catch {
    return false;
  }
};
const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9-]/g, "");

type Draft = { id?: string; name: string; slug: string; email: string; monthly_url: string; lifetime_url: string };
const EMPTY: Draft = { name: "", slug: "", email: "", monthly_url: "", lifetime_url: "" };

export const AffiliatesPanel = () => {
  const { data, loading, error, reload } = useLoad(async () => ({ aff: await adminApi.affiliates(), sales: await adminApi.platformSales(500) }), { aff: [] as Affiliate[], sales: [] as PlatformSale[] });
  const [draft, setDraft] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const entry = (slug: string) => `${origin}/a/${slug}`;

  const stats = useMemo(() => {
    const m = new Map<string, { n: number; vol: number }>();
    data.sales.forEach((s) => {
      if (!s.affiliate_slug || !PAID_STATUSES.includes(s.status)) return;
      const cur = m.get(s.affiliate_slug) || { n: 0, vol: 0 };
      cur.n++; cur.vol += s.amount || 0;
      m.set(s.affiliate_slug, cur);
    });
    return m;
  }, [data.sales]);

  const submit = async () => {
    if (!draft) return;
    const d = { ...draft, name: draft.name.trim(), slug: slugify(draft.slug), email: draft.email.trim(), monthly_url: draft.monthly_url.trim(), lifetime_url: draft.lifetime_url.trim() };
    if (!d.name || !d.slug) return toast.error("Informe o nome e o identificador público.");
    if (!d.monthly_url && !d.lifetime_url) return toast.error("Informe pelo menos um destino (mensal ou anual).");
    for (const [label, u] of [["mensal", d.monthly_url], ["anual", d.lifetime_url]] as const) {
      if (u && !hostOk(u)) return toast.error(`O destino ${label} precisa ser um link https de um provedor aceito.`);
    }
    if (d.monthly_url && d.monthly_url === d.lifetime_url) return toast.error("Os destinos mensal e anual não podem ser iguais.");
    setSaving(true);
    try {
      await adminApi.saveAffiliate(d);
      toast.success(d.id ? "Afiliado atualizado" : "Afiliado criado");
      setDraft(null);
      await reload();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (a: Affiliate) => {
    try {
      await adminApi.deleteAffiliate(a.id);
      toast.success("Afiliado excluído");
      await reload();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  return (
    <Panel
      title="Afiliados"
      icon={<Megaphone />}
      sub="Parceiros, entrada pública e destinos de checkout. A indicação é preservada pelo controlador de atribuição do site."
      tools={<><Btn variant="primary" onClick={() => setDraft({ ...EMPTY })}><Plus />Novo afiliado</Btn><RefreshBtn onClick={reload} busy={loading} /></>}
    >
      {error && <Note tone="bad">{error}</Note>}
      {draft && (
        <div className="ad-box">
          <div className="ad-form">
            <Field label="Nome"><input className="au-input ad-in" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
            <Field label="Identificador público" hint={`Endereço: /a/${slugify(draft.slug) || "identificador"}`}>
              <input className="au-input ad-in" value={draft.slug} onChange={(e) => setDraft({ ...draft, slug: slugify(e.target.value) })} />
            </Field>
            <Field label="E-mail (opcional)"><input className="au-input ad-in" type="email" value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
          </div>
          <div className="ad-form" style={{ marginTop: 12, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
            <Field label="Destino mensal"><input className="au-input ad-in" value={draft.monthly_url} onChange={(e) => setDraft({ ...draft, monthly_url: e.target.value })} placeholder="https://" /></Field>
            <Field label="Destino anual"><input className="au-input ad-in" value={draft.lifetime_url} onChange={(e) => setDraft({ ...draft, lifetime_url: e.target.value })} placeholder="https://" /></Field>
          </div>
          {draft.id && <div style={{ marginTop: 12 }}><Note tone="warn">Mudar o identificador muda o endereço público; o endereço antigo deixa de funcionar.</Note></div>}
          <div className="ad-tools" style={{ marginTop: 14 }}>
            <Btn variant="primary" busy={saving} onClick={submit}>{draft.id ? "Salvar alterações" : "Criar afiliado"}</Btn>
            <Btn onClick={() => setDraft(null)}>Cancelar</Btn>
          </div>
        </div>
      )}

      {loading && data.aff.length === 0 ? <Loading /> : data.aff.length === 0 ? (
        <Empty icon={<Megaphone />}>Nenhum afiliado cadastrado.</Empty>
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table" style={{ minWidth: 820 }}>
            <thead><tr><th>Parceiro</th><th>Entrada pública</th><th className="num">Vendas</th><th className="num">Volume</th><th>Destinos</th><th className="r">Ações</th></tr></thead>
            <tbody>
              {data.aff.map((a) => {
                const st = stats.get(a.slug);
                return (
                  <tr key={a.id}>
                    <td><div>{a.name}</div><div className="mut">{a.email || "—"}</div></td>
                    <td>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <span className="mono">/a/{a.slug}</span>
                        <CopyBtn text={entry(a.slug)} label="Copiar entrada" />
                        <a className="au-icon-btn" href={entry(a.slug)} target="_blank" rel="noreferrer" title="Abrir" aria-label="Abrir entrada"><ExternalLink /></a>
                      </span>
                    </td>
                    <td className="num">{st?.n ?? 0}</td>
                    <td className="num">{fmtBRL(st?.vol ?? 0)}</td>
                    <td>
                      <span style={{ display: "inline-flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                        {a.monthly_url ? <><Pill plain>Mensal</Pill><CopyBtn text={a.monthly_url} label="Copiar destino mensal" /></> : null}
                        {a.lifetime_url ? <><Pill plain>Anual</Pill><CopyBtn text={a.lifetime_url} label="Copiar destino anual" /></> : null}
                      </span>
                    </td>
                    <td className="r">
                      <span style={{ display: "inline-flex", gap: 8, justifyContent: "flex-end" }}>
                        <Btn sm onClick={() => setDraft({ id: a.id, name: a.name, slug: a.slug, email: a.email || "", monthly_url: a.monthly_url || "", lifetime_url: a.lifetime_url || "" })}><Pencil />Editar</Btn>
                        <ConfirmBtn confirmLabel="Excluir" onConfirm={() => remove(a)}>Excluir</ConfirmBtn>
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <Note>
        Volume e vendas usam as 500 vendas mais recentes e só contam status pago. Excluir um afiliado não liquida comissão nem estorna vendas. Conferir se o código de comissão no provedor externo está correto é por sua conta.
      </Note>
    </Panel>
  );
};

