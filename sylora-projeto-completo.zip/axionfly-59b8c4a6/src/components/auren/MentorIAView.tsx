import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Bot, Send, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Msg = { role: "user" | "assistant"; content: string };

const MentorIAView = () => {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("mentor-ia", { body: { messages: next } });
      if (error || !data?.reply) throw error ?? new Error(data?.error);
      setMessages((m) => [...m, { role: "assistant", content: data.reply }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: "Não consegui responder agora. Tente de novo em instantes." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="max-w-[880px] mx-auto pt-6 pb-10"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <div className="au-builder overflow-hidden">
        <div className="flex items-center gap-3.5 px-5 py-4 border-b border-white/[0.07]">
          <div className="au-icon-box solid"><Bot /></div>
          <div className="min-w-0">
            <div className="flex items-center gap-2.5 flex-wrap">
              <p className="au-display text-[17px] font-bold text-[var(--au-text)]">
                Mentor IA <span className="au-shine">Sylora</span>
              </p>
              <span className="au-badge" style={{ padding: "3px 9px", fontSize: 8.5, letterSpacing: "0.16em" }}>
                <Sparkles /> Disponível
              </span>
            </div>
            <p className="text-[12px] text-[var(--au-text-3)] mt-0.5">Tire dúvidas sobre como usar a Sylora e suas funcionalidades</p>
          </div>
        </div>

        <div className="relative h-[440px] overflow-y-auto au-scroll px-5 py-6">
          <div aria-hidden className="au-grid-bg absolute inset-0 pointer-events-none" style={{ maskImage: "none", opacity: 0.6 }} />
          <div className="relative">
            {messages.length === 0 ? (
              <div className="text-center pt-4">
                <motion.div
                  className="au-icon-box solid mx-auto"
                  style={{ width: 80, height: 80, borderRadius: 22 }}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 220, damping: 16 }}
                >
                  <Sparkles style={{ width: 34, height: 34 }} />
                </motion.div>
                <h3 className="au-display text-[22px] font-bold text-[var(--au-text)] mt-6">Como posso te ajudar hoje?</h3>
                <p className="text-[14px] text-[var(--au-text-2)] mt-3 max-w-[420px] mx-auto leading-relaxed">
                  O Mentor IA te ajuda a se localizar dentro da Sylora: onde encontrar cada função, como usar a extensão,
                  como gerar o prompt do site, como acessar scripts, calculadora de preço, prospecção e por aí vai.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <AnimatePresence initial={false}>
                  {messages.map((m, i) => (
                    <motion.div
                      key={i}
                      className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <div
                        className={`${m.role === "user" ? "au-bubble-user font-medium" : "au-bubble-ai"} max-w-[80%] px-4 py-2.5 text-[14px] leading-relaxed whitespace-pre-wrap`}
                      >
                        {m.content}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {loading && (
                  <div className="flex justify-start">
                    <div className="au-bubble-ai px-4 py-3 au-typing flex gap-1.5"><span /><span /><span /></div>
                  </div>
                )}
                <div ref={endRef} />
              </div>
            )}
          </div>
        </div>

        <div className="px-4 pt-4 pb-3 border-t border-white/[0.07]">
          <form
            className="flex gap-2.5"
            onSubmit={(e) => { e.preventDefault(); send(); }}
          >
            <input
              className="au-input"
              placeholder="Ex: onde fica a extensão? como gero o prompt do site?"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button type="submit" disabled={!input.trim() || loading} className="au-btn au-btn-primary shrink-0" style={{ width: 46, padding: 0 }} aria-label="Enviar">
              <Send />
            </button>
          </form>
          <p className="text-center text-[11px] text-[var(--au-text-3)] mt-2.5">O Mentor IA pode cometer erros. Confira informações importantes.</p>
        </div>
      </div>
    </motion.div>
  );
};

export default MentorIAView;
