import { useState, useEffect, useMemo } from "react";
import { useCurrency } from "@/lib/currency";
import { Trash2, Edit2, X, Check, Radio, TrendingUp, Clock, Receipt, CalendarDays, SlidersHorizontal } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import "@/components/auren/sylora-shell.css";

interface Sale {
  id: string;
  client_name: string;
  description: string | null;
  amount: number;
  status: string;
  sale_date: string;
  created_at?: string;
}

const statusOptions = [
  { value: "pendente", label: "Pendente", color: "text-yellow-500" },
  { value: "pago", label: "Pago", color: "text-green-500" },
  { value: "cancelado", label: "Cancelado", color: "text-red-500" },
];

/** Data local (YYYY-MM-DD) — evita o dia "virar" antes da meia-noite no Brasil. */
const localDate = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const fmtDate = (ymd: string) => {
  const [y, m, d] = ymd.split("-");
  return `${d}/${m}/${y}`;
};

const REFRESH_MS = 30_000;

const VendasView = () => {
  const { user } = useAuth();
  const [sales, setSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Modo Protocolo: conta de demonstração pode ajustar qualquer número do painel (só no navegador, nunca grava venda).
  const [isProto, setIsProto] = useState(false);
  const [showOv, setShowOv] = useState(false);
  const ovKey = user ? `sy_proto_ov_${user.id}` : "";
  const [ov, setOv] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!user) return;
    (supabase as any).from("profiles").select("is_protocolo").eq("user_id", user.id).maybeSingle()
      .then(({ data }: { data?: { is_protocolo?: boolean } | null }) => setIsProto(data?.is_protocolo === true))
      .catch(() => {});
    try { setOv(JSON.parse(localStorage.getItem(`sy_proto_ov_${user.id}`) || "{}")); } catch { setOv({}); }
  }, [user]);
  const setOvField = (k: string, v: string) => setOv((cur) => {
    const next = { ...cur, [k]: v };
    if (v === "") delete next[k];
    try { localStorage.setItem(ovKey, JSON.stringify(next)); } catch { /* sem armazenamento */ }
    return next;
  });
  const clearOv = () => { setOv({}); try { localStorage.removeItem(ovKey); } catch { /* ok */ } };
  const num = (k: string, real: number) => {
    if (!isProto) return real;
    const raw = ov[k];
    return raw !== undefined && raw !== "" && Number.isFinite(Number(raw)) ? Number(raw) : real;
  };

  // Form fields
  const [clientName, setClientName] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [status, setStatus] = useState("pendente");
  const [saleDate, setSaleDate] = useState(localDate());

  const demoSales: Sale[] = useMemo(() => {
    const now = new Date();
    const entries = [
      { client_name: "Barbearia Dom Corte", amount: 2800, status: "pago", daysAgo: 3 },
      { client_name: "Barbearia El Patrón", amount: 1500, status: "pago", daysAgo: 7 },
      { client_name: "Barbearia Vintage Club", amount: 1900, status: "pago", daysAgo: 12 },
      { client_name: "Barbearia Reis do Corte", amount: 1200, status: "pago", daysAgo: 15 },
      { client_name: "Navalha Negra Barbearia", amount: 1700, status: "pago", daysAgo: 18 },
      { client_name: "Barbearia Lenhador", amount: 1650, status: "pago", daysAgo: 22 },
      { client_name: "Studio Barber Premium", amount: 1786, status: "pago", daysAgo: 25 },
      { client_name: "Barbearia Old School SP", amount: 1400, status: "pago", daysAgo: 30 },
      { client_name: "Corte & Estilo Barbearia", amount: 1550, status: "pago", daysAgo: 35 },
      { client_name: "Barbearia Machado", amount: 1350, status: "pago", daysAgo: 38 },
      { client_name: "Dom Bigode Barbearia", amount: 1750, status: "pago", daysAgo: 42 },
      { client_name: "Barbearia Tropa do Corte", amount: 1300, status: "pago", daysAgo: 45 },
      { client_name: "Barbearia La Mafia", amount: 1600, status: "pago", daysAgo: 48 },
      { client_name: "Barbearia Cavalheiro", amount: 1450, status: "pago", daysAgo: 50 },
      { client_name: "Black Barber Studio", amount: 1800, status: "pago", daysAgo: 53 },
      { client_name: "Barbearia Corte Real", amount: 1831, status: "pago", daysAgo: 56 },
      { client_name: "Barbearia Império do Fade", amount: 2200, status: "pendente", daysAgo: 1 },
    ];
    return entries.map((e, i) => {
      const d = new Date(now);
      d.setDate(d.getDate() - e.daysAgo);
      return {
        id: `demo-${i}`,
        client_name: e.client_name,
        description: "Criação de site",
        amount: e.amount,
        status: e.status,
        sale_date: localDate(d),
      };
    });
  }, []);

  const fetchSales = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("sales")
      .select("*")
      .order("sale_date", { ascending: false });
    const isOwner = user.email === "andreyhenriquev4@gmail.com";
    if (error) {
      toast.error("Erro ao carregar vendas");
      setSales(isOwner ? demoSales : []);
    } else {
      const realSales = (data as Sale[]) || [];
      setSales(isOwner ? [...realSales, ...demoSales] : realSales);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSales();
    // "Ao vivo": recarrega as vendas periodicamente
    const id = window.setInterval(fetchSales, REFRESH_MS);
    return () => window.clearInterval(id);
  }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  const resetForm = () => {
    setClientName("");
    setDescription("");
    setAmount("");
    setStatus("pendente");
    setSaleDate(localDate());
    setShowForm(false);
    setEditingId(null);
  };

  const handleSubmit = async () => {
    if (!clientName.trim() || !amount) {
      toast.error("Preencha o nome do cliente e o valor");
      return;
    }

    const payload = {
      client_name: clientName.trim(),
      description: description.trim() || null,
      amount: parseFloat(amount),
      status,
      sale_date: saleDate,
      user_id: user!.id,
    };

    if (editingId) {
      const { error } = await supabase.from("sales").update(payload).eq("id", editingId);
      if (error) {
        toast.error("Erro ao atualizar venda");
        return;
      }
      toast.success("Venda atualizada!");
    } else {
      const { error } = await supabase.from("sales").insert(payload);
      if (error) {
        toast.error("Erro ao adicionar venda");
        return;
      }
      toast.success("Venda registrada!");
      const audio = new Audio("/sounds/sale-added.mpeg");
      audio.volume = 0.5;
      audio.play().catch(() => {});
    }

    resetForm();
    fetchSales();
  };

  const handleEdit = (sale: Sale) => {
    setClientName(sale.client_name);
    setDescription(sale.description || "");
    setAmount(String(sale.amount));
    setStatus(sale.status);
    setSaleDate(sale.sale_date);
    setEditingId(sale.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("sales").delete().eq("id", id);
    if (error) {
      toast.error("Erro ao excluir venda");
      return;
    }
    toast.success("Venda excluída");
    fetchSales();
  };

  const { format: formatCurrency } = useCurrency();

  // ---- números reais ----
  const today = localDate();
  const monthPrefix = today.slice(0, 7);
  const active = sales.filter((s) => s.status !== "cancelado");
  const paid = sales.filter((s) => s.status === "pago");
  const todaySales = active
    .filter((s) => s.sale_date === today)
    .sort((a, b) => (b.created_at ?? "").localeCompare(a.created_at ?? ""));
  const todayTotal = num("today", todaySales.reduce((sum, s) => sum + Number(s.amount), 0));
  const todayCount = Math.round(num("todayCount", todaySales.length));
  const totalRevenue = num("revenue", paid.reduce((sum, s) => sum + Number(s.amount), 0));
  const totalPending = num("pending", sales.filter((s) => s.status === "pendente").reduce((sum, s) => sum + Number(s.amount), 0));
  const monthCount = Math.round(num("month", active.filter((s) => s.sale_date.startsWith(monthPrefix)).length));
  const salesCount = Math.round(num("count", active.length));
  const avgTicket = num("ticket", paid.length ? totalRevenue / paid.length : 0);

  // Receita dos últimos 7 dias (vendas não canceladas)
  const last7 = useMemo(() => {
    const days: { key: string; label: string; total: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = localDate(d);
      days.push({
        key,
        label: d.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", ""),
        total: num(`d${6 - i}`, sales.filter((s) => s.status !== "cancelado" && s.sale_date === key).reduce((sum, s) => sum + Number(s.amount), 0)),
      });
    }
    return days;
  }, [sales, ov, isProto]); // eslint-disable-line react-hooks/exhaustive-deps
  const maxDay = Math.max(1, ...last7.map((d) => d.total));

  // curva suave dos últimos 7 dias (viewBox 700x150, margens laterais iguais às do cartão)
  const curve = useMemo(() => {
    const W = 700, H = 150, padX = 28, top = 18, bot = 6;
    const pts = last7.map((d, i) => [padX + (i * (W - padX * 2)) / 6, top + (1 - d.total / maxDay) * (H - top - bot)] as const);
    let line = `M${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[Math.max(0, i - 1)], [x1, y1] = pts[i], [x2, y2] = pts[i + 1], [x3, y3] = pts[Math.min(pts.length - 1, i + 2)];
      line += ` C${x1 + (x2 - x0) / 6},${y1 + (y2 - y0) / 6} ${x2 - (x3 - x1) / 6},${y2 - (y3 - y1) / 6} ${x2},${y2}`;
    }
    const last = pts[pts.length - 1];
    return { W, H, pts, line, area: `${line} L${last[0]},${H} L${pts[0][0]},${H} Z`, last };
  }, [last7, maxDay]);

  const [filter, setFilter] = useState<"todas" | "pago" | "pendente" | "cancelado">("todas");
  const shown = filter === "todas" ? sales : sales.filter((s) => s.status === filter);

  // 8 semanas de vendas (colunas = semanas, linhas = dias da semana)
  const heat = useMemo(() => {
    const byDay = new Map<string, number>();
    sales.filter((s) => s.status !== "cancelado").forEach((s) => byDay.set(s.sale_date, (byDay.get(s.sale_date) ?? 0) + Number(s.amount)));
    const start = new Date(); start.setDate(start.getDate() - 55);
    const cells: { key: string; lv: number; pad?: boolean }[] = Array.from({ length: start.getDay() }, (_, i) => ({ key: `p${i}`, lv: 0, pad: true }));
    const vals: number[] = [];
    for (let i = 0; i < 56; i++) { const d = new Date(start); d.setDate(start.getDate() + i); vals.push(byDay.get(localDate(d)) ?? 0); }
    const top = Math.max(1, ...vals);
    for (let i = 0; i < 56; i++) {
      const d = new Date(start); d.setDate(start.getDate() + i);
      const t = vals[i];
      cells.push({ key: localDate(d), lv: t === 0 ? 0 : Math.min(4, Math.ceil((t / top) * 4)) });
    }
    return cells;
  }, [sales]);

  // participação de cada status no valor total
  const totalCancelled = num("cancelled", sales.filter((s) => s.status === "cancelado").reduce((sum, s) => sum + Number(s.amount), 0));
  const shareTotal = totalRevenue + totalPending + totalCancelled;
  const ringParts = [
    { key: "pago", label: "Pago", color: "#0A0A0C", value: totalRevenue },
    { key: "pendente", label: "Pendente", color: "#8A8D97", value: totalPending },
    { key: "cancelado", label: "Cancelado", color: "#D8D9DE", value: totalCancelled },
  ];
  const paidPct = shareTotal ? Math.round((totalRevenue / shareTotal) * 100) : 0;

  const tape = useMemo(() => [...sales].sort((a, b) => b.sale_date.localeCompare(a.sale_date)).slice(0, 12), [sales]);
  const groups = useMemo(() => {
    const m = new Map<string, Sale[]>();
    shown.forEach((s) => m.set(s.sale_date, [...(m.get(s.sale_date) ?? []), s]));
    return [...m.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, [shown]);

  const longDate = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });

  const timeOf = (s: Sale) =>
    s.created_at ? new Date(s.created_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) : "hoje";

  const statusPill = (st: string) => (
    <span className={cn("sy-pill", st)}>
      <i />
      {statusOptions.find((o) => o.value === st)?.label ?? st}
    </span>
  );

  const initialsOf = (n: string) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="sy-dash max-w-[1120px] mx-auto space-y-4 pb-8"
    >
      {/* Cabeçalho */}
      <div className="sy-head pb-1">
        <div>
          <p className="au-eyebrow" style={{ letterSpacing: "0.22em" }}>{longDate.charAt(0).toUpperCase() + longDate.slice(1)}</p>
          <h2 className="au-display text-[24px] md:text-[28px] font-bold text-[var(--au-text)] mt-1 leading-tight">
            Resumo das <span className="au-shine">vendas</span>
          </h2>
          <p className="text-[14px] text-[var(--au-text-2)] mt-2">
            {salesCount === 0 ? "Nenhuma venda registrada ainda." : `${salesCount} venda${salesCount === 1 ? "" : "s"} registrada${salesCount === 1 ? "" : "s"} · ${monthCount} neste mês`}
          </p>
        </div>
        {isProto && (
          <button type="button" onClick={() => setShowOv((v) => !v)} className="au-btn" aria-expanded={showOv}>
            <SlidersHorizontal /> {showOv ? "Fechar edição" : "Editar resultados"}
          </button>
        )}
      </div>

      {/* Protocolo: editar qualquer resultado do painel */}
      {isProto && showOv && (
        <div className="au-card p-5">
          <div className="flex items-center justify-between gap-3 mb-1">
            <p className="au-display text-[16px] font-bold text-[var(--au-text)]">Editar resultados (Protocolo)</p>
            <button type="button" onClick={clearOv} className="au-btn">Restaurar valores reais</button>
          </div>
          <p className="text-[12.5px] text-[var(--au-text-3)] mb-4">Deixe em branco para usar o valor real. Os ajustes ficam só neste navegador e não criam vendas.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {([
              ["today", "Vendas hoje (R$)"], ["todayCount", "Qtd. vendas hoje"], ["revenue", "Receita paga (R$)"], ["pending", "A receber (R$)"],
              ["cancelled", "Cancelado (R$)"], ["ticket", "Ticket médio (R$)"], ["month", "Vendas no mês"], ["count", "Vendas registradas"],
            ] as const).map(([k, l]) => (
              <div key={k}>
                <label className="au-label" htmlFor={`ov-${k}`}>{l}</label>
                <input id={`ov-${k}`} className="au-input" type="number" inputMode="decimal" min="0" step="any" placeholder="real" value={ov[k] ?? ""} onChange={(e) => setOvField(k, e.target.value)} />
              </div>
            ))}
          </div>
          <p className="au-label mt-4">Últimos 7 dias (R$)</p>
          <div className="grid grid-cols-4 md:grid-cols-7 gap-3">
            {last7.map((d, i) => (
              <div key={d.key}>
                <label className="au-label" htmlFor={`ov-d${i}`}>{d.label}</label>
                <input id={`ov-d${i}`} className="au-input" type="number" inputMode="decimal" min="0" step="any" placeholder="real" value={ov[`d${i}`] ?? ""} onChange={(e) => setOvField(`d${i}`, e.target.value)} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Formulário */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="au-card p-6" style={{ borderColor: "rgba(230,233,238,0.22)" }}>
              <div className="flex items-center justify-between mb-5">
                <p className="au-display text-[18px] font-bold text-[var(--au-text)]">{editingId ? "Editar Venda" : "Nova Venda"}</p>
                <button type="button" onClick={resetForm} className="au-icon-btn" aria-label="Fechar"><X /></button>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="au-label">Cliente *</label>
                  <input className="au-input" placeholder="Nome do cliente" value={clientName} onChange={(e) => setClientName(e.target.value)} />
                </div>
                <div>
                  <label className="au-label">Valor (R$) *</label>
                  <input className="au-input" type="number" step="0.01" placeholder="0,00" value={amount} onChange={(e) => setAmount(e.target.value)} />
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-4 mt-4">
                <div>
                  <label className="au-label">Descrição</label>
                  <input className="au-input" placeholder="Ex: Criação de site" value={description} onChange={(e) => setDescription(e.target.value)} />
                </div>
                <div>
                  <label className="au-label">Status</label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger className="au-input flex items-center justify-between"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[var(--au-surface)] border-[var(--au-border)] text-[var(--au-text)]">
                      {statusOptions.map((s) => (
                        <SelectItem key={s.value} value={s.value} className="focus:bg-white/[0.06] focus:text-[var(--au-text)]">{s.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="au-label">Data</label>
                  <input className="au-input" type="date" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} style={{ colorScheme: "dark" }} />
                </div>
              </div>
              <button type="button" onClick={handleSubmit} className="au-btn au-btn-primary w-full mt-5">
                <Check /> {editingId ? "Salvar Alterações" : "Registrar Venda"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AO VIVO */}
      <div className="sy-hero au-dark">
        <div className="min-w-0">
          <div className="meta">
            <span className="sy-tag"><i /> Ao vivo</span>
            <span className="text-[11px] text-[#8A8D97] flex items-center gap-1.5"><Radio className="w-3.5 h-3.5" /> atualiza a cada 30s</span>
          </div>
          <p className="label">Vendas ao vivo hoje</p>
          <motion.p key={todayTotal} initial={{ opacity: 0.4, y: 8 }} animate={{ opacity: 1, y: 0 }} className="amount">
            {formatCurrency(todayTotal)}
          </motion.p>
          <p className="sub">
            {todayCount === 0
              ? "Nenhuma venda hoje ainda."
              : `${todayCount} ${todayCount === 1 ? "venda registrada" : "vendas registradas"} hoje`}
          </p>
        </div>

        {/* 8 semanas */}
        <div className="sy-heat">
          <div className="sy-heat-grid" role="img" aria-label="Vendas das últimas 8 semanas">
            {heat.map((c) => (
              <i key={c.key} className={cn(c.pad ? "pad" : `l${c.lv}`, c.key === today && "now")} title={c.pad ? undefined : fmtDate(c.key)} />
            ))}
          </div>
        </div>
      </div>

      {/* Fita de vendas */}
      {tape.length > 0 && (
        <div className="sy-tape" aria-label="Últimas vendas">
          <div className="sy-tape-track">
            {[...tape, ...tape].map((s, i) => (
              <span key={`${s.id}-${i}`} className="sy-tape-item">
                <span className="sy-ini s">{initialsOf(s.client_name)}</span>
                {s.client_name}
                <b>{formatCurrency(Number(s.amount))}</b>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Últimos 7 dias */}
      <div className="sy-week au-dark">
        <div className="head">
          <div>
            <p className="label">Últimos 7 dias</p>
            <p className="total">{formatCurrency(last7.reduce((sum, d) => sum + d.total, 0))}</p>
          </div>
          <p className="note">
            {last7.filter((d) => d.total > 0).length} de 7 dias com venda
          </p>
        </div>
        <div className="bars" role="img" aria-label="Receita de cada um dos últimos 7 dias">
          {last7.map((d, i) => (
            <div key={d.key} className={cn("col", i === last7.length - 1 && "now")}>
              <span className="val">{d.total > 0 ? formatCurrency(d.total) : "—"}</span>
              <div className="track"><motion.i initial={{ height: 0 }} animate={{ height: `${Math.max(d.total > 0 ? 6 : 0, (d.total / maxDay) * 100)}%` }} transition={{ duration: 0.7, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }} /></div>
              <span className="day">{d.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="sy-mid">
        {/* Participação + indicadores */}
        <div className="sy-panel">
          <div className="sy-ring">
            <svg viewBox="0 0 120 120" aria-hidden>
              <circle cx="60" cy="60" r="48" fill="none" stroke="rgba(10,10,12,0.06)" strokeWidth="14" />
              {(() => {
                const C = 2 * Math.PI * 48; let off = 0;
                return ringParts.map((p) => {
                  const len = shareTotal ? (p.value / shareTotal) * C : 0;
                  const el = <motion.circle key={p.key} cx="60" cy="60" r="48" fill="none" stroke={p.color} strokeWidth="14" strokeDasharray={`${Math.max(0, len - 2)} ${C}`} strokeDashoffset={-off} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }} />;
                  off += len; return el;
                });
              })()}
            </svg>
            <div className="min-w-0 flex-1">
              <p className="au-display text-[40px] font-bold tabular-nums leading-none text-[var(--au-text)]">{paidPct}%</p>
              <div className="sy-legend mt-4">
                {ringParts.map((p) => (
                  <div key={p.key}><i style={{ background: p.color }} />{p.label}<b>{formatCurrency(p.value)}</b></div>
                ))}
              </div>
            </div>
          </div>

          <div className="sy-stats">
            {[
              { icon: TrendingUp, label: "Receita paga", value: formatCurrency(totalRevenue) },
              { icon: Clock, label: "A receber", value: formatCurrency(totalPending) },
              { icon: Receipt, label: "Ticket médio", value: formatCurrency(avgTicket) },
              { icon: CalendarDays, label: "Vendas no mês", value: String(monthCount) },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="sy-stat">
                <p className="lbl"><Icon /> {label}</p>
                <p className="val">{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Feed de hoje */}
        <div className="sy-panel sy-time">
          <div className="flex items-center justify-between pb-4 border-b border-[var(--sy-line)]">
            <p className="text-[15px] font-bold text-[var(--au-text)]">Linha do tempo de hoje</p>
            <span className="text-[11px] text-[var(--au-text-3)] tabular-nums">{todayCount} hoje</span>
          </div>
          {todaySales.length === 0 ? (
            <div className="empty">
              <div className="ring"><Radio /></div>
              <p className="text-[14px] text-[var(--au-text)] font-semibold mt-8">Aguardando a primeira venda do dia</p>
              <p className="text-[12.5px] text-[var(--au-text-3)] mt-1.5 max-w-[260px]">Assim que uma venda de hoje for registrada, ela aparece aqui.</p>
            </div>
          ) : (
            <ul className="au-scroll overflow-y-auto max-h-[360px] pr-1">
              <AnimatePresence initial={false}>
                {todaySales.map((s) => (
                  <motion.li key={s.id} layout initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}>
                    <span className="text-[11px] font-mono text-[var(--au-text-3)] w-11 shrink-0 tabular-nums">{timeOf(s)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[13.5px] font-semibold text-[var(--au-text)] truncate">{s.client_name}</p>
                      <p className="text-[11.5px] text-[var(--au-text-3)] truncate">{s.description || "—"}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-[14px] font-bold text-[var(--au-text)] tabular-nums">{formatCurrency(Number(s.amount))}</p>
                      <div className="mt-1">{statusPill(s.status)}</div>
                    </div>
                  </motion.li>
                ))}
              </AnimatePresence>
            </ul>
          )}
        </div>
      </div>

      {/* Todas as vendas */}
      <div className="sy-ledger">
        <div className="hd">
          <div className="flex items-baseline gap-3">
            <p className="text-[15px] font-bold text-[var(--au-text)]">Todas as vendas</p>
            <span className="text-[11px] text-[var(--au-text-3)] tabular-nums">{sales.length} no total</span>
          </div>
          <div className="sy-chips" role="tablist" aria-label="Filtrar por status">
            {([["todas", "Todas"], ["pago", "Pago"], ["pendente", "Pendente"], ["cancelado", "Cancelado"]] as const).map(([val, l]) => (
              <button key={val} type="button" role="tab" aria-selected={filter === val} className={cn(filter === val && "on")} onClick={() => setFilter(val)}>{l}</button>
            ))}
          </div>
        </div>
        {loading ? (
          <p className="text-center py-12 text-[var(--au-text-3)]">Carregando...</p>
        ) : shown.length === 0 ? (
          <p className="text-center py-12 text-[var(--au-text-3)]">Nenhuma venda registrada ainda</p>
        ) : (
          groups.map(([day, list]) => (
            <div key={day}>
              <div className="sy-day">
                <span>{fmtDate(day)}</span>
                <b>{formatCurrency(list.filter((s) => s.status !== "cancelado").reduce((sum, s) => sum + Number(s.amount), 0))}</b>
              </div>
              {list.map((sale) => (
                <div key={sale.id} className="sy-row group">
                  <span className="sy-ini">{initialsOf(sale.client_name)}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[14px] font-semibold text-[var(--au-text)] truncate">{sale.client_name}</p>
                    <p className="text-[12px] text-[var(--au-text-3)] truncate">{sale.description || "—"}</p>
                  </div>
                  <div className="hidden sm:block">{statusPill(sale.status)}</div>
                  <p className="text-[15px] font-bold text-[var(--au-text)] tabular-nums w-[104px] text-right shrink-0">{formatCurrency(Number(sale.amount))}</p>
                  <div className="sy-act flex gap-1.5 w-[74px] justify-end opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                    <button type="button" onClick={() => handleEdit(sale)} className="au-icon-btn" aria-label="Editar"><Edit2 /></button>
                    <button type="button" onClick={() => handleDelete(sale.id)} className="au-icon-btn hover:!text-red-400" aria-label="Excluir"><Trash2 /></button>
                  </div>
                </div>
              ))}
            </div>
          ))
        )}
      </div>
    </motion.div>
  );
};

export default VendasView;
