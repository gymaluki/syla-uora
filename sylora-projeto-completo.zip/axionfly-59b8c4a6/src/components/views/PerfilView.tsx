import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import "@/components/auren/admin/admin.css";
import "@/components/auren/perfil.css";
import { BladeRule } from "@/components/auren/fx/parts";
import { Loader2, User, Lock, History, Users2, Trash2, ExternalLink, Check, Calendar, CreditCard, Rocket, MapPin, Globe } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { CURRENCIES, useCurrency } from "@/lib/currency";

type TabId = "dados" | "senha" | "sites" | "historico" | "leads" | "integracoes";

const TABS: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: "dados", label: "Dados", icon: User },
  { id: "senha", label: "Senha", icon: Lock },
  { id: "sites", label: "Meus Sites", icon: Globe },
  { id: "historico", label: "Buscas", icon: History },
  { id: "leads", label: "Leads", icon: Users2 },
  { id: "integracoes", label: "Integrações", icon: ExternalLink },
];

interface SearchHistoryItem {
  id: string;
  query: string;
  nicho: string | null;
  location: string | null;
  results_count: number;
  created_at: string;
}

interface ContactedLeadItem {
  id: string;
  lead_name: string;
  phone: string | null;
  website: string | null;
  source_url: string | null;
  status: string;
  created_at: string;
}

const PerfilView = () => {
  const { code: currency, setCode: setCurrency } = useCurrency();
  const { user } = useAuth();
  const [tab, setTab] = useState<TabId>("dados");
  const [displayName, setDisplayName] = useState("");
  const [caktoClientId, setCaktoClientId] = useState("");
  const [caktoClientSecret, setCaktoClientSecret] = useState("");
  const [caktoProductImageUrl, setCaktoProductImageUrl] = useState("");
  const [hasCaktoCredentials, setHasCaktoCredentials] = useState(false);
  const [caktoCredentialsUpdatedAt, setCaktoCredentialsUpdatedAt] = useState<string | null>(null);
  const [savingName, setSavingName] = useState(false);
  const [savingCakto, setSavingCakto] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);

  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [leads, setLeads] = useState<ContactedLeadItem[]>([]);
  const [userSites, setUserSites] = useState<any[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!user) return;

    supabase.functions.invoke("manage-cakto-credentials", { method: "GET" }).then(({ data, error }) => {
      if (error) {
        console.error("Erro ao carregar integração Cakto:", error);
        return;
      }

      setDisplayName(data?.display_name ?? "");
      setCaktoProductImageUrl(data?.cakto_product_image_url ?? "");
      setHasCaktoCredentials(Boolean(data?.has_credentials));
      setCaktoCredentialsUpdatedAt(data?.credentials_updated_at ?? null);
      setCaktoClientId("");
      setCaktoClientSecret("");
    });

    const loadAll = async () => {
      setLoadingData(true);
      const [h, l, s] = await Promise.all([
        supabase
          .from("search_history")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(50),
        supabase
          .from("contacted_leads")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(100),
        supabase
          .from("user_sites")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false }),
      ]);
      if (h.data) setHistory(h.data as SearchHistoryItem[]);
      if (l.data) setLeads(l.data as ContactedLeadItem[]);
      if (s.data) setUserSites(s.data);
      setLoadingData(false);
    };
    loadAll();
  }, [user]);

  const handleSaveName = async () => {
    if (!user) return;
    setSavingName(true);
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: displayName.trim() || null })
      .eq("user_id", user.id);
    setSavingName(false);
    if (error) {
      toast.error("Erro ao salvar nome");
      return;
    }
    toast.success("Nome atualizado!");
  };

  const handleSaveCakto = async () => {
    if (!user) return;
    setSavingCakto(true);
    const { error } = await supabase.functions.invoke("manage-cakto-credentials", {
      body: {
        client_id: caktoClientId,
        client_secret: caktoClientSecret,
        cakto_product_image_url: caktoProductImageUrl,
      },
    });
    setSavingCakto(false);
    if (error) {
      toast.error("Erro ao salvar credenciais Cakto");
      return;
    }

    setHasCaktoCredentials(true);
    setCaktoCredentialsUpdatedAt(new Date().toISOString());
    setCaktoClientId("");
    setCaktoClientSecret("");
    toast.success("Credenciais Cakto atualizadas com segurança!");
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.email) return;

    if (newPassword.length < 6) {
      toast.error("A nova senha precisa ter pelo menos 6 caracteres");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("As senhas novas não coincidem");
      return;
    }

    setChangingPassword(true);

    // Verifica senha atual reautenticando
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPassword,
    });

    if (signInError) {
      toast.error("Senha atual incorreta");
      setChangingPassword(false);
      return;
    }

    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword,
    });

    setChangingPassword(false);

    if (updateError) {
      toast.error(updateError.message);
      return;
    }

    toast.success("Senha alterada com sucesso!");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const deleteHistory = async (id: string) => {
    const { error } = await supabase.from("search_history").delete().eq("id", id);
    if (error) {
      toast.error("Erro ao remover");
      return;
    }
    setHistory((h) => h.filter((x) => x.id !== id));
  };

  const deleteLead = async (id: string) => {
    const { error } = await supabase.from("contacted_leads").delete().eq("id", id);
    if (error) {
      toast.error("Erro ao remover");
      return;
    }
    setLeads((l) => l.filter((x) => x.id !== id));
  };

  const deleteSite = async (id: string) => {
    const { error } = await supabase.from("user_sites").delete().eq("id", id);
    if (error) {
      toast.error("Erro ao remover site");
      return;
    }
    setUserSites((s) => s.filter((x) => x.id !== id));
    toast.success("Site removido!");
  };

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });

  const initials = (displayName ? displayName : user?.email ?? "").slice(0, 2).toUpperCase();
  const since = (() => {
    const c = (user as { created_at?: string } | null)?.created_at;
    if (!c) return "Maio 2026";
    const t = new Date(c).toLocaleDateString("pt-BR", { month: "long", year: "numeric" }).replace(" de ", " ");
    return t.charAt(0).toUpperCase() + t.slice(1);
  })();

  const Loading = () => (
    <div className="ad-loading"><Loader2 className="w-6 h-6 animate-spin" style={{ color: "var(--au-silver)" }} /></div>
  );
  const Empty = ({ children }: { children: React.ReactNode }) => <div className="ad-empty">{children}</div>;
  const Trash = ({ onClick }: { onClick: () => void }) => (
    <button type="button" className="au-icon-btn" onClick={onClick} aria-label="Remover" title="Remover"><Trash2 /></button>
  );

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div><label className="au-label">{label}</label>{children}</div>
  );

  const current = TABS.find((t) => t.id === tab)!;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="pf-root"
    >
      {/* Identidade */}
      <section className="au-card pf-id">
        <div className="pf-mono">
          <div className="disc"><b>{initials}</b></div>
          <span className="on" aria-hidden />
        </div>
        <div style={{ minWidth: 0 }}>
          <h2 className="pf-name">{displayName || "Usuário"}</h2>
          <div className="pf-pills">
            <span className="pf-pill solid"><Check /> Membro Ativo</span>
            <span className="pf-pill">Plano Premium</span>
          </div>
        </div>
        <BladeRule width={190} className="pf-blade" />
      </section>

      {/* Resumo da conta */}
      <section className="au-card pf-strip-card">
        <div className="pf-strip-head"><Rocket /> Resumo da Conta</div>
        <div className="pf-strip">
          <div><div className="k"><Calendar /> Cadastro</div><div className="v">{since}</div></div>
          <div><div className="k"><CreditCard /> Status</div><div className="v ok">Ativo</div></div>
          <div><div className="k"><History /> Buscas</div><div className="v">{history.length}</div></div>
          <div><div className="k"><MapPin /> Leads</div><div className="v">{leads.length}</div></div>
        </div>
      </section>

      <div className="pf-body">
        {/* Trilho de seções: uma só navegação */}
        <nav className="au-card pf-rail" aria-label="Seções do perfil">
          {TABS.map((t) => {
            const Icon = t.icon;
            const on = tab === t.id;
            return (
              <button key={t.id} type="button" className={cn("pf-tab", on && "on")} onClick={() => setTab(t.id)} aria-current={on ? "page" : undefined}>
                {on && <motion.span layoutId="pf-tab-ind" className="pf-tab-ind" transition={{ type: "spring", stiffness: 480, damping: 40 }} />}
                <Icon /><span>{t.label}</span>
              </button>
            );
          })}
        </nav>

        <section className="au-card pf-pane">
          <div className="pf-pane-head"><current.icon /><h3>{current.label}</h3></div>
          <AnimatePresence mode="wait" initial={false}>
            <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.18 }}>

              {tab === "dados" && (
                <div className="pf-form">
                  <Field label="Email">
                    <input className="au-input" value={user?.email ?? ""} disabled readOnly />
                  </Field>
                  <Field label="Nome de exibição">
                    <input className="au-input" value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Seu nome" />
                  </Field>
                  <div>
                    <label className="au-label">Moeda de exibição</label>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                      {CURRENCIES.map((c) => (
                        <button
                          key={c.code}
                          type="button"
                          onClick={() => { setCurrency(c.code); toast.success(`Valores em ${c.label}`); }}
                          className={cn("au-chip", currency === c.code && "on")}
                          style={{ height: 38, fontSize: 11.5 }}
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                    <p className="pf-hint" style={{ marginTop: 10 }}>Muda só como os valores aparecem no Dashboard. As vendas continuam registradas em reais.</p>
                  </div>
                  <div>
                    <button type="button" className="au-btn au-btn-primary" onClick={handleSaveName} disabled={savingName}>
                      {savingName ? <Loader2 className="animate-spin" /> : null}
                      Salvar
                    </button>
                  </div>
                </div>
              )}

              {tab === "senha" && (
                <form onSubmit={handleChangePassword} className="pf-form">
                  <Field label="Senha atual">
                    <input className="au-input" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
                  </Field>
                  <Field label="Nova senha">
                    <input className="au-input" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={6} />
                  </Field>
                  <Field label="Confirmar nova senha">
                    <input className="au-input" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={6} />
                  </Field>
                  <div>
                    <button type="submit" className="au-btn au-btn-primary" disabled={changingPassword}>
                      {changingPassword ? <Loader2 className="animate-spin" /> : <Lock />}
                      Alterar senha
                    </button>
                  </div>
                  <p className="pf-hint">Se você se cadastrou com Google, não é possível alterar a senha por aqui.</p>
                </form>
              )}

              {tab === "sites" && (
                loadingData ? <Loading /> : userSites.length === 0 ? (
                  <Empty>Você ainda não criou nenhum site.</Empty>
                ) : (
                  <div className="ad-table-wrap">
                    <table className="ad-table" style={{ minWidth: 520 }}>
                      <thead><tr><th>Site</th><th>Nicho</th><th>Data</th><th /></tr></thead>
                      <tbody>
                        {userSites.map((s) => (
                          <tr key={s.id}>
                            <td>
                              <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                                {s.site_name}
                                {s.url && <a href={s.url} target="_blank" rel="noopener noreferrer" aria-label="Abrir site" style={{ color: "var(--au-silver)" }}><ExternalLink className="w-3 h-3" /></a>}
                              </span>
                            </td>
                            <td className="mut">{s.niche || "—"}</td>
                            <td className="mut">{formatDate(s.created_at)}</td>
                            <td className="r"><Trash onClick={() => deleteSite(s.id)} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              )}

              {tab === "historico" && (
                loadingData ? <Loading /> : history.length === 0 ? (
                  <Empty>Você ainda não fez nenhuma busca.</Empty>
                ) : (
                  <div className="ad-table-wrap">
                    <table className="ad-table" style={{ minWidth: 520 }}>
                      <thead><tr><th>Nicho</th><th>Local</th><th className="num">Resultados</th><th>Data</th><th /></tr></thead>
                      <tbody>
                        {history.map((h) => (
                          <tr key={h.id}>
                            <td>{h.nicho || "—"}</td>
                            <td className="mut">{h.location || "—"}</td>
                            <td className="num">{h.results_count}</td>
                            <td className="mut">{formatDate(h.created_at)}</td>
                            <td className="r"><Trash onClick={() => deleteHistory(h.id)} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              )}

              {tab === "leads" && (
                loadingData ? <Loading /> : leads.length === 0 ? (
                  <Empty>Nenhum lead contatado ainda. Marque leads como contatados na Busca de Leads.</Empty>
                ) : (
                  <div className="ad-table-wrap">
                    <table className="ad-table" style={{ minWidth: 560 }}>
                      <thead><tr><th>Negócio</th><th>Telefone</th><th>Status</th><th>Data</th><th /></tr></thead>
                      <tbody>
                        {leads.map((l) => (
                          <tr key={l.id}>
                            <td>
                              <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                                {l.lead_name}
                                {l.source_url && <a href={l.source_url} target="_blank" rel="noopener noreferrer" aria-label="Abrir origem" style={{ color: "var(--au-text-3)" }}><ExternalLink className="w-3 h-3" /></a>}
                              </span>
                            </td>
                            <td>{l.phone || "—"}</td>
                            <td className="mut">{l.status}</td>
                            <td className="mut">{formatDate(l.created_at)}</td>
                            <td className="r"><Trash onClick={() => deleteLead(l.id)} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              )}

              {tab === "integracoes" && (
                <div className="pf-form" style={{ maxWidth: 520 }}>
                  <div>
                    <h4 style={{ fontFamily: "var(--au-font-display)", fontSize: 16, fontWeight: 600 }}>Cakto API</h4>
                    <p className="pf-hint" style={{ marginTop: 8, fontSize: 13, color: "var(--au-text-2)" }}>
                      Insira suas credenciais da Cakto para que possamos automatizar a criação de seus produtos.
                      Elas serão guardadas em uma área protegida do backend e não ficam mais visíveis no seu perfil.
                    </p>
                  </div>

                  {hasCaktoCredentials ? (
                    <div className="ad-note">
                      <Check />
                      <div>
                        <b>Credenciais já configuradas</b>
                        <div style={{ marginTop: 4 }}>
                          Por segurança, o segredo atual não é exibido aqui.
                          {caktoCredentialsUpdatedAt ? ` Última atualização: ${formatDate(caktoCredentialsUpdatedAt)}.` : ""}
                        </div>
                        <div style={{ marginTop: 4 }}>Preencha novamente os campos abaixo somente se quiser substituir as credenciais atuais.</div>
                      </div>
                    </div>
                  ) : null}

                  <Field label="Client ID">
                    <input className="au-input" value={caktoClientId} onChange={(e) => setCaktoClientId(e.target.value)} placeholder={hasCaktoCredentials ? "Novo Client ID" : "Seu Client ID"} />
                  </Field>
                  <Field label="Client Secret">
                    <input className="au-input" type="password" value={caktoClientSecret} onChange={(e) => setCaktoClientSecret(e.target.value)} placeholder={hasCaktoCredentials ? "Novo Client Secret" : "Seu Client Secret"} />
                  </Field>
                  <div>
                    <Field label="URL da Imagem do Produto (Opcional)">
                      <input className="au-input" value={caktoProductImageUrl} onChange={(e) => setCaktoProductImageUrl(e.target.value)} placeholder="https://exemplo.com/imagem.jpg" />
                    </Field>
                    <p className="pf-hint" style={{ marginTop: 8 }}>Link da imagem que aparecerá no checkout da Cakto.</p>
                  </div>
                  <div>
                    <button type="button" className="au-btn au-btn-primary" onClick={handleSaveCakto} disabled={savingCakto}>
                      {savingCakto ? <Loader2 className="animate-spin" /> : <Check />}
                      {hasCaktoCredentials ? "Atualizar Credenciais" : "Salvar Credenciais"}
                    </button>
                  </div>
                  <div className="ad-note"><ExternalLink /><div>As chaves são usadas apenas para autenticar chamadas à API da Cakto em seu nome.</div></div>
                </div>
              )}

            </motion.div>
          </AnimatePresence>
        </section>
      </div>

      <p className="pf-foot">Sylora Premium v1.4</p>
    </motion.div>
  );
};

export default PerfilView;
