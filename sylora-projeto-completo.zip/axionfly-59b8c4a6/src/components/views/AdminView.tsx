import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Activity, AlertCircle, BarChart3, Bug, Clock, CreditCard, Crown, Film, Globe, History, KeyRound, Lock,
  Mail, Megaphone, Bell, SlidersHorizontal, Link2, Type, MessageSquare, ShieldCheck, ShieldX, Target, Trophy, Users, Cloud,
} from "lucide-react";
import { adminApi } from "@/lib/adminData";
import type { AdminUser, PendingPayment } from "@/lib/adminTypes";
import { Btn, Loading } from "@/components/auren/admin/ui";
import { AdminsPanel, PendingPanel, ProtocoloAdminPanel, UsersPanel } from "@/components/auren/admin/UserPanels";
import { AffiliatesPanel, CaktoEmailsPanel, MetaPanel } from "@/components/auren/admin/SalesPanels";
import { MentorLogsPanel, TopQuestionsPanel, UsagePanel } from "@/components/auren/admin/UsagePanels";
import { AuditPanel, LicensesPanel } from "@/components/auren/admin/LicensePanels";
import { CloudPanel, DomainPanel, LandingPanel, SystemPanel } from "@/components/auren/admin/SettingsPanels";
import { RafflePanel } from "@/components/auren/admin/RafflePanel";
import { BuilderPanel } from "@/components/auren/admin/BuilderPanel";
import { NoticePanel, PlansPanel, SiteTextPanel } from "@/components/auren/admin/SitePanels";
import "@/components/auren/admin/admin.css";

type TabId =
  | "users" | "meta" | "usage" | "protocolo" | "admins" | "cakto" | "pending" | "affiliates" | "licenses"
  | "audit" | "landing" | "sitetext" | "builder" | "plans" | "notice" | "domain" | "mentor" | "top" | "raffle" | "cloud" | "system";

const TABS: { id: TabId; label: string; icon: React.ElementType; owner?: boolean }[] = [
  { id: "users", label: "Usuários", icon: Users },
  { id: "meta", label: "Meta 50K", icon: Target },
  { id: "usage", label: "Prova de uso", icon: Activity },
  { id: "protocolo", label: "Protocolo", icon: ShieldCheck },
  { id: "admins", label: "Admins", icon: Crown, owner: true },
  { id: "cakto", label: "E-mails Cakto", icon: Mail },
  { id: "pending", label: "Pendentes", icon: Clock },
  { id: "affiliates", label: "Afiliados", icon: Megaphone },
  { id: "licenses", label: "Licenças", icon: KeyRound },
  { id: "audit", label: "Auditoria", icon: History },
  { id: "landing", label: "Landing Page", icon: Film },
  { id: "sitetext", label: "Textos do site", icon: Type },
  { id: "plans", label: "Planos e checkout", icon: Link2 },
  { id: "builder", label: "Criar Site ou App", icon: SlidersHorizontal },
  { id: "notice", label: "Aviso aos membros", icon: Bell },
  { id: "domain", label: "Aviso Domínio", icon: Globe },
  { id: "mentor", label: "Mentor IA", icon: MessageSquare },
  { id: "top", label: "Dúvidas TOP", icon: BarChart3 },
  { id: "raffle", label: "Sorteio", icon: Trophy },
  { id: "cloud", label: "Cloud", icon: Cloud, owner: true },
  { id: "system", label: "Sistema", icon: Bug, owner: true },
];

type Gate = "checking" | "ok" | "denied" | "error";

const AdminView = ({ onShowTour }: { onShowTour?: () => void }) => {
  const [gate, setGate] = useState<Gate>("checking");
  const [gateMsg, setGateMsg] = useState("");
  const [isOwner, setIsOwner] = useState(false);
  const [tab, setTab] = useState<TabId>("users");
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [pendings, setPendings] = useState<PendingPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [auditKey, setAuditKey] = useState(0);
  const alive = useRef(true);

  const verify = useCallback(async () => {
    setGate("checking");
    setGateMsg("");
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const timeout = new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new Error("A verificação demorou demais.")), 8000); });
      const ok = await Promise.race([adminApi.isAdmin(), timeout]);
      if (!alive.current) return;
      if (!ok) { setGate("denied"); return; }
      setGate("ok");
      adminApi.isOwner().then((o) => alive.current && setIsOwner(o)).catch(() => undefined);
    } catch (e) {
      if (!alive.current) return;
      setGateMsg(e instanceof Error ? e.message : "Erro ao verificar o acesso.");
      setGate("error");
    } finally {
      if (timer) clearTimeout(timer);
    }
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await adminApi.list();
      if (!alive.current) return;
      setUsers(d.users);
      setPendings(d.pendings);
    } catch (e) {
      console.error(e);
    } finally {
      if (alive.current) setLoading(false);
    }
  }, []);

  useEffect(() => { alive.current = true; void verify(); return () => { alive.current = false; }; }, [verify]);
  useEffect(() => { if (gate === "ok") void load(); }, [gate, load]);

  if (gate === "checking") return <Loading />;
  if (gate !== "ok") {
    return (
      <div className="ad-gate">
        <div className="au-icon-box" style={{ width: 64, height: 64, borderRadius: 20, margin: "0 auto" }}>
          {gate === "denied" ? <ShieldX style={{ width: 28, height: 28 }} /> : <AlertCircle style={{ width: 28, height: 28 }} />}
        </div>
        <h2>{gate === "denied" ? "Acesso negado" : "Não foi possível verificar o acesso"}</h2>
        <p>{gate === "denied" ? "Esta área é só para administradores." : gateMsg || "Tente novamente em instantes."}</p>
        {gate === "error" && <div style={{ marginTop: 18 }}><Btn variant="primary" onClick={verify}>Tentar de novo</Btn></div>}
      </div>
    );
  }

  const active = users.filter((u) => u.subscription?.status === "active").length;
  const activePending = pendings.filter((p) => p.status === "active").length;
  const processed = pendings.filter((p) => p.status === "processed").length;
  const tabs = TABS.filter((t) => !t.owner || isOwner);
  const current = tabs.some((t) => t.id === tab) ? tab : "users";
  const firstOwner = tabs.findIndex((t) => t.owner);

  const stats = [
    { n: active, l: "Assinaturas ativas", i: Users },
    { n: users.length - active, l: "Sem acesso", i: AlertCircle },
    { n: activePending, l: "Pré-pagamentos", i: Clock },
    { n: processed, l: "Já ativados", i: CreditCard },
  ];

  const common = { users, reload: load, busy: loading };

  return (
    <div className="ad-root">
      <div className="ad-stats">
        {stats.map((s) => (
          <div key={s.l} className="au-card ad-stat">
            <div className="au-icon-box"><s.i /></div>
            <div><b>{loading && users.length === 0 ? "–" : s.n}</b><span>{s.l}</span></div>
          </div>
        ))}
      </div>

      <div className="ad-tabs-wrap">
        <div className="ad-tabs" role="tablist" aria-label="Seções do painel administrativo">
          {tabs.map((t, i) => {
            const I = t.icon;
            const on = t.id === current;
            return (
              <span key={t.id} style={{ display: "contents" }}>
                {i === firstOwner && firstOwner > 0 && <span className="ad-tab-sep" aria-hidden />}
                <button type="button" role="tab" aria-selected={on} className={"ad-tab" + (on ? " on" : "") + (t.owner ? " owner" : "")} onClick={(e) => { setTab(t.id); e.currentTarget.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" }); }}>
                  {t.owner ? <Lock /> : <I />}
                  {t.label}
                  {t.id === "users" && <span className="n">{users.length}</span>}
                  {t.id === "pending" && <span className="n">{pendings.length}</span>}
                  {on && <motion.span layoutId="ad-tab-ind" className="ad-tab-ind" transition={{ type: "spring", stiffness: 480, damping: 40 }} />}
                </button>
              </span>
            );
          })}
        </div>
      </div>

      <motion.div key={current} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.22 }}>
        {current === "users" && <UsersPanel {...common} />}
        {current === "meta" && <MetaPanel users={users} />}
        {current === "usage" && <UsagePanel />}
        {current === "protocolo" && <ProtocoloAdminPanel {...common} />}
        {current === "admins" && isOwner && <AdminsPanel {...common} />}
        {current === "cakto" && <CaktoEmailsPanel pendings={pendings} />}
        {current === "pending" && <PendingPanel pendings={pendings} reload={load} busy={loading} />}
        {current === "affiliates" && <AffiliatesPanel />}
        {current === "licenses" && <LicensesPanel users={users} onTested={() => setAuditKey((k) => k + 1)} />}
        {current === "audit" && <AuditPanel users={users} refreshKey={auditKey} />}
        {current === "landing" && <LandingPanel />}
        {current === "sitetext" && <SiteTextPanel />}
        {current === "plans" && <PlansPanel />}
        {current === "builder" && <BuilderPanel />}
        {current === "notice" && <NoticePanel />}
        {current === "domain" && <DomainPanel />}
        {current === "mentor" && <MentorLogsPanel />}
        {current === "top" && <TopQuestionsPanel />}
        {current === "raffle" && <RafflePanel onShowTour={() => onShowTour?.()} />}
        {current === "cloud" && isOwner && <CloudPanel users={users} />}
        {current === "system" && isOwner && <SystemPanel />}
      </motion.div>
    </div>
  );
};

export default AdminView;
