import { useState, useEffect, useRef, useMemo } from "react";
import {
  Loader2, ExternalLink, Download, MessageCircle, MapPin, Search,
  Scissors, Pizza, Sandwich, Sparkles, Stethoscope, Building2,
  Dumbbell, PawPrint, UtensilsCrossed, Wrench, Smile, Wand2,
  Home, Scale, Calculator, BookOpen, ShoppingBag, Pill, Glasses,
  Flower2, Car, Camera, RotateCcw,
} from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { firecrawlApi } from "@/lib/api/firecrawl";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type LucideIcon = typeof Scissors;

const nichos: { label: string; Icon: LucideIcon }[] = [
  { label: "Barbearias", Icon: Scissors },
  { label: "Pizzarias", Icon: Pizza },
  { label: "Hamburguerias", Icon: Sandwich },
  { label: "Açaiteria", Icon: UtensilsCrossed },
  { label: "Manicures", Icon: Sparkles },
  { label: "Dentistas", Icon: Stethoscope },
  { label: "Clínicas", Icon: Building2 },
  { label: "Academias", Icon: Dumbbell },
  { label: "Pet Shops", Icon: PawPrint },
  { label: "Restaurantes", Icon: UtensilsCrossed },
  { label: "Mecânicas", Icon: Wrench },
  { label: "Salões de Beleza", Icon: Smile },
  { label: "Estética", Icon: Wand2 },
  { label: "Imobiliárias", Icon: Home },
  { label: "Advogados", Icon: Scale },
  { label: "Contadores", Icon: Calculator },
  { label: "Escolas de Idiomas", Icon: BookOpen },
  { label: "Assistência Técnica", Icon: Wrench },
  { label: "Padarias", Icon: ShoppingBag },
  { label: "Farmácias", Icon: Pill },
  { label: "Óticas", Icon: Glasses },
  { label: "Floricultura", Icon: Flower2 },
  { label: "Lava Jato", Icon: Car },
  { label: "Fotógrafos", Icon: Camera },
];

// Todos os países (código ISO), com o nome em português gerado pelo navegador.
const PAISES_ISO = "AF AL DZ AS AD AO AI AQ AG AR AM AW AU AT AZ BS BH BD BB BY BE BZ BJ BM BT BO BA BW BR IO VG BN BG BF BI KH CM CA CV BQ KY CF TD CL CN CX CC CO KM CG CD CK CR CI HR CU CW CY CZ DK DJ DM DO EC EG SV GQ ER EE SZ ET FK FO FJ FI FR GF PF GA GM GE DE GH GI GR GL GD GP GU GT GG GN GW GY HT HN HK HU IS IN ID IR IQ IE IM IL IT JM JP JE JO KZ KE KI XK KW KG LA LV LB LS LR LY LI LT LU MO MG MW MY MV ML MT MH MQ MR MU YT MX FM MD MC MN ME MS MA MZ MM NA NR NP NL NC NZ NI NE NG NU KP MK MP NO OM PK PW PS PA PG PY PE PH PL PT PR QA RE RO RU RW WS SM ST SA SN RS SC SL SG SX SK SI SB SO ZA KR SS ES LK BL SH KN LC MF PM VC SD SR SE CH SY TW TJ TZ TH TL TG TK TO TT TN TR TM TC TV VI UG UA AE GB US UY UZ VU VA VE VN WF EH YE ZM ZW".split(" ");

const nomePais = (code: string) => {
  try { return new Intl.DisplayNames(["pt-BR"], { type: "region" }).of(code) || code; } catch { return code; }
};

const estados = [
  { sigla: "AC", nome: "Acre" }, { sigla: "AL", nome: "Alagoas" }, { sigla: "AP", nome: "Amapá" },
  { sigla: "AM", nome: "Amazonas" }, { sigla: "BA", nome: "Bahia" }, { sigla: "CE", nome: "Ceará" },
  { sigla: "DF", nome: "Distrito Federal" }, { sigla: "ES", nome: "Espírito Santo" },
  { sigla: "GO", nome: "Goiás" }, { sigla: "MA", nome: "Maranhão" }, { sigla: "MT", nome: "Mato Grosso" },
  { sigla: "MS", nome: "Mato Grosso do Sul" }, { sigla: "MG", nome: "Minas Gerais" },
  { sigla: "PA", nome: "Pará" }, { sigla: "PB", nome: "Paraíba" }, { sigla: "PR", nome: "Paraná" },
  { sigla: "PE", nome: "Pernambuco" }, { sigla: "PI", nome: "Piauí" }, { sigla: "RJ", nome: "Rio de Janeiro" },
  { sigla: "RN", nome: "Rio Grande do Norte" }, { sigla: "RS", nome: "Rio Grande do Sul" },
  { sigla: "RO", nome: "Rondônia" }, { sigla: "RR", nome: "Roraima" }, { sigla: "SC", nome: "Santa Catarina" },
  { sigla: "SP", nome: "São Paulo" }, { sigla: "SE", nome: "Sergipe" }, { sigla: "TO", nome: "Tocantins" },
];

interface SearchResult {
  url: string;
  title: string;
  description: string;
  phone: string | null;
}

const extractPhone = (text: string): string | null => {
  const patterns = [
    /\(?\d{2}\)?\s*9?\d{4}[-.\s]?\d{4}/,
    /\+55\s*\(?\d{2}\)?\s*9?\d{4}[-.\s]?\d{4}/,
  ];
  for (const p of patterns) {
    const match = text.match(p);
    if (match) return match[0].trim();
  }
  return null;
};

const openExternalLink = (url: string) => {
  const w = window.open(url, "_blank", "noopener,noreferrer");
  if (w) w.opener = null;
};

interface ProspeccaoViewProps {
  lockedNicho?: string; // label exato do nicho (ex.: "Pizzarias"); quando fornecido, esconde a grade de nichos
}

const ProspeccaoView = ({ lockedNicho }: ProspeccaoViewProps = {}) => {
  const [pais, setPais] = useState("BR");
  const [cidade, setCidade] = useState("");
  const [estado, setEstado] = useState("");
  const paises = useMemo(() => PAISES_ISO.map((c) => ({ code: c, nome: nomePais(c) })).sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR")), []);
  const isBR = pais === "BR";
  const [cidades, setCidades] = useState<string[]>([]);
  const [loadingCidades, setLoadingCidades] = useState(false);
  const [activeFilter, setActiveFilter] = useState(lockedNicho || "");
  const [searchMode, setSearchMode] = useState<"automatic" | "manual">("automatic");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [manualRedirectUrl, setManualRedirectUrl] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);

  // Mantém o filtro travado em sincronia caso o pai mude o nicho
  useEffect(() => {
    if (lockedNicho && lockedNicho !== activeFilter) {
      setActiveFilter(lockedNicho);
      setResults([]);
      setSearched(false);
    }
  }, [lockedNicho]); // eslint-disable-line

  const hydratedRef = useRef(false);
  const userInteractedRef = useRef(false);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { hydratedRef.current = true; return; }
      const saved = localStorage.getItem(`prospeccao-view-state-${user.id}`);
      if (saved && !userInteractedRef.current) {
        try {
          const s = JSON.parse(saved);
          setPais(s.pais || "BR");
          setCidade(s.cidade || "");
          setEstado(s.estado || "");
          if (!lockedNicho) setActiveFilter(s.activeFilter || "");
          setSearchMode(s.searchMode || "automatic");
          setResults(s.results || []);
          setSearched(s.searched || false);
        } catch {}
      }
      hydratedRef.current = true;
    };
    load();
  }, []);

  useEffect(() => {
    if (!hydratedRef.current) return;
    const save = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      localStorage.setItem(
        `prospeccao-view-state-${user.id}`,
        JSON.stringify({ pais, cidade, estado, activeFilter, results, searched, searchMode })
      );
    };
    save();
  }, [pais, cidade, estado, activeFilter, results, searched, searchMode]);

  // Lista de cidades embutida no app (carrega só quando precisa), sem depender de API externa.
  useEffect(() => {
    if (!isBR || !estado || estado === "todos") { setCidades([]); return; }
    let vivo = true;
    setLoadingCidades(true);
    import("@/data-cidades-br.json")
      .then((m) => { if (vivo) setCidades(((m.default as Record<string, string[]>)[estado]) || []); })
      .catch(() => { if (vivo) setCidades([]); })
      .finally(() => { if (vivo) setLoadingCidades(false); });
    return () => { vivo = false; };
  }, [estado, isBR]);

  const buildLocation = () => {
    const parts: string[] = [];
    if (isBR) {
      if (cidade && cidade !== "todas") parts.push(cidade);
      if (estado && estado !== "todos") {
        const est = estados.find(e => e.sigla === estado);
        if (est) parts.push(est.nome);
      }
      parts.push("Brasil");
    } else {
      if (cidade.trim()) parts.push(cidade.trim());
      if (estado.trim()) parts.push(estado.trim());
      parts.push(nomePais(pais));
    }
    return parts.join(", ");
  };

  const doSearch = async (nicho: string) => {
    if (!nicho.trim()) return;
    const location = buildLocation();
    const query = `${nicho} em ${location}`.trim();
    setLoading(true);
    setSearched(true);
    setResults([]);
    try {
      const response = await firecrawlApi.search(query, { limit: 15, lang: "pt-br", country: "br" });
      if (response.success && Array.isArray(response.data)) {
        const mapped: SearchResult[] = (response.data as any[]).map((item: any) => {
          const allText = `${item.description || ""} ${item.markdown || ""}`;
          return {
            url: item.url || "",
            title: item.title || "Sem título",
            description: item.description || "",
            phone: extractPhone(allText),
          };
        });
        setResults(mapped);
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from("search_history").insert({
            user_id: user.id, query, nicho, location, results_count: mapped.length,
          });
        }
      } else {
        toast.error(response.error || "Nenhum resultado encontrado");
      }
    } catch (err) {
      console.error(err);
      toast.error("Erro ao buscar leads. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (!activeFilter) { 
      toast.error("Selecione um nicho antes de buscar"); 
      return; 
    }
    
    if (searchMode === "manual") {
      setLoading(true);
      setSearched(true);
      setManualRedirectUrl(null);
      
      const location = buildLocation();
      const query = `${activeFilter} em ${location}`.trim();
      const mapsUrl = `https://www.google.com/maps/search/${encodeURIComponent(query)}`;
      
      // Salva no histórico antes de redirecionar
      const saveToHistory = async () => {
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase.from("search_history").insert({
              user_id: user.id, 
              query, 
              nicho: activeFilter, 
              location, 
              results_count: 0,
              search_mode: "manual"
            });
          }
        } catch (err) {
          console.error("Erro ao salvar histórico manual:", err);
        }
      };
      
      saveToHistory();

      // Redirecionamento imediato para melhor UX
      const win = window.open(mapsUrl, "_blank", "noopener,noreferrer");
      
      if (win) {
        toast.success("Abrindo Google Maps...");
        setTimeout(() => setLoading(false), 1000);
      } else {
        // Fallback se o popup for bloqueado
        setManualRedirectUrl(mapsUrl);
        setLoading(false);
        toast.error("O navegador bloqueou a abertura automática do Google Maps.");
      }
      return;
    }
    
    doSearch(activeFilter);
  };

  const extractDomain = (url: string) => {
    try { return new URL(url).hostname.replace("www.", ""); } catch { return url; }
  };

  const handleExportCSV = () => {
    if (!results.length) return;
    const header = ["Negócio", "Site", "Descrição", "Telefone", "URL"];
    const rows = results.map(r => [
      r.title, extractDomain(r.url), r.description.replace(/[\r\n,]/g, " "),
      r.phone || "", r.url,
    ].map(v => `"${String(v).replace(/"/g, '""')}"`).join(","));
    const csv = [header.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `leads-${activeFilter || "sylora"}-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exportado!");
  };

  const cidadeDisabled = isBR && (!estado || estado === "todos");
  const activeNicho = nichos.find(n => n.label === activeFilter);

  const handleSelectNicho = (label: string) => {
    userInteractedRef.current = true;
    if (activeFilter === label) return;
    setActiveFilter(label);
    setResults([]);
    setSearched(false);
  };

  const handleClearNicho = () => {
    userInteractedRef.current = true;
    setActiveFilter("");
    setResults([]);
    setSearched(false);
    setPais("BR");
    setEstado("");
    setCidade("");
    toast.info("Pesquisa reiniciada");
  };

  return (
    <div
      className="prospeccao-root -m-4 md:-m-8 min-h-[calc(100vh-64px)]"
      style={{ background: "#05050A", color: "#FFFFFF" }}
    >
      <style>{`
        .pp-scroll::-webkit-scrollbar { width: 6px; height: 6px; }
        .pp-scroll::-webkit-scrollbar-track { background: transparent; }
        .pp-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.06); border-radius: 10px; }
        .pp-scroll::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.12); }

        .nicho-card { transition: all 160ms ease; }
        .nicho-card:hover:not([data-selected="true"]) {
          background: #111118 !important;
          border-color: rgba(var(--q-accent-rgb, 36,99,235),0.3) !important;
          box-shadow: 0 0 0 1px rgba(var(--q-accent-rgb, 36,99,235),0.1);
        }
        .nicho-card:hover:not([data-selected="true"]) .nicho-icon { color: var(--q-accent, #2463EB) !important; }
        .nicho-card:hover:not([data-selected="true"]) span { color: #FFFFFF !important; }

        @keyframes pulse-blue {
          0% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.4); opacity: 0.4; }
          100% { transform: scale(1); opacity: 1; }
        }
        .pulse-dot {
          animation: pulse-blue 2s infinite;
        }

        .row-result { transition: all 120ms ease-out; }
        .row-result:hover { background: #0D0D12 !important; }

        .btn-buscar { transition: all 160ms ease; position: relative; overflow: hidden; }
        .btn-buscar:not(:disabled):hover {
          background: var(--q-accent-hover, #2F6EED) !important;
          box-shadow: 0 4px 20px rgba(var(--q-accent-rgb, 36,99,235),0.35);
        }
        .btn-buscar:not(:disabled):active { transform: scale(0.97); background: var(--q-accent-active, #1D4ED8) !important; }
        
        .btn-buscar::after {
          content: "";
          position: absolute;
          top: 0; left: -100%;
          width: 50%; height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent);
          transition: none;
        }
        .btn-buscar:hover::after {
          left: 100%;
          transition: left 500ms linear;
        }

        .pp-select-trigger {
          background: #0D0D12 !important;
          border: 1px solid rgba(255,255,255,0.08) !important;
          color: #FFFFFF !important;
          height: 42px !important;
          border-radius: 8px !important;
          font-size: 14px !important;
          transition: all 160ms ease !important;
        }
        .pp-select-trigger:focus, .pp-select-trigger[data-state="open"] {
          border-color: var(--q-accent, #2463EB) !important;
          outline: none !important;
          box-shadow: 0 0 0 3px rgba(var(--q-accent-rgb, 36,99,235),0.12) !important;
        }

        @keyframes skel-shimmer {
          0% { background-position: -400% 0; }
          100% { background-position: 400% 0; }
        }
        .skel {
          background: linear-gradient(90deg, #0D0D12 0%, #16161E 50%, #0D0D12 100%);
          background-size: 400% 100%;
          animation: skel-shimmer 2s ease infinite;
          border-radius: 8px;
        }

        @keyframes scan-line {
          0% { top: 0; opacity: 0; }
          5% { opacity: 0.5; }
          50% { opacity: 0.8; }
          95% { opacity: 0.5; }
          100% { top: 100%; opacity: 0; }
        }
        .scanner-line {
          position: absolute;
          left: 0;
          width: 100%;
          height: 2px;
          background: linear-gradient(90deg, transparent, var(--q-accent, #2463EB), transparent);
          box-shadow: 0 0 15px var(--q-accent, #2463EB);
          animation: scan-line 2.5s ease-in-out infinite;
          z-index: 10;
        }

      `}</style>

      {/* HEADER — escondido quando embutido no construtor (nicho travado) */}
      {!lockedNicho && (
      <div
        className="px-6 pt-6 pb-5 flex items-start justify-between"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
      >
        <div>
          <h1 className="text-[22px] font-bold leading-tight" style={{ color: "#FFFFFF" }}>
            Prospecção de <span style={{ color: "var(--q-accent, #2463EB)" }}>Clientes</span>
          </h1>
          <p className="text-[13px] mt-1" style={{ color: "#6B7280" }}>
            Selecione um nicho para começar
          </p>
        </div>
        <div className="flex items-center gap-2">
          {["50k+ Empresas", "22 Nichos", "27 Estados"].map((pill) => (
            <div
              key={pill}
              className="px-2.5 py-1 rounded-full border flex items-center justify-center"
              style={{
                background: "rgba(var(--q-accent-rgb, 36,99,235),0.1)",
                borderColor: "rgba(var(--q-accent-rgb, 36,99,235),0.2)",
              }}
            >
              <span style={{ color: "var(--q-accent, #2463EB)", fontSize: 11, fontWeight: 700, letterSpacing: "-0.01em" }}>
                {pill}
              </span>
            </div>
          ))}
        </div>
      </div>
      )}

      {/* GRID DE NICHOS — escondido quando o nicho vem travado do quiz */}
      {!lockedNicho && (
      <div className="px-6 py-6">
        <div
          className="grid gap-2"
          style={{ gridTemplateColumns: "repeat(5, minmax(0, 1fr))" }}
        >
          {nichos.map((n, idx) => {
            const selected = activeFilter === n.label;
            const Icon = n.Icon;
            return (
              <motion.button
                key={n.label}
                type="button"
                onClick={() => handleSelectNicho(n.label)}
                data-selected={selected}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, ease: "easeOut", delay: idx * 0.018 }}
                className="nicho-card relative flex items-center text-left"
                style={{
                  height: 52,
                  padding: "0 14px",
                  gap: 10,
                  borderRadius: 10,
                  background: selected 
                    ? "linear-gradient(135deg, #0F1629 0%, #0a1220 100%)" 
                    : "#0D0D12",
                  border: selected
                    ? "1px solid var(--q-accent, #2463EB)"
                    : "1px solid rgba(255,255,255,0.07)",
                  boxShadow: selected 
                    ? "0 0 0 1px rgba(var(--q-accent-rgb, 36,99,235),0.2), 0 4px 24px rgba(var(--q-accent-rgb, 36,99,235),0.15)" 
                    : "none",
                  borderLeft: selected ? "3px solid var(--q-accent, #2463EB)" : "1px solid rgba(255,255,255,0.07)",
                  paddingLeft: selected ? 12 : 14,
                }}
              >
                <Icon
                  className="nicho-icon shrink-0"
                  size={15}
                  strokeWidth={1.5}
                  color="currentColor" style={{ color: selected ? "var(--q-accent, #2463EB)" : "#374151" }}
                />
                <span
                  className="truncate"
                  style={{
                    fontSize: 13,
                    fontWeight: selected ? 700 : 500,
                    color: selected ? "#FFFFFF" : "#9CA3AF",
                  }}
                >
                  {n.label}
                </span>
                {selected && (
                  <div 
                    className="pulse-dot absolute top-2 right-2 w-[5px] h-[5px] rounded-full"
                    style={{ background: "var(--q-accent, #2463EB)" }}
                  />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
      )}

      {/* SEÇÃO DE RESULTADOS (acordeão) */}
      <AnimatePresence initial={false}>
        {activeNicho && (
          <motion.section
            key="results-section"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.38, ease: [0.16, 1, 0.3, 1] }}
            style={{ overflow: "hidden" }}
          >
            {/* BARRA DE CONTEXTO */}
            <div
              className="flex items-center justify-between px-6"
              style={{
                height: 52,
                background: "#0D0D12",
                borderTop: "2px solid var(--q-accent, #2463EB)",
                borderBottom: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div className="flex items-center gap-3">
                <activeNicho.Icon size={16} strokeWidth={1.5} color="currentColor" style={{ color: "var(--q-accent, #2463EB)" }} />
                <span className="text-[15px] font-bold" style={{ color: "#FFFFFF" }}>
                  {activeNicho.label}
                </span>
                <div 
                  className="px-2 py-0.5 rounded-full border flex items-center justify-center ml-1"
                  style={{
                    background: "rgba(var(--q-accent-rgb, 36,99,235),0.1)",
                    borderColor: "rgba(var(--q-accent-rgb, 36,99,235),0.2)",
                  }}
                >
                  <span style={{ color: "var(--q-accent, #2463EB)", fontSize: 11, fontWeight: 700 }}>
                    Selecionado
                  </span>
                </div>
              </div>
              {!lockedNicho && (
                <button
                  type="button"
                  onClick={handleClearNicho}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg border border-[var(--au-border)] hover:border-[var(--au-border-strong)] transition-all group"
                  style={{ fontSize: 12, color: "#6B7280", background: "transparent" }}
                >
                  <RotateCcw size={12} className="group-hover:text-[var(--au-text)] transition-colors" />
                  <span className="group-hover:text-[var(--au-text)] transition-colors">Reiniciar pesquisa</span>
                </button>
              )}
            </div>

            {/* MODOS DE BUSCA */}
            <div className="px-6 pt-4 flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <span className="uppercase tracking-[0.12em] font-bold" style={{ fontSize: 10, color: "#6B7280" }}>Modo:</span>
                <div className="flex p-1 rounded-lg" style={{ background: "#0D0D12", border: "1px solid rgba(255,255,255,0.06)" }}>
                  {([["automatic", "API Inteligente (Auto)"], ["manual", "Pesquisa Manual (Maps)"]] as const).map(([mode, label]) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setSearchMode(mode)}
                      className="px-4 py-1.5 rounded-md transition-all"
                      style={{
                        background: searchMode === mode ? "var(--q-accent, #2463EB)" : "transparent",
                        color: searchMode === mode ? "var(--q-on-accent, #FFFFFF)" : "#9CA3AF",
                        fontSize: 13,
                        fontWeight: searchMode === mode ? 700 : 500,
                      }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
              <span className="flex items-center gap-1.5 uppercase font-bold" style={{ fontSize: 10, letterSpacing: "0.04em", color: "#22c55e" }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "#22c55e" }} />
                API gratuita ativa
              </span>
            </div>

            {/* FILTROS DE LOCALIZAÇÃO */}
            <div className="px-6 py-5" style={{ background: "#05050A" }}>
              <div className="flex flex-wrap items-end gap-3">
                <div style={{ flex: "1 1 120px", minWidth: 0 }}>
                  <label
                    className="block uppercase tracking-[0.08em] mb-1.5"
                    style={{ fontSize: 10, color: "#6B7280" }}
                  >
                    País
                  </label>
                  <Select value={pais} onValueChange={(v) => { setPais(v); setEstado(""); setCidade(""); }}>
                    <SelectTrigger className="pp-select-trigger">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent
                      className="pp-scroll"
                      style={{ background: "#0D0D12", border: "1px solid rgba(255,255,255,0.08)", color: "#FFFFFF", maxHeight: 280 }}
                    >
                      {paises.map(p => (
                        <SelectItem key={p.code} value={p.code}>{p.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div style={{ flex: "1 1 120px", minWidth: 0 }}>
                  <label
                    className="block uppercase tracking-[0.08em] mb-1.5"
                    style={{ fontSize: 10, color: "#6B7280" }}
                  >
                    Estado
                  </label>
                  {isBR ? (
                  <Select value={estado} onValueChange={(v) => { setEstado(v); setCidade(""); }}>
                    <SelectTrigger className="pp-select-trigger">
                      <SelectValue placeholder="Selecione o estado" />
                    </SelectTrigger>
                    <SelectContent
                      className="pp-scroll"
                      style={{ background: "#0D0D12", border: "1px solid rgba(255,255,255,0.08)", color: "#FFFFFF" }}
                    >
                      <SelectItem value="todos">Todos</SelectItem>
                      {estados.map(e => (
                        <SelectItem key={e.sigla} value={e.sigla}>{e.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  ) : (
                    <input value={estado} onChange={(e) => setEstado(e.target.value)} placeholder="Estado ou região" style={{ width: "100%", height: 40, padding: "0 12px", borderRadius: 8, background: "#0D0D12", border: "1px solid rgba(255,255,255,0.08)", color: "#FFFFFF", fontSize: 14, outline: "none" }} />
                  )}
                </div>
                <div style={{ flex: "1 1 120px", minWidth: 0 }}>
                  <label
                    className="block uppercase tracking-[0.08em] mb-1.5"
                    style={{ fontSize: 10, color: "#6B7280" }}
                  >
                    Cidade
                  </label>
                  {isBR ? (
                  <Select
                    value={cidade}
                    onValueChange={setCidade}
                    disabled={cidadeDisabled || loadingCidades}
                  >
                    <SelectTrigger
                      className="pp-select-trigger"
                      style={{ opacity: cidadeDisabled ? 0.5 : 1 }}
                    >
                      <SelectValue placeholder={cidadeDisabled ? "Selecione um estado" : (loadingCidades ? "Carregando..." : "Selecione a cidade")} />
                    </SelectTrigger>
                    <SelectContent
                      className="pp-scroll"
                      style={{ background: "#0D0D12", border: "1px solid rgba(255,255,255,0.08)", color: "#FFFFFF", maxHeight: 280 }}
                    >
                      <SelectItem value="todas">Todas</SelectItem>
                      {cidades.map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  ) : (
                    <input value={cidade} onChange={(e) => setCidade(e.target.value)} placeholder="Digite a cidade" style={{ width: "100%", height: 40, padding: "0 12px", borderRadius: 8, background: "#0D0D12", border: "1px solid rgba(255,255,255,0.08)", color: "#FFFFFF", fontSize: 14, outline: "none" }} />
                  )}
                </div>
                <button
                  type="button"
                  onClick={handleSearch}
                  disabled={loading}
                  className="btn-buscar flex items-center justify-center gap-2"
                  style={{
                    width: "auto",
                    padding: "0 24px",
                    height: 42,
                    borderRadius: 8,
                    background: "var(--q-accent, #2463EB)",
                    color: "var(--q-on-accent, #FFFFFF)",
                    fontSize: 14,
                    fontWeight: 700,
                    border: "none",
                    cursor: loading ? "default" : "pointer",
                    opacity: loading ? 0.8 : 1,
                  }}
                >
                  {loading ? (
                    <><Loader2 size={14} className="animate-spin" /> {searchMode === "manual" ? "Abrindo..." : "Buscando..."}</>
                  ) : searchMode === "manual" ? (
                    <><MapPin size={14} /> Abrir no Google Maps</>
                  ) : (
                    <><Search size={14} /> Buscar Leads</>
                  )}
                </button>
              </div>
            </div>

            {/* TABELA DE RESULTADOS (Apenas em modo automático ou durante o loading do manual/fallback) */}
            {(searchMode === "automatic" || (searchMode === "manual" && (loading || manualRedirectUrl))) && (
              <div className="px-6 pb-8">
              <div
                style={{
                  background: "#0D0D12",
                  border: "1px solid rgba(255,255,255,0.06)",
                  borderRadius: 12,
                  overflow: "hidden",
                }}
              >
                {/* Header da tabela */}
                <div
                  className="flex flex-wrap items-center justify-between gap-2 px-6 py-2"
                  style={{
                    minHeight: 52,
                    background: "#0D0D12",
                    borderBottom: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: 12, color: "#6B7280" }}>
                      {loading
                        ? (
                          <div className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-[var(--q-accent,#2463EB)] animate-pulse" />
                            <span>{searchMode === "manual" ? "Preparando redirecionamento para o Google Maps..." : "Escaneando a web em busca de leads..."}</span>
                          </div>
                        )
                        : manualRedirectUrl 
                          ? "Ação necessária: Clique no botão abaixo para abrir o Google Maps"
                          : results.length > 0
                          ? `${results.length} leads encontrados`
                          : searched
                            ? "Nenhum lead encontrado"
                            : "Configure os filtros e clique em Buscar"}
                    </span>
                    {results.length > 0 && (
                      <div 
                        className="px-2 py-0.5 rounded-full border border-[rgba(var(--q-accent-rgb, 36,99,235),0.15)] bg-[rgba(var(--q-accent-rgb, 36,99,235),0.1)]"
                        style={{ marginLeft: 4 }}
                      >
                        <span style={{ color: "var(--q-accent, #2463EB)", fontSize: 11, fontWeight: 700 }}>
                          {activeFilter}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleExportCSV}
                      disabled={!results.length}
                      className="flex items-center gap-1.5 px-3 transition-colors"
                      style={{
                        height: 32,
                        borderRadius: 7,
                        border: "1px solid rgba(255,255,255,0.08)",
                        fontSize: 12,
                        color: results.length ? "#FFFFFF" : "#374151",
                        cursor: results.length ? "pointer" : "default",
                        background: "transparent",
                      }}
                      onMouseEnter={(e) => { if (results.length) { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.color = "#FFFFFF"; } }}
                      onMouseLeave={(e) => { if (results.length) { e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "#FFFFFF"; } }}
                    >
                      <Download size={12} /> Exportar CSV
                    </button>
                  </div>
                </div>

                {/* Conteúdo */}
                {loading ? (
                  <div className="relative overflow-hidden">
                    <div className="scanner-line" />
                    <div className="px-5 py-6 space-y-4">
                      <div className="flex items-center gap-4 mb-2">
                        <div className="skel h-4 w-32" />
                        <div className="skel h-4 w-48" />
                      </div>
                      {[0, 1, 2, 3, 4, 5].map(i => (
                        <div key={i} className="flex gap-4 items-center">
                          <div className="skel h-12 flex-1" />
                          <div className="skel h-12 flex-1 hidden md:block" />
                          <div className="skel h-12 w-32 hidden md:block" />
                          <div className="skel h-10 w-24" />
                        </div>
                      ))}
                    </div>
                  </div>
                ) : manualRedirectUrl ? (
                  <div className="flex flex-col items-center justify-center py-16 px-6 text-center space-y-6">
                    <div className="w-16 h-16 rounded-2xl bg-[rgba(var(--q-accent-rgb,36,99,235),0.1)] flex items-center justify-center border border-[rgba(var(--q-accent-rgb,36,99,235),0.2)]">
                      <MapPin size={32} className="text-[var(--q-accent,#2463EB)]" />
                    </div>
                    <div className="max-w-md space-y-2">
                      <h3 className="text-xl font-bold text-[var(--au-text)]">Redirecionamento bloqueado</h3>
                      <p className="text-[var(--au-text-3)] text-sm">
                        O seu navegador bloqueou o popup automático. Clique no botão abaixo para prosseguir com a prospecção manual no Google Maps.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        window.open(manualRedirectUrl, "_blank", "noopener,noreferrer");
                        setManualRedirectUrl(null);
                      }}
                      className="flex items-center gap-2 px-8 h-12 bg-[var(--q-accent,#2463EB)] hover:bg-[var(--q-accent-hover,#2F6EED)] text-[var(--q-on-accent,#FFFFFF)] rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(var(--q-accent-rgb,36,99,235),0.3)] active:scale-95"
                    >
                      <ExternalLink size={18} />
                      Abrir no Google Maps
                    </button>
                  </div>
                ) : results.length > 0 ? (
                  <div className="pp-scroll" style={{ maxHeight: 520, overflowY: "auto" }}>
                    <table className="w-full" style={{ fontSize: 13 }}>
                      <thead>
                        <tr
                          style={{
                            borderBottom: "1px solid rgba(255,255,255,0.06)",
                            background: "#05050A",
                          }}
                        >
                          <th className="text-left font-medium px-6 py-2.5" style={{ color: "#374151", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase" }}>Negócio</th>
                          <th className="text-left font-medium px-4 py-2.5" style={{ color: "#374151", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase" }}>Descrição</th>
                          <th className="text-left font-medium px-4 py-2.5" style={{ color: "#374151", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase" }}>Telefone</th>
                          <th className="text-right font-medium px-6 py-2.5" style={{ color: "#374151", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase" }}>Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.map((r, i) => (
                          <motion.tr
                            key={i}
                            initial={{ opacity: 0, x: -6 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.18, ease: "easeOut", delay: i * 0.025 }}
                            className="row-result"
                            style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}
                          >
                            <td className="px-6 py-3.5 align-top" style={{ maxWidth: 240 }}>
                              <div className="flex items-center gap-1.5 font-medium truncate" style={{ color: "#FFFFFF", fontSize: 14 }}>
                                <MapPin size={12} strokeWidth={1.5} color="currentColor" className="shrink-0" style={{ color: "var(--q-accent, #2463EB)" }} />
                                {r.title}
                              </div>
                              <div className="truncate text-[11px] mt-0.5 ml-[18px]" style={{ color: "#374151" }}>{extractDomain(r.url)}</div>
                            </td>
                            <td className="px-4 py-3.5 align-top" style={{ color: "#6B7280", maxWidth: 360 }}>
                              <div className="line-clamp-1 text-[13px]">{r.description || "—"}</div>
                            </td>
                            <td className="px-4 py-3.5 align-top whitespace-nowrap text-[13px]" style={{ color: r.phone ? "#FFFFFF" : "#374151" }}>
                              {r.phone || "—"}
                            </td>
                            <td className="px-6 py-3.5 align-top">
                              <div className="flex items-center justify-end gap-2.5">
                                {r.phone && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const text = encodeURIComponent(`Olá, sou da Sylora. Vi que o seu negócio "${r.title}" tem um grande potencial, mas ainda não está aproveitando todo o poder do digital para fechar mais contratos.

Gostaria de apresentar como podemos automatizar sua prospecção e escalar seu faturamento de forma profissional. Podemos conversar hoje?`);
                                      const cleanPhone = r.phone!.replace(/\D/g, "");
                                      const waNumber = cleanPhone.length === 11 ? cleanPhone : (cleanPhone.length === 10 ? `11${cleanPhone}` : cleanPhone);
                                      openExternalLink(`https://wa.me/55${waNumber}?text=${text}`);
                                    }}
                                    title="Fechar Contrato no WhatsApp"
                                    className="flex items-center justify-center bg-[#22c55e]/10 hover:bg-[#22c55e]/20 transition-all group"
                                    style={{ width: 32, height: 32, borderRadius: 8, border: "1px solid rgba(34,197,94,0.2)" }}
                                  >
                                    <MessageCircle size={15} className="text-[#22c55e] transition-colors" />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const loc = buildLocation();
                                    const q = `${r.title} ${loc}`.trim();
                                    openExternalLink(`https://www.google.com/maps/search/${encodeURIComponent(q)}`);
                                  }}
                                  title="Ver no Google Maps"
                                  className="flex items-center justify-center bg-[rgba(var(--q-accent-rgb,36,99,235),0.1)] hover:bg-[rgba(var(--q-accent-rgb,36,99,235),0.2)] transition-all group"
                                  style={{ width: 32, height: 32, borderRadius: 8, border: "1px solid rgba(var(--q-accent-rgb, 36,99,235),0.2)" }}
                                >
                                  <MapPin size={15} className="text-[var(--q-accent,#2463EB)] transition-colors" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openExternalLink(r.url)}
                                  title="Abrir Site"
                                  className="flex items-center justify-center bg-[var(--au-surface-2)] hover:bg-[var(--au-surface-2)] transition-all group"
                                  style={{ width: 32, height: 32, borderRadius: 8, border: "1px solid rgba(255,255,255,0.06)" }}
                                >
                                  <ExternalLink size={15} className="text-[var(--au-text-3)] group-hover:text-[var(--au-text)] transition-colors" />
                                </button>
                              </div>
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div
                    className="flex flex-col items-center justify-center text-center"
                    style={{ padding: "56px 24px" }}
                  >
                    <Search size={28} strokeWidth={1.5} color="#1F2937" />
                    <p style={{ fontSize: 13, color: "#374151", marginTop: 12 }}>
                      Configure os filtros e clique em Buscar
                    </p>
                  </div>
                )}
              </div>
            </div>
            )}
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ProspeccaoView;
