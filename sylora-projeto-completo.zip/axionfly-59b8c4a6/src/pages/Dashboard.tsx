import MemberNotice from "@/components/auren/MemberNotice";
import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useAccessControl } from "@/hooks/useAccessControl";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import AurenSidebar, { type AurenView } from "@/components/auren/AurenSidebar";
import CriacaoSitesView from "@/components/auren/CriacaoSitesView";
import AnaliseSiteView from "@/components/auren/AnaliseSiteView";
import PortfolioIAView from "@/components/auren/PortfolioIAView";
import CreditosInfinitosView from "@/components/auren/CreditosInfinitosView";
import MentorIAView from "@/components/auren/MentorIAView";
import PresenteView from "@/components/auren/PresenteView";
import AurenTour from "@/components/auren/AurenTour";
import { RaffleCountdownBanner, RaffleWelcomeModal } from "@/components/auren/presente/RaffleBlocks";
import "@/components/auren/auren.css";
import VendasView from "@/components/views/VendasView";
import AdminView from "@/components/views/AdminView";
import PerfilView from "@/components/views/PerfilView";
import MeuGrupoView from "@/components/views/MeuGrupoView";
import { AnimatePresence, motion } from "framer-motion";
import { ShieldX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Component, type ErrorInfo, type ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AurenAmbient, Grain } from "@/components/auren/fx/parts";
import { useSpotlight } from "@/components/auren/fx/useSpotlight";
import { supabase } from "@/integrations/supabase/client";

const GRUPO_ALLOWED_EMAILS = ["evair.lol@live.com"];
// O Painel Admin só aparece para este e-mail.
const ADMIN_PANEL_EMAIL = "andreyhenriquev4@gmail.com";

type View = AurenView;

class DashboardViewErrorBoundary extends Component<
  { children: ReactNode },
  { hasError: boolean }
> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Dashboard view render error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-[60vh] items-center justify-center px-4">
          <div className="text-center space-y-3 max-w-md">
            <div className="w-14 h-14 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto">
              <ShieldX className="w-7 h-7 text-destructive" />
            </div>
            <h2 className="text-xl font-bold text-foreground">Não foi possível carregar esta área</h2>
            <p className="text-sm text-muted-foreground mb-4">A conexão falhou ou ocorreu um erro no carregamento. Tente atualizar a página.</p>
            <div className="flex flex-col gap-2">
              <Button 
                variant="neon" 
                onClick={() => window.location.reload()}
                className="w-full font-bold"
              >
                Atualizar Página
              </Button>
              <Button 
                variant="outline" 
                onClick={() => window.open("https://lovable.dev/projects", "_blank")}
                className="w-full font-bold border-[var(--au-border)]"
              >
                Ir para o Lovable
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const viewTitles: Record<View, string> = {
  vendas: "Dashboard",
  criar: "Criação de Sites",
  creditos: "Ativar Créditos",
  analise: "Diagnóstico de Sites",
  portfolio: "Meu Portfólio",
  mentor: "Mentor de Vendas",
  presente: "Recompensas",
  perfil: "Perfil",
  "meu-grupo": "Seu Grupo",
  admin: "Painel Administrativo",
};

const EASE = [0.22, 1, 0.36, 1] as const;

const Dashboard = () => {
  const rootRef = useSpotlight<HTMLDivElement>();
  const { user, loading, signOut } = useAuth();
  const { hasAccess, loading: accessLoading } = useAccessControl(user);
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const validViews: View[] = ["vendas", "criar", "creditos", "analise", "portfolio", "mentor", "presente", "perfil", "admin", "meu-grupo"];
  const paramView = searchParams.get("view") as View | null;
  const [activeView, setActiveView] = useState<View>(
    paramView && validViews.includes(paramView) ? paramView : "criar"
  );
  const [userName, setUserName] = useState<string>("");
  const [onboardingDone, setOnboardingDone] = useState(false);
  const [isProtocolo, setIsProtocolo] = useState(false);
  const [tourForce, setTourForce] = useState(0);

  const handleNavigate = useCallback((view: View) => {
    setActiveView(view);
    setSearchParams({ view });
  }, [setSearchParams]);

  useEffect(() => {
    if (!loading && !user) {
      navigate(`/auth?redirect=${encodeURIComponent(`${location.pathname}${location.search}`)}`, { replace: true });
    }
  }, [user, loading, navigate, location.pathname, location.search]);

  // Fetch profile display name
  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("display_name")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data?.display_name) setUserName(data.display_name);
      });
  }, [user]);

  // Marca Protocolo (contas de demonstração não veem banner nem aviso do sorteio). Falha silenciosa: a coluna pode não existir ainda.
  useEffect(() => {
    if (!user) return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (supabase as any).from("profiles").select("is_protocolo").eq("user_id", user.id).maybeSingle()
      .then(({ data }: { data?: { is_protocolo?: boolean } | null }) => setIsProtocolo(data?.is_protocolo === true))
      .catch(() => undefined);
  }, [user]);

  if (loading || accessLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <motion.div
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center"
        >
          <div className="w-5 h-5 rounded-full bg-primary" />
        </motion.div>
      </div>
    );
  }

  if (!user) return null;

  const canSeeAdmin = user.email?.toLowerCase() === ADMIN_PANEL_EMAIL;

  if (!hasAccess) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center space-y-6 max-w-md"
        >
          <div className="w-16 h-16 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto">
            <ShieldX className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Acesso Restrito</h1>
          <p className="text-muted-foreground">
            Você precisa adquirir um plano para acessar a plataforma. Após o pagamento, seu acesso será liberado automaticamente.
          </p>
          <div className="flex gap-3 justify-center">
            <Button variant="outline" onClick={async () => { await signOut(); navigate("/"); }}>
              Voltar
            </Button>
            <Button variant="neon" onClick={() => navigate("/#pricing")}>
              Ver Planos
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div ref={rootRef} className="auren flex min-h-screen w-full relative">
        {/* Fundo: o mesmo céu e a mesma grade da landing, em baixa intensidade */}
        <AurenAmbient />
        <Grain soft />

        <AurenSidebar
          active={activeView}
          onNavigate={handleNavigate}
          onSignOut={async () => {
            await signOut();
            navigate("/");
          }}
          userEmail={user.email}
          userName={userName}
          isAdmin={canSeeAdmin}
          showGrupo={!!user.email && GRUPO_ALLOWED_EMAILS.includes(user.email.toLowerCase())}
        />

        <div className="flex-1 min-w-0 flex flex-col relative z-10 overflow-x-clip">
          <header className="au-hdr">
            <SidebarTrigger className="text-[var(--au-text-3)] hover:text-[var(--au-text)] transition-colors" />
            <span className="au-hdr-sep" aria-hidden />
            <AnimatePresence mode="wait" initial={false}>
              <motion.h1
                key={activeView}
                className="au-hdr-title"
                initial={{ opacity: 0, y: 7 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -7 }}
                transition={{ duration: 0.2, ease: EASE }}
              >
                {viewTitles[activeView]}
              </motion.h1>
            </AnimatePresence>
            {/* o limite do cabeçalho: a lâmina cruza a cada troca de tela */}
            <span className="au-hdr-line" aria-hidden>
              <motion.i
                key={activeView}
                className="run"
                initial={{ left: "-14%", opacity: 0 }}
                animate={{ left: "104%", opacity: [0, 1, 1, 0] }}
                transition={{ duration: 1.25, ease: [0.45, 0.05, 0.3, 1], times: [0, 0.12, 0.85, 1] }}
              />
            </span>
          </header>

          <main className="flex-1 p-3 md:p-6 overflow-auto">
            <MemberNotice />
            {!isProtocolo && onboardingDone && <RaffleCountdownBanner userId={user.id} />}
            <DashboardViewErrorBoundary>
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeView}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.3, ease: EASE }}
                >
                  {activeView === "vendas" && <VendasView />}
                  {activeView === "criar" && <CriacaoSitesView />}
                  {activeView === "creditos" && <CreditosInfinitosView />}
                  {activeView === "analise" && <AnaliseSiteView />}
                  {activeView === "portfolio" && <PortfolioIAView />}
                  {activeView === "mentor" && <MentorIAView />}
                  {activeView === "presente" && <PresenteView />}
                  {activeView === "perfil" && <PerfilView />}
                  {activeView === "meu-grupo" && !!user.email && GRUPO_ALLOWED_EMAILS.includes(user.email.toLowerCase()) && <MeuGrupoView />}
                  {activeView === "admin" && canSeeAdmin && <AdminView onShowTour={() => setTourForce((n) => n + 1)} />}
                </motion.div>
              </AnimatePresence>
            </DashboardViewErrorBoundary>
          </main>
        </div>
      </div>

      <AurenTour userId={user.id} onComplete={() => setOnboardingDone(true)} forceOpen={tourForce} />
      <RaffleWelcomeModal userId={user.id} enabled={onboardingDone && !isProtocolo} />
    </SidebarProvider>
  );
};

export default Dashboard;
