import { useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { captureAffiliateFromUrl } from "@/lib/affiliates";
import AurenLanding from "@/components/auren/AurenLanding";

const Index = () => {
  useEffect(() => {
    captureAffiliateFromUrl();
  }, []);

  return (
    <>
      <Helmet>
        <title>Sylora — Criador de Sites com IA e Prospecção</title>
        <meta name="description" content="Crie sites e apps com IA em 10 minutos, prospecte clientes e venda mais com a Sylora." />
        <meta property="og:title" content="Sylora — Criador de Sites com IA e Prospecção" />
        <meta property="og:description" content="Crie sites e apps com IA em 10 minutos, prospecte clientes e venda mais com a Sylora." />
        <meta property="og:url" content="https://axionfly.lovable.app/" />
        <link rel="canonical" href="https://axionfly.lovable.app/" />
      </Helmet>
      <AurenLanding />
    </>
  );
};

export default Index;
