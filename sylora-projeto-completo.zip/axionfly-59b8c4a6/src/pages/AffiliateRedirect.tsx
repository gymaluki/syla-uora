import { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { normalizeAffiliateSlug, registerAffiliate } from "@/lib/affiliates";

export default function AffiliateRedirect({ slug: propsSlug }: { slug?: string }) {
  const { slug: paramsSlug } = useParams<{ slug: string }>();
  const slug = propsSlug || paramsSlug;
  const navigate = useNavigate();

  useEffect(() => {
    const affiliateSlug = normalizeAffiliateSlug(slug);

    let alive = true;
    // Só guarda a indicação se o afiliado existir; depois leva para a landing
    void (affiliateSlug ? registerAffiliate(affiliateSlug) : Promise.resolve(false)).finally(() => {
      if (alive) navigate("/", { replace: true });
    });
    return () => { alive = false; };
  }, [slug, navigate]);

  return null;
}
