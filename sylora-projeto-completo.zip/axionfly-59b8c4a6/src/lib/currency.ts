import { useCallback, useEffect, useState } from "react";

export const CURRENCIES = [
  { code: "BRL", label: "Real (R$)", locale: "pt-BR" },
  { code: "USD", label: "Dólar (US$)", locale: "en-US" },
  { code: "EUR", label: "Euro (€)", locale: "de-DE" },
  { code: "GBP", label: "Libra (£)", locale: "en-GB" },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]["code"];

const KEY = "auren_currency";
const RATES_KEY = "auren_rates";
const EVENT = "auren-currency";
// Valores aproximados, usados só se a cotação não puder ser buscada. 1 BRL = X
const FALLBACK: Record<CurrencyCode, number> = { BRL: 1, USD: 0.18, EUR: 0.16, GBP: 0.14 };

const readCode = (): CurrencyCode => {
  try {
    const v = localStorage.getItem(KEY) as CurrencyCode | null;
    if (v && CURRENCIES.some((c) => c.code === v)) return v;
  } catch { /* sem storage */ }
  return "BRL";
};

const readRates = (): Record<CurrencyCode, number> => {
  try {
    const raw = JSON.parse(localStorage.getItem(RATES_KEY) || "null");
    if (raw?.rates) return { ...FALLBACK, ...raw.rates };
  } catch { /* ignora */ }
  return FALLBACK;
};

async function refreshRates() {
  try {
    const raw = JSON.parse(localStorage.getItem(RATES_KEY) || "null");
    if (raw?.at && Date.now() - raw.at < 12 * 3600 * 1000) return;
    const res = await fetch("https://api.frankfurter.app/latest?from=BRL&to=USD,EUR,GBP");
    if (!res.ok) return;
    const json = await res.json();
    localStorage.setItem(RATES_KEY, JSON.stringify({ at: Date.now(), rates: { BRL: 1, ...json.rates } }));
    window.dispatchEvent(new Event(EVENT));
  } catch { /* fica com a última cotação ou a aproximada */ }
}

/** Moeda de exibição escolhida no Perfil. Os valores continuam salvos em reais; só a exibição converte. */
export function useCurrency() {
  const [code, setCodeState] = useState<CurrencyCode>(readCode);
  const [rates, setRates] = useState(readRates);

  useEffect(() => {
    const sync = () => { setCodeState(readCode()); setRates(readRates()); };
    window.addEventListener(EVENT, sync);
    refreshRates();
    return () => window.removeEventListener(EVENT, sync);
  }, []);

  const setCode = useCallback((c: CurrencyCode) => {
    try { localStorage.setItem(KEY, c); } catch { /* sem storage */ }
    window.dispatchEvent(new Event(EVENT));
  }, []);

  const format = useCallback((brl: number) => {
    const cur = CURRENCIES.find((c) => c.code === code)!;
    return (brl * (rates[code] ?? 1)).toLocaleString(cur.locale, { style: "currency", currency: code });
  }, [code, rates]);

  return { code, setCode, format };
}
