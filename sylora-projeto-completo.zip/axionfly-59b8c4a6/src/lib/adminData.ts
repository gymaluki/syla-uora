/* eslint-disable @typescript-eslint/no-explicit-any -- tabelas novas ainda não estão nos tipos gerados do Supabase */
// Camada de dados do Painel Admin. Toda autorização real fica no servidor (RPCs e função
// admin-manage-users); esconder uma aba na interface nunca substitui essa validação.
import { supabase } from "@/integrations/supabase/client";
import type { AdminApi, AdminAction } from "./adminTypes";

const db = supabase as any;

const invoke = async (action: string, body: Record<string, unknown> = {}) => {
  const { data, error } = await supabase.functions.invoke("admin-manage-users", { body: { action, ...body } });
  if (error) throw error;
  if (data && (data as any).error) throw new Error((data as any).error);
  return data as any;
};

const getUid = async () => (await supabase.auth.getUser()).data.user?.id ?? null;

export const adminApi: AdminApi = {
  async isAdmin() {
    const uid = await getUid();
    if (!uid) return false;
    const { data, error } = await supabase.rpc("is_admin", { check_user_id: uid });
    if (error) throw error;
    return data === true;
  },
  async isOwner() {
    const uid = await getUid();
    if (!uid) return false;
    const { data } = await db.rpc("is_owner", { check_user_id: uid });
    return data === true;
  },
  async list() {
    const data = await invoke("list");
    return { users: data.users || [], pendings: data.pendings || [] };
  },
  act: (action: AdminAction, body) => invoke(action, body),

  async getSettings(keys) {
    const { data, error } = await db.from("site_settings").select("key,value").in("key", keys);
    if (error) throw error;
    const out: Record<string, string> = {};
    (data || []).forEach((r: any) => { out[r.key] = r.value ?? ""; });
    return out;
  },
  async saveSettings(values) {
    const rows = Object.entries(values).map(([key, value]) => ({ key, value, updated_at: new Date().toISOString() }));
    const { error } = await db.from("site_settings").upsert(rows);
    if (error) throw error;
  },
  async uploadVideo(file, kind) {
    const ext = file.name.split(".").pop() || "mp4";
    const path = `${kind}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("landing-videos").upload(path, file, { upsert: true, contentType: file.type || "video/mp4" });
    if (error) throw error;
    // Mesmo comportamento do painel antigo: a landing lê o link público gravado em site_settings.
    const { data } = supabase.storage.from("landing-videos").getPublicUrl(path);
    return { path: data.publicUrl, url: data.publicUrl };
  },

  async platformSales(limit) {
    const { data, error } = await db.from("platform_sales").select("*").order("created_at", { ascending: false }).limit(limit);
    if (error) throw error;
    return data || [];
  },
  async licenses() {
    const { data, error } = await db.from("hyperbuild_licenses").select("*").order("created_at", { ascending: false });
    if (error) throw error;
    return data || [];
  },
  async licenseLogs(limit) {
    const { data, error } = await db.from("hyperbuild_license_logs").select("id,license_key,action,details,created_at,user_id").order("created_at", { ascending: false }).limit(limit);
    if (error) throw error;
    return data || [];
  },
  async testLicense() {
    // Atenção: esta chamada pode atribuir/consumir uma chave de verdade.
    const { error } = await supabase.rpc("claim_hyperbuild_license");
    if (error) {
      if (error.message.includes("Não há licenças")) return { ok: true, message: "Conectado, mas o estoque está vazio." };
      throw error;
    }
    return { ok: true, message: "Sistema de licenças respondendo corretamente." };
  },

  async mentorLogs(limit) {
    const { data, error } = await db.from("mentor_ia_logs").select("*").order("created_at", { ascending: false }).limit(limit);
    if (error) throw error;
    return data || [];
  },
  async usageReport() {
    const data = await invoke("usage_report");
    return data.rows || [];
  },
  async admins() {
    const data = await invoke("list_admins");
    return data.admins || [];
  },

  async affiliates() {
    const { data, error } = await db.from("affiliates").select("*").order("name");
    if (error) throw error;
    return data || [];
  },
  async saveAffiliate(a) {
    const payload = {
      name: a.name, slug: a.slug, email: a.email || null,
      monthly_url: a.monthly_url || null, lifetime_url: a.lifetime_url || null,
      updated_at: new Date().toISOString(),
    };
    const res = a.id ? await db.from("affiliates").update(payload).eq("id", a.id) : await db.from("affiliates").insert(payload);
    if (res.error) throw res.error;
  },
  async deleteAffiliate(id) {
    const { error } = await db.from("affiliates").delete().eq("id", id);
    if (error) throw error;
  },

  async systemErrors(limit) {
    const { data, error } = await db.from("system_errors").select("*").order("created_at", { ascending: false }).limit(limit);
    if (error) throw error;
    return data || [];
  },
  async resolveError(id) {
    const { error } = await db.from("system_errors").update({ resolved: true }).eq("id", id);
    if (error) throw error;
  },
  async deleteError(id) {
    const { error } = await db.from("system_errors").delete().eq("id", id);
    if (error) throw error;
  },
  onErrorsChange(cb) {
    const ch = supabase.channel("auren-admin-errors").on("postgres_changes", { event: "*", schema: "public", table: "system_errors" }, cb).subscribe();
    return () => { supabase.removeChannel(ch); };
  },
};
