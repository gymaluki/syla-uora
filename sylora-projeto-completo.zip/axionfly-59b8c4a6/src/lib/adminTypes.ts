// Tipos e constantes do Painel Admin (compartilhados entre a camada de dados e as abas).

export interface Subscription {
  id?: string;
  user_id: string;
  status: string;
  plan: string | null;
  payment_provider: string | null;
  transaction_id: string | null;
  affiliate_slug?: string | null;
  expires_at?: string | null;
  created_at: string;
  updated_at: string;
}

export interface AdminUser {
  user_id: string;
  email: string;
  display_name: string | null;
  created_at: string;
  last_sign_in_at: string | null;
  subscription: Subscription | null;
  is_protocolo?: boolean;
  is_admin?: boolean;
  is_owner?: boolean;
}

export interface PendingPayment {
  id: string;
  email: string;
  status: string;
  plan: string | null;
  payment_provider: string | null;
  transaction_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface PlatformSale {
  id: string;
  email: string;
  amount: number | null;
  status: string;
  payment_method: string | null;
  plan: string | null;
  affiliate_slug: string | null;
  transaction_id: string | null;
  created_at: string | null;
}

export interface License {
  id: string;
  key: string;
  lote: string | null;
  status: string;
  created_at: string;
  expires_at: string | null;
  used_by: string | null;
  used_at: string | null;
}

export interface LicenseLog {
  id: string;
  license_key: string | null;
  action: string;
  details: string | null;
  created_at: string;
  user_id: string | null;
}

export interface Affiliate {
  id: string;
  name: string;
  slug: string;
  email: string | null;
  monthly_url: string | null;
  lifetime_url: string | null;
  created_at: string | null;
}

export interface MentorLog {
  id: string;
  user_email: string | null;
  question: string;
  response: string | null;
  cached: boolean;
  source: string | null;
  created_at: string;
}

export interface UsageRow {
  user_id: string;
  email: string;
  display_name: string | null;
  plan: string | null;
  status: string | null;
  created_at: string;
  last_sign_in_at: string | null;
  mentor: number;
  prospeccao: number;
  aulas: number;
  sites: number;
  vendas: number;
  licencas: number;
  total_acoes: number;
  ultima_atividade: string | null;
}

export interface SystemError {
  id: string;
  level: string;
  message: string;
  source: string | null;
  url: string | null;
  user_email: string | null;
  stack: string | null;
  resolved: boolean;
  created_at: string;
}

export interface AdminRecord {
  user_id: string;
  email: string;
  is_owner: boolean;
}

export type AdminAction =
  | "activate"
  | "deactivate"
  | "set_plan"
  | "create_user"
  | "set_protocolo"
  | "set_admin";

export interface AdminApi {
  isAdmin(): Promise<boolean>;
  isOwner(): Promise<boolean>;
  list(): Promise<{ users: AdminUser[]; pendings: PendingPayment[] }>;
  act(action: AdminAction, body: Record<string, unknown>): Promise<unknown>;
  getSettings(keys: string[]): Promise<Record<string, string>>;
  saveSettings(values: Record<string, string>): Promise<void>;
  uploadVideo(file: File, kind: string): Promise<{ path: string; url: string }>;
  platformSales(limit: number): Promise<PlatformSale[]>;
  licenses(): Promise<License[]>;
  licenseLogs(limit: number): Promise<LicenseLog[]>;
  testLicense(): Promise<{ ok: boolean; message: string }>;
  mentorLogs(limit: number): Promise<MentorLog[]>;
  usageReport(): Promise<UsageRow[]>;
  admins(): Promise<AdminRecord[]>;
  affiliates(): Promise<Affiliate[]>;
  saveAffiliate(a: Partial<Affiliate>): Promise<void>;
  deleteAffiliate(id: string): Promise<void>;
  systemErrors(limit: number): Promise<SystemError[]>;
  resolveError(id: string): Promise<void>;
  deleteError(id: string): Promise<void>;
  onErrorsChange(cb: () => void): () => void;
}

export const PLAN_LABELS: Record<string, string> = {
  monthly: "Mensal (30 dias)",
  annual: "Anual (365 dias)",
  trial: "Trial (7 dias)",
  lifetime: "Vitalício",
};

export const PLAN_DAYS: Record<string, number> = { monthly: 30, annual: 365, trial: 7, lifetime: 36500 };

export const PAID_STATUSES = ["paid", "active", "approved", "completed"];

export const fmtDate = (d: string | null | undefined) =>
  d
    ? new Date(d).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })
    : "—";

export const fmtBRL = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

/** Dias restantes de uma assinatura (expires_at quando existe; senão, atualização + prazo do plano). */
export const calcRemaining = (sub: Subscription | null): string => {
  if (!sub || sub.status !== "active") return "—";
  const plan = sub.plan || "monthly";
  if (plan === "lifetime") return "Vitalício";
  const end = sub.expires_at
    ? new Date(sub.expires_at).getTime()
    : new Date(sub.updated_at).getTime() + (PLAN_DAYS[plan] || 30) * 86400000;
  const rem = Math.ceil((end - Date.now()) / 86400000);
  if (rem <= 0) return "Expirado";
  return `${rem} dia${rem === 1 ? "" : "s"}`;
};

/** Assinatura ativa e ainda dentro do prazo. */
export const isLive = (sub: Subscription | null) => {
  if (!sub || sub.status !== "active") return false;
  if (!sub.expires_at) return true;
  return new Date(sub.expires_at).getTime() > Date.now();
};
