// Textos e links do site editáveis pelo Painel Admin (tabela site_settings, leitura pública).
// Sem valor salvo, vale o padrão daqui: a landing nunca fica vazia se a consulta falhar.
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type SiteField = { key: string; label: string; group: string; def: string; long?: boolean; hint?: string };

export const SITE_FIELDS: SiteField[] = [
  { key: "site_ticker", group: "Faixa do topo", label: "Texto da faixa", def: "Promoção Black Friday", hint: "Aparece na faixa preta acima do menu." },
  { key: "site_hero_1", group: "Título principal", label: "Linha 1", def: "Lance sites e apps prontos" },
  { key: "site_hero_2", group: "Título principal", label: "Linha 2", def: "em 10 minutos com IA" },
  { key: "site_hero_sub", group: "Título principal", label: "Subtítulo", long: true, def: "A IA monta tudo por você. Escolha seu plano e comece a construir um negócio *sem limites* para crescer.", hint: "Coloque *asteriscos* em volta do trecho que deve aparecer sublinhado." },
  { key: "site_hero_cta", group: "Título principal", label: "Botão principal", def: "Quero começar agora" },
  { key: "site_hero_cta2", group: "Título principal", label: "Botão secundário", def: "Conhecer os planos" },
  { key: "site_feat_title", group: "Funcionalidades", label: "Título da seção", def: "Tudo o que você precisa para escalar seu negócio" },
  { key: "site_feat_lead", group: "Funcionalidades", label: "Texto da seção", long: true, def: "Da prospecção ao fechamento. Uma plataforma completa desenvolvida para transformar iniciantes em agências de sucesso." },
  { key: "site_how_title", group: "Como funciona", label: "Título da seção", def: "O caminho mais rápido para começar a vender" },
  { key: "site_how_lead", group: "Como funciona", label: "Texto da seção", long: true, def: "Da ativação ao fechamento, tudo acontece em uma sequência simples para você sair da teoria e ir direto para o lucro." },
  { key: "bld_site_desc", group: "Criar Site ou App · telas", label: "Descrição do tipo Site", long: true, def: "Página profissional para captar clientes, mostrar serviços e converter visitantes em vendas reais." },
  { key: "bld_app_desc", group: "Criar Site ou App · telas", label: "Descrição do tipo App", long: true, def: "Aplicativo instalável no celular para delivery, cardápio digital ou agendamento de horários 24h." },
  { key: "bld_h_1", group: "Criar Site ou App · telas", label: "Título da etapa 1 (Leads)", def: "Qual é o seu *negócio*?", hint: "Os *asteriscos* marcam o trecho com brilho." },
  { key: "bld_s_1", group: "Criar Site ou App · telas", label: "Texto da etapa 1", def: "Escolha o nicho que melhor representa o que você faz." },
  { key: "bld_h_2", group: "Criar Site ou App · telas", label: "Título da etapa 2 (Negócio)", def: "Conte sobre o seu *negócio*" },
  { key: "bld_h_3", group: "Criar Site ou App · telas", label: "Título da etapa 3 (Abordagem)", def: "Sua *abordagem* profissional" },
  { key: "bld_s_3", group: "Criar Site ou App · telas", label: "Texto da etapa 3", long: true, def: "Geramos um script de pré-venda dividido em blocos estratégicos. Use por completo ou copie por etapas." },
  { key: "bld_ab_abertura", group: "Criar Site ou App · script de abordagem", label: "Abertura", long: true, hint: "Variáveis: {empresa} {cidade} {nicho} {entrega} {pronto} {link}", def: "Olá! Tudo bem? Falo com o responsável pela {empresa}?" },
  { key: "bld_ab_apresentacao", group: "Criar Site ou App · script de abordagem", label: "Apresentação", long: true, def: "Meu nome é [Seu Nome] e trabalho criando {entrega} para empresas do segmento de {nicho} aqui em {cidade}." },
  { key: "bld_ab_diagnostico", group: "Criar Site ou App · script de abordagem", label: "Diagnóstico", long: true, def: "Analisei rapidamente a presença digital da {empresa} e identifiquei pontos importantes que estão fazendo a empresa perder clientes todos os dias para a concorrência." },
  { key: "bld_ab_proposta_site", group: "Criar Site ou App · script de abordagem", label: "Proposta de valor · Site", long: true, def: "Preparei uma proposta exclusiva de site profissional pensada especificamente para a {empresa}, com foco em três entregas claras:\n\n✅ Captação ativa de novos clientes pelo Google e redes sociais\n✅ Autoridade e credibilidade que justificam um ticket maior\n✅ Atendimento integrado ao WhatsApp, 24h por dia, sem perder lead" },
  { key: "bld_ab_proposta_app", group: "Criar Site ou App · script de abordagem", label: "Proposta de valor · App", long: true, def: "Preparei uma proposta exclusiva de aplicativo pensada especificamente para a {empresa}, com foco em três entregas claras:\n\n✅ Pedidos e agendamentos direto pelo celular, sem pagar comissão de marketplace\n✅ App instalável com a marca da empresa na tela do cliente\n✅ Atendimento integrado ao WhatsApp, 24h por dia, sem perder pedido" },
  { key: "bld_ab_fechamento_link", group: "Criar Site ou App · script de abordagem", label: "Fechamento · com link do projeto", long: true, def: "Já deixei {pronto} para você visualizar: {link}\n\nPosso te explicar como funciona em uma conversa rápida?" },
  { key: "bld_ab_fechamento", group: "Criar Site ou App · script de abordagem", label: "Fechamento · sem link", long: true, def: "Já deixei uma prévia do projeto pronta para você visualizar. Posso te enviar agora mesmo para agendar uma conversa?" },
];

export const SITE_DEFAULTS: Record<string, string> = Object.fromEntries(SITE_FIELDS.map((f) => [f.key, f.def]));

let cache: Record<string, string> | null = null;
let inflight: Promise<Record<string, string>> | null = null;

const loadSite = (): Promise<Record<string, string>> => {
  if (cache) return Promise.resolve(cache);
  inflight ??= (async () => {
    try {
      const { data } = await supabase.from("site_settings").select("key,value").in("key", SITE_FIELDS.map((f) => f.key));
      const out: Record<string, string> = {};
      (data || []).forEach((r) => { if (r.value && r.value.trim()) out[r.key] = r.value.trim(); });
      cache = out;
    } catch {
      cache = {};
    }
    return cache!;
  })();
  return inflight;
};

/** Devolve t("chave"): o texto salvo no painel ou o padrão. */
export const useSiteText = () => {
  const [saved, setSaved] = useState<Record<string, string>>(cache ?? {});
  useEffect(() => { let on = true; void loadSite().then((v) => on && setSaved(v)); return () => { on = false; }; }, []);
  return (key: string) => saved[key] || SITE_DEFAULTS[key] || "";
};

/** Texto com *trechos* marcados: devolve as partes e se cada uma é destaque. */
export const markParts = (text: string) => text.split("*").map((t, i) => ({ t, mark: i % 2 === 1 })).filter((p) => p.t);

/* ---------- links de checkout ---------- */
const CHECKOUT_HOSTS = ["applyfy.com.br", "cakto.com.br", "kirvano.com", "perfectpay.com.br", "abacatepay.com"];
export const isCheckoutUrlOk = (url: string) => {
  try {
    const u = new URL(url);
    const h = u.hostname.toLowerCase();
    return u.protocol === "https:" && CHECKOUT_HOSTS.some((d) => h === d || h.endsWith("." + d));
  } catch {
    return false;
  }
};

export const CHECKOUT_KEYS = { monthly: "checkout_monthly_url", lifetime: "checkout_annual_url" } as const;

/** Link salvo no painel para o plano, ou null (usa o padrão do código). */
export const fetchCheckoutOverride = async (plan: "monthly" | "lifetime"): Promise<string | null> => {
  try {
    const key = CHECKOUT_KEYS[plan];
    const { data } = await supabase.from("site_settings").select("value").eq("key", key).maybeSingle();
    const v = data?.value?.trim();
    return v && isCheckoutUrlOk(v) ? v : null;
  } catch {
    return null;
  }
};
