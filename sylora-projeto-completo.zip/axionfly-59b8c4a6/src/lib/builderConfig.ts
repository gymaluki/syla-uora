// Configuração do fluxo "Criar Site ou App" editável no Painel Admin (site_settings, chave builder_config).
// Sem nada salvo, valem os nichos e as cores do código.
import { useEffect, useMemo, useState } from "react";
import { Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { NICHES, type Niche } from "@/components/auren/niches";
import { namedColors } from "@/components/views/SitesView";

export const BUILDER_KEY = "builder_config";

export type NicheOverride = { hidden?: boolean; label?: string; app?: boolean; primary?: string; secondary?: string; prompt?: string };
export type CustomNiche = { key: string; label: string; app: boolean; primary: string; secondary: string; prompt: string };
export type NamedColor = { name: string; hex: string };
export type BuilderConfig = { niches: Record<string, NicheOverride>; custom: CustomNiche[]; colors: NamedColor[] | null };
export type BuilderNiche = Niche & { prompt?: string; custom?: boolean };

export const EMPTY_CONFIG: BuilderConfig = { niches: {}, custom: [], colors: null };

const HEX = /^#[0-9a-fA-F]{6}$/;

export const parseConfig = (raw: string | null | undefined): BuilderConfig => {
  try {
    const j = JSON.parse(raw || "{}");
    const custom: CustomNiche[] = (Array.isArray(j.custom) ? j.custom : [])
      .filter((c: CustomNiche) => c && typeof c.key === "string" && typeof c.label === "string" && c.label.trim())
      .map((c: CustomNiche) => ({
        key: c.key, label: c.label.trim(), app: !!c.app,
        primary: HEX.test(c.primary) ? c.primary : "#0F172A", secondary: HEX.test(c.secondary) ? c.secondary : "#F8FAFC",
        prompt: String(c.prompt || ""),
      }));
    const colors: NamedColor[] | null = Array.isArray(j.colors)
      ? j.colors.filter((c: NamedColor) => c && typeof c.name === "string" && HEX.test(c.hex)).map((c: NamedColor) => ({ name: c.name.trim() || c.hex, hex: c.hex }))
      : null;
    return { niches: j.niches && typeof j.niches === "object" ? j.niches : {}, custom, colors: colors && colors.length ? colors : null };
  } catch {
    return EMPTY_CONFIG;
  }
};

let cache: BuilderConfig | null = null;
let inflight: Promise<BuilderConfig> | null = null;
const listeners = new Set<(c: BuilderConfig) => void>();

const load = (): Promise<BuilderConfig> => {
  if (cache) return Promise.resolve(cache);
  inflight ??= (async () => {
    try {
      const { data } = await supabase.from("site_settings").select("value").eq("key", BUILDER_KEY).maybeSingle();
      cache = parseConfig(data?.value);
    } catch {
      cache = EMPTY_CONFIG;
    }
    return cache!;
  })();
  return inflight;
};

/** Chamado pelo Painel Admin depois de salvar, para o app refletir na hora. */
export const setBuilderConfig = (c: BuilderConfig) => { cache = c; listeners.forEach((l) => l(c)); };

/** Junta nichos do código + ajustes salvos + nichos criados no painel. */
export const mergeNiches = (cfg: BuilderConfig, includeHidden = false): BuilderNiche[] => {
  const base: BuilderNiche[] = NICHES.map((n) => {
    const o = cfg.niches[n.key] || {};
    return {
      ...n,
      label: o.label?.trim() || n.label,
      permiteApp: o.app ?? n.permiteApp,
      defaultPrimary: o.primary && HEX.test(o.primary) ? o.primary : n.defaultPrimary,
      defaultSecondary: o.secondary && HEX.test(o.secondary) ? o.secondary : n.defaultSecondary,
      prompt: o.prompt?.trim() || undefined,
    };
  });
  const extra: BuilderNiche[] = cfg.custom.map((c) => ({
    key: c.key, label: c.label, icon: Sparkles, defaultPrimary: c.primary, defaultSecondary: c.secondary,
    permiteApp: c.app, prompt: c.prompt.trim() || undefined, custom: true,
  }));
  const all = [...base, ...extra];
  return includeHidden ? all : all.filter((n) => !cfg.niches[n.key]?.hidden);
};

export const useBuilderConfig = () => {
  const [cfg, setCfg] = useState<BuilderConfig>(cache ?? EMPTY_CONFIG);
  useEffect(() => {
    let on = true;
    void load().then((c) => on && setCfg(c));
    listeners.add(setCfg);
    return () => { on = false; listeners.delete(setCfg); };
  }, []);
  const niches = useMemo(() => mergeNiches(cfg), [cfg]);
  const colors = cfg.colors ?? namedColors;
  return { cfg, niches, colors, nicheByKey: (key: string) => niches.find((n) => n.key === key) };
};

/** Preenche {{nome}}, {{endereco}}, {{telefone}}, {{cor1}}, {{cor2}}, {{tipo}} e {{nicho}} no prompt do nicho. */
export const fillPrompt = (tpl: string, v: Record<string, string>) =>
  tpl.replace(/\{\{\s*(\w+)\s*\}\}/g, (m, k) => (k in v ? v[k] : m));
