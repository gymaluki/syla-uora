// Relógios do sorteio e do bônus. São três bases diferentes de propósito (ver guia):
//  - banner e aviso inicial: primeiro registro local da conta neste navegador + 13 dias;
//  - sorteio na aba Presente: criação da conta + 13 dias;
//  - bônus (Presente): criação da conta + 6 dias.
// Todos somam períodos de 24h (86.400.000 ms). Não contam dias de uso.

export const RAFFLE_DAYS = 13;
export const BONUS_DAYS = 6;
export const RAFFLE_PRIZE = "R$ 2.000";
export const RAFFLE_SLOTS = 10;
export const RAFFLE_BUYER = "10.000";
export const DAY_MS = 86_400_000;

const key = (userId: string) => `sylora_raffle_first_seen_v1:${userId}`;

/** Lê o primeiro registro local SEM gravar. */
export const readFirstSeen = (userId: string): Date | null => {
  try {
    const v = localStorage.getItem(key(userId));
    const d = v ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d : null;
  } catch {
    return null;
  }
};

export const hasFirstSeen = (userId: string) => readFirstSeen(userId) !== null;

/** Reaproveita a data válida existente; sem ela, grava agora. Só chame depois do tutorial. */
export const ensureFirstSeen = (userId: string): Date => {
  const cur = readFirstSeen(userId);
  if (cur) return cur;
  const now = new Date();
  try { localStorage.setItem(key(userId), now.toISOString()); } catch { /* armazenamento bloqueado */ }
  return now;
};

/** Para exibição: usa a data gravada ou "agora" sem gravar nada. */
export const getSorteioDate = (userId: string): Date => {
  const start = readFirstSeen(userId) ?? new Date();
  return new Date(start.getTime() + RAFFLE_DAYS * DAY_MS);
};

/** Arredonda para cima: fração positiva de dia vira pelo menos 1; vencido vira 0. */
export const getDiasRestantesSorteio = (userId: string): number => {
  const diff = getSorteioDate(userId).getTime() - Date.now();
  return diff <= 0 ? 0 : Math.ceil(diff / DAY_MS);
};

export const getSorteioDataFormatada = (userId: string): string =>
  getSorteioDate(userId).toLocaleDateString("pt-BR", { day: "numeric", month: "long", year: "numeric" });

export const splitRemaining = (target: Date, now = Date.now()) => {
  const diff = Math.max(0, target.getTime() - now);
  return {
    done: diff <= 0,
    days: Math.floor(diff / DAY_MS),
    hours: Math.floor((diff % DAY_MS) / 3_600_000),
    minutes: Math.floor((diff % 3_600_000) / 60_000),
    seconds: Math.floor((diff % 60_000) / 1000),
  };
};
